Comandos básicos

/*
LIVRO NOSQL
*/


// comandos usados

use ligado
show dbs;
show collections;
db.albuns.insert({})


db.albuns.insert({"nome": "The Dark Side of the Moon", "data": new Date(1973, 3, 29)})
db.albuns.insert({"nome" : "Master ofPuppets", "dataLancamento" : new Date(1986, 2, 3), "duracao" : 3286})
db.albuns.insert({"nome" : "...And Justice for All", "dataLancamento" : new Date(1988, 7, 25), "duracao" : 3929})
db.albuns.insert({"nome" : "AmongtheLiving", "produtor" : "Eddie Kramer"})
db.albuns.insert({"nome" : "Nevermind", "artista" : "Nirvana", "estudioGravacao" : ["SoundCity Studios", "SmartStudios(Madison)"], "dataLancamento" : new Date(1992, 0, 11)})
db.albuns.insert({"nome": "Reignin Blood", "dataLancamento" : new Date(1986, 9, 7), "artista" : "Larry Carroll", "duracao" : 1738})
db.albuns.insert({"nome" : "Seventh Son of a Seventh Son", "artista" : "Iron Maiden", "produtor" : "Martin Birch", "estudioGravacao" : "MusiclandStudios", "dataLancamento" : new Date(1988, 3, 11)})

// retorna uma lista
db.albuns.find({
    "nome": "Master ofPuppets"
})

// retorna um documento
db.albuns.findOne({
    "nome": "Master ofPuppets"
})


// operadores de comparação
operador -  descrição - simbolo
$gt  - maior que  - >
$gte - maior ou igual - >=
$in  - existe no array - contém em uma lista/array ex.: 1 in [4,65,2,44,1]
$lt  - menor que - <
$lte - menor ou igual - <=
$ne  - diferença  !=
$nin - negação !


// operadores lógicos
$and
$nor 
$not
$or


db.albuns.find({
    $and: [
           {"dataLancamento": {$gte : new Date(1986, 0, 1) }},
           {"dataLancamento": {$lt: new Date(1987, 0, 1) }}
          ]
})



db.albuns.find({
    "dataLancamento": {
        $gte : new Date(1986, 0, 1),
        $lt: new Date(1987, 0, 1)
    }         
})



