Apresentação: 
* tecnologias de persistencia de dados: bancos relacionais e não relacionais

Conceitos principais
* Banco de dados relacionais: ACID
Atomicidade = a transação é executada totalmente ou não é executada

Consistência = sistemas sempre consistente após uma operação

Isolamento = transação não sofre interferência de outra transação concorrente

Durabilidade = o que foi salvo não é mais perdido  - força a consistência ao final de cada transação


Modelo de Dados
* Categorias de modelos de dados
- conceituais: alto nível - possuem conceitos que descrevem os dados como os usuários percebem; baseado em entidades, atributos e relacionamentos (independente de SGBD)

- físico: baixo nível - possuem conceitos que descrevem como os dados estão armazenados no computador (tipos e tamanho de registros)

- lógicos: representativos ou de implementação - intermediário entre físico e lógico; ex.: modelo relacional



Linguagens de SGBD:
1. linguagem de definição de dados - DDL - definição dos esquemas do banco de dados
2. linguagem de manipulação de dados - DML
3. linguagem de controle de dados - DCL - usada para conceder e retirar privilégios de usuários de DB emm objetos de DB
4. linguagem de consulta de dados - DQL - data query language
5. linguagem de controle de transação - TCL - usada para lidar com transações no banco de dados


Banco de dados relacionais
* file:///home/antonio/Documents/Github/pos/banco-de-dados-relacionais-nao/1_02_Modelo%20Relacional.pdf
* Integridade referencial

* Para resumir o procedimento de normalização da Primeira até a Terceira Forma Normal: cada campo em um registro deve depender da chave primária (1FN), de toda a chave primária (2FN) e nada além da chave primária (3FN).

Exemplo de modelagem ER
oracle
user: antonioggca000@gmail.com
passwd RUB76w83MjWQzPx


CREATE TABLE Aluno (
    matricula int,
    nome varchar (30),
    CONSTRAINT pk_matricula PRIMARY KEY (matricula)
);

insert into Aluno (matricula, nome) values (10, 'Marria');
select * from Aluno;

alter table empregado add uf_emp char(2) null;
alter table empregado drop column uf_emp;

-- alter table dependente drop constraint pk_dep
-- alter table dependente add constraint pk_dep primary key (matemp, nomdep)
-- alter table empregado drop constraint pk_emp;


alter table Dependente drop constraint FK_EMP_DEP

alter table Dependente add constraint FK_EMP_DEP foreign key (MatEmp)  references Empregado (MatEmp) on delete cascade


select NomEmp, CidEmp 
from Empregado
where MatEmp = 11


select NomEmp, Salario, Salario + 300
from Empregado

select NomEmp as nome, Salario as salario, 12 * (Salario + 300) as salrioMaior 
from Empregado



select sum(salario) as soma, max(salario) as maior, min(salario) as menor, avg(salario) as media
from empregado


* count()


select nomemp 
from empregado
order by nomemp desc


select codDepto, count(*) as qtd, avg(Salario) as sal 
from Empregado
group by codDepto


select P.CodProjeto, P.ProjNome, count(*)
from Projeto P, Trabalha_Em T
where P.CodProjeto = T.CodProjeto
group by P.CodProjeto, P.ProjNome 
having count(*) > 2


select NomEmp
from Empregado
where SALARIOBRUTO = (select max(SALARIOBRUTO) from Empregado)


select distinct MatEmp
from Trabalha_Em
where Horas in (select Horas
                from Trabalha_Em
                where MatEmp = '123')
                
                
select NomEmp
from EMPREGADO
where Salario > all(select Salario
                    from Empregado
                    where CodDepto = 2),
                    
                    
select E.NomEmp, E.EndEmp 
from Empregado E, Departamento D
where D.DeptoNome = 'Pesquisa' and D.codDepto = E.codDepto

select E.NomEmp, E.EndEmp 
from Empregado E JOIN Departamento D ON E.CodDepto = D.CodDepto
where D.DeptoNome = 'Pesquisa' 


select E.MatEmp as matricula, E.NomEmp as nome, D.NomDep as dependente
from Empregado E Join Dependente D on D.MatEmp = E.MatEmp


INNER JOIN
select *
from Empregado E inner join Departamento D on E.CodDepto = D.CodDepto

select *
from Empregado E left outer join Departamento D on E.CodDepto = D.CodDepto

select *
from Empregado E right outer join Departamento D on E.CodDepto = D.CodDepto

select *
from Empregado E full outer join Departamento D on E.CodDepto = D.CodDepto

select *
from Empregado E cross join Departamento D 

Para tabelas auto referenciadas
select *
from Empregado E inner join Empregado Emp ON E.CodSupervisor = Emp.MatEmp


Inner join de mais de duas tabelas
select E.NomEmp, P.ProjNome
from Empregado E inner join Trabalha_Em T on E.MatEmp = T.MatEmp 
        inner join Projeto P on T.CodProjeto = P.CodProjeto
        
        
        
        
        
        
        
        
        
 MODULO II - BANCO DE DADOS NOSQL
 
 * Os 5 V´s
 - Volume, velocidade e variedade
 - Veracidade e Valor
 
 * Servidores de Replicação master-slave e masterless
 - trata se da replicação dos dados entre os servidores, no sentido do master para os slaves. dessa forma ambos os servidores servem para leitura, porém apenas o master como leitura e escrita. 
 
 * CAP Theorem
 - Consistência / Alta Disponibilidade / Tolerância a Particionamento dos dados na rede 
 - Segundo o teorema só é possível obter apenas duas dessas partições ao mesmo tempo;
 - CP: forte consistência e tolerância a particionamento - 
 
 
 REDIS PRÁTICA
 