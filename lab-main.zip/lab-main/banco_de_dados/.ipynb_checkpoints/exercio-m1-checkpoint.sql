drop table Cliente if exists;
drop table Locacao if exists;
drop table Filme if exists;
drop table Preco if exists;
drop table Genero if exists;

create table Cliente (
    codCliente number(10) not null,
    nome varchar2(50) null,
    endereco varchar2(50) null,
    bairro varchar2(20) null,
    cidade varchar2(50) null,
    estado char(2) null,
    constraint pk_cliente primary key (codCliente)
);

create table Preco (
    cor char(2) not null,
    valor number(10,2) not null,
    constraint pk_cor primary key (cor)
);

insert into Preco (cor, valor) values (23, 30.00);
insert into Preco (cor, valor) values (20, 25.5);
insert into Preco (cor, valor) values (10, 10.5);
insert into Preco (cor, valor) values (50, 10);



create table Genero (
    codGenero number(3) not null,
    descricao varchar2(20) not null,
    constraint pk_genero primary key (codGenero)
);


create table Filme (
    codFilme number(3) not null,
    nome varchar2(50) not null,
    cor char(2) not null,
    status char(1) not null,
    codGenero number(3) not null,
    constraint pk_filme primary key (codFilme),
    constraint fk_preco foreign key (cor) references Preco (cor),
    constraint fk_genero foreign key (codGenero) references Genero (codGenero)
);


create table Locacao (
    codCliente number(10) not null,
    data_ date not null,
    codFilme number(3) not null,
    dataDeDevolucao date null,
    constraint pk_locacao primary key (data_)
);

alter table Locacao add constraint fk_cliente foreign key (codCliente) references Cliente (codCliente);
alter table Locacao add constraint fk_filme foreign key (codFilme) references Filme (codFilme);
