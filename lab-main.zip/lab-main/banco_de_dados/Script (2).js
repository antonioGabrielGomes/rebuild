
var overspeed_route = db.truck_event.find({ "eventType": "Overspeed" })

/*
overspeed_route.forEach(function(o){
    print(o["routeName"])
})
*/

overspeed_route.forEach(function(o){
   // db.albuns.find({ "artista": {"nome": "Blind Guardian"} })
    //var dv = db.driver.find({"driverId": o["driverId"]})        
   // dv
   print("Truck ID: ", o["routeName"], "// Driver ID: ", o["driverId"], "// SSN: ")
})


