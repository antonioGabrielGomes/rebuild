
/*
LIVRO NOSQL
*/


// comandos usados

// use ligado
// show dbs;
// show collections;

// db.albuns.insert({})

/*
db.albuns.insert({"nome": "The Dark Side of the Moon", "data": new Date(1973, 3, 29)})
db.albuns.insert({"nome" : "Master ofPuppets", "dataLancamento" : new Date(1986, 2, 3), "duracao" : 3286})
db.albuns.insert({"nome" : "...And Justice for All", "dataLancamento" : new Date(1988, 7, 25), "duracao" : 3929})
db.albuns.insert({"nome" : "AmongtheLiving", "produtor" : "Eddie Kramer"})
db.albuns.insert({"nome" : "Nevermind", "artista" : "Nirvana", "estudioGravacao" : ["SoundCity Studios", "SmartStudios(Madison)"], "dataLancamento" : new Date(1992, 0, 11)})
db.albuns.insert({"nome": "Reignin Blood", "dataLancamento" : new Date(1986, 9, 7), "artista" : "Larry Carroll", "duracao" : 1738})
db.albuns.insert({"nome" : "Seventh Son of a Seventh Son", "artista" : "Iron Maiden", "produtor" : "Martin Birch", "estudioGravacao" : "MusiclandStudios", "dataLancamento" : new Date(1988, 3, 11)})



db.albuns.find({
    "nome": "Master ofPuppets"
})


db.albuns.findOne({
    "nome": "Master ofPuppets"
})

db.albuns.find({
    "duracao": { "$lt": 1800 }
})

db.albuns.find({
    $and: [
           {"dataLancamento": {$gte : new Date(1986, 0, 1) }},
           {"dataLancamento": {$lt: new Date(1987, 0, 1) }}
          ]
})

db.albuns.find({
    "dataLancamento": {
        $gte : new Date(1986, 0, 1),
        $lt: new Date(1987, 0, 1)
    }         
})

db.albuns.remove({"nome": "...And Justice for All"})

//db.albuns.update({"nome": "AmongtheLiving"},
 //                {"duracao": 3013})

db.albuns.update(
    {"_id": ObjectId("6082624cf74927f5fc26bd3d")},
    {$set: {"nome": "Among the Living",
            "produtor": "Eddie Kramer"}}
)

db.artistas.insert([ {"nome" : "Metallica"},
{"nome" : "Megadeath"},
{"nome" : "Slayer"},
{"nome" : "Anthrax"} ])

// criando chaves estrangeira fake
db.albuns.update({
    "nome": "Master ofPuppets"
}, {
    $set: {"artista_id": ObjectId("608741895d85c9598b634c49")}
})

// criando chaves estrangeira fake
db.albuns.update({
    "nome": "Nevermind"
}, {
    $set: {"artista_id": ObjectId("608741895d85c9598b634c49")}
})

// insert com id de outro documento
db.albuns.insert({
    "nome": "... And Justice for All",
    "dataLancamento": new Date(1988, 7, 25),
    "duracao": 3929,
    "artista_id": ObjectId("608741895d85c9598b634c4a")
})

var artista = db.artistas.findOne({"nome": "Metallica"})
//artista

var albuns = db.albuns.find({ "artista_id": artista._id })
albuns.forEach(function(album){
    print(album["nome"])
})

var albuns = db.albuns.find({
    "dataLancamento": {"$gte": new Date(1986, 1, 1)}
})


albuns.forEach(function(album){
    print(album["nome"])
    print(album["artista_id"])
})

// documentos concatenados

db.albuns.insert({
    "nome": "Somewhere Far Beyond",
    "dataLancamento": new Date(1992, 5, 30),
    "duracao": 3328,
    "artista": {"nome": "Blind Guardian"}
})

db.albuns.insert({
    "nome": "Imaginations from the Other Side",
    "dataLancamento": new Date(1995, 3, 4),
    "duracao": 2958,
    "artista": {"nome": "Blind Guardian"}
})

db.albuns.insert({
    "nome": "Tunes of War",
    "dataLancamento": new Date(1996, 7, 25),
    "duracao": 3165,
    "artista": {"nome": "Grave Digger"}
})

db.albuns.insert({
    "nome": "Knights of the Cross",
    "dataLancamento": new Date(1998, 4, 18),
    "duracao": 3150,
    "artista": {"nome": "Grave Digger"}
})

// busca 
var albuns = db.albuns.find({
    "dataLancamento": {
        "$gte": new Date(1996, 1, 1),
        "$lt": new Date(1999, 1, 1)
    }
})

albuns.forEach(function(album){
    
    print(album["nome"],
        album["artista"]["nome"])
    
})

db.albuns.find({ "artista": {"nome": "Blind Guardian"}})

// desnormalizando tabelas

var metallica = db.artistas.findOne({
    "nome": "Metallica"
})

//db.albuns.count({"artista_id": metallica["_id"]})

db.albuns.update(
    {"artista_id": metallica["_id"]},
    {$set: {"nome_artista": metallica["nome"]}}
)


*/
  

var artistas = db.artistas.find({})
artistas.forEach(function(artista){
    print("Atualizando albuns de ", artista["nome"])
    
})

// pag 37 desnormalizando os dados







