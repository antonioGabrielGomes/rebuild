// show dbs
// use aula
// criar colection
//db.albuns.insert({})

/*
db.albuns.insert({"nome": "The Dark Side of the Moon", "data": new Date(1973, 3, 29)})
db.albuns.insert({"nome" : "Master ofPuppets", "dataLancamento" : new Date(1986, 2, 3), "duracao" : 3286})
db.albuns.insert({"nome" : "...And Justice for All", "dataLancamento" : new Date(1988, 7, 25), "duracao" : 3929})
db.albuns.insert({"nome" : "AmongtheLiving", "produtor" : "Eddie Kramer"})
db.albuns.insert({"nome" : "Nevermind", "artista" : "Nirvana", "estudioGravacao" : ["SoundCity Studios", "SmartStudios(Madison)"], "dataLancamento" : new Date(1992, 0, 11)})
db.albuns.insert({"nome": "Reignin Blood", "dataLancamento" : new Date(1986, 9, 7), "artista" : "Larry Carroll", "duracao" : 1738})
db.albuns.insert({"nome" : "Seventh Son of a Seventh Son", "artista" : "Iron Maiden", "produtor" : "Martin Birch", "estudioGravacao" : "MusiclandStudios", "dataLancamento" : new Date(1988, 3, 11)})
*/

/* 

db.albuns.find({"nome" : "Seventh Son of a Seventh Son"}).pretty()
db.albuns.find({"nome" : /of/})
db.albuns.findOne({"nome" : "Seventh Son of a Seventh Son"})
db.albuns.remove({"nome" : "Seventh Son of a Seventh Son"})
db.albuns.find()

db.albuns.remove({})
db.albuns.find()


db.albuns.update({
     "nome": "AmongtheLiving"   
}, {
     $set: { "duracao": 3013 },
     $set: { "nome":  "Among the Living"}
})

db.albuns.update({
     "nome": "Among the Living"   
}, {
     $set: { "duracao": 3013 }
})

show collections

// menor que
db.albuns.find({
    "duracao": { "$lt" : 1800 } 
})

// entre
db.albuns.find({
    "duracao": { "$in" : [1738,3286] } 
})

// and
db.albuns.find({
    $and : [
        { "dataLancamento" : { $gte: new Date(1986, 0, 1) } },
        { "dataLancamento" : { $lt: new Date(1987, 0, 1) } }
    ]
})

db.albuns.find({
    $and : [
        { "dataLancamento" : { $gte: new Date(1986, 0, 1) } },
        { "dataLancamento" : { $lt: new Date(1987, 0, 1) } }
    ]
})


// RELACIONAMENTOS
db.artistas.insert([ {"nome": "Metallica", "id": 1} ])


*/

db.artistas.find({})


