# FTTH-Fiber-Optic-Network-Design-System
Diploma thesis - plugin to QGIS which automatic creates optic net design by graph algorithms.

This plugin works with RÚIAN data - needs layers adresni_mista and ulice.
