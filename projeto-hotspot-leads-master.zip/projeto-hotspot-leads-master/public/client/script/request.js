(function () {
  'use strict'

  window.addEventListener('load', function () {


    const form = document.querySelector('#form');

    form.addEventListener('submit', async (e) => {

      e.preventDefault()

      // disable btn
      let btn = document.querySelector('#btn_sub')
      btn.disabled = true

      // status message
      let status = document.querySelector('#status')
      status.style.display = 'inline'


      let name = form.querySelector('#name').value
      let email = form.querySelector('#email').value
      let whatsapp = form.querySelector('#whatsapp').value
      let psw = form.querySelector('#psw').value

      // validar whatsapp
      if (!telefone_validation(whatsapp)) {
        alert('Algo está errado com o número de whatsapp.');
        btn.disabled = false
        status.style.display = 'none'
        return false
      }
      // validar name
      if (name.length > 200) {
        alert('Nome muito longo. Tente apenas o primeiro e segundo nome.');
        btn.disabled = false
        status.style.display = 'none'
        return false
      }
      // validar name
      if (email.length > 255) {
        alert('Email muito longo. Tente um email válido.');
        btn.disabled = false
        status.style.display = 'none'
        return false
      }


      await axios.post('/register', {
        name, email, whatsapp, psw
      })
        .then(function (res) {

          let output = document.querySelector('#divForm');
          output.style.display = 'none'
          let signin = document.querySelector('.signin')
          signin.style.height = "600px"

          if (!isNaN(res.data.user))
            createTable({ email, psw }, signin)
          else
            return false
        })
        .catch(function (err) {
          alert(err.response.data.message)
          btn.disabled = false
          status.style.display = 'none'
          //return false
        });


    })
  })





  function createTable(data, el) {
    const table = document.createElement('table')

    const tr1 = document.createElement('tr')
    const th1 = document.createElement('th')
    const th2 = document.createElement('th')

    th1.innerHTML = "Login"
    th2.innerHTML = "Senha"

    tr1.appendChild(th1)
    tr1.appendChild(th2)
    table.appendChild(tr1)

    const tr2 = document.createElement('tr')
    const td1 = document.createElement('td')
    const td2 = document.createElement('td')

    td1.innerHTML = data.email
    td2.innerHTML = data.psw

    tr2.appendChild(td1)
    tr2.appendChild(td2)
    table.appendChild(tr2)

    el.appendChild(table)
  }

  function telefone_validation(telefone) {
    //retira todos os caracteres menos os numeros
    telefone = telefone.replace(/\D/g, '');

    //verifica se tem a qtde de numero correto
    if (!(telefone.length >= 10 && telefone.length <= 11)) return false;

    //Se tiver 11 caracteres, verificar se começa com 9 o celular
    if (telefone.length == 11 && parseInt(telefone.substring(2, 3)) != 9) return false;

    //verifica se não é nenhum numero digitado errado (propositalmente)
    for (var n = 0; n < 10; n++) {
      //um for de 0 a 9.
      //estou utilizando o metodo Array(q+1).join(n) onde "q" é a quantidade e n é o 	  
      //caractere a ser repetido
      if (telefone == new Array(11).join(n) || telefone == new Array(12).join(n)) return false;
    }
    //DDDs validos
    var codigosDDD = [11, 12, 13, 14, 15, 16, 17, 18, 19,
      21, 22, 24, 27, 28, 31, 32, 33, 34,
      35, 37, 38, 41, 42, 43, 44, 45, 46,
      47, 48, 49, 51, 53, 54, 55, 61, 62,
      64, 63, 65, 66, 67, 68, 69, 71, 73,
      74, 75, 77, 79, 81, 82, 83, 84, 85,
      86, 87, 88, 89, 91, 92, 93, 94, 95,
      96, 97, 98, 99];
    //verifica se o DDD é valido (sim, da pra verificar rsrsrs)
    if (codigosDDD.indexOf(parseInt(telefone.substring(0, 2))) == -1) return false;

    /*
    E por ultimo verificar se o numero é realmente válido. Até 2016 um celular pode 
    ter 8 caracteres, após isso somente numeros de telefone e radios (ex. Nextel)
    vão poder ter numeros de 8 digitos (fora o DDD), então esta função ficará inativa
    até o fim de 2016, e se a ANATEL realmente cumprir o combinado, os numeros serão
    validados corretamente após esse período.
    NÃO ADICIONEI A VALIDAÇÂO DE QUAIS ESTADOS TEM NONO DIGITO, PQ DEPOIS DE 2016 ISSO NÃO FARÁ DIFERENÇA
    Não se preocupe, o código irá ativar e desativar esta opção automaticamente.
    Caso queira, em 2017, é só tirar o if.
    */
    //if(new Date().getFullYear() < 2017) return true;
    if (telefone.length == 10 && [2, 3, 4, 5, 7].indexOf(parseInt(telefone.substring(2, 3))) == -1) return false;

    //se passar por todas as validações acima, então está tudo certo
    return true;

  }


}())
