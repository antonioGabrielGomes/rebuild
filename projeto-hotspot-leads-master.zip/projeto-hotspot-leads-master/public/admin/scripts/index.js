

window.lead = new LeadsTableController()  
window.selectbtn = new BtnController()
