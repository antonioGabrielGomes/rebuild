class LeadsTableController {
    'use strict'


    constructor(){


        this.modifiBody(this.createTable())
    }


    modifiBody(html, id_container = 'demo') {

        let container = document.querySelector(`#${id_container}`)
        this.replaceChildBody(container, this.newContainer(html))
        return 'table_leads'

    }

    newContainer(html = '') {
        let div = document.createElement('div')
        // add style

        // content
        if (html !== '')
            div.innerHTML = html

        return div
    }

    replaceChildBody(parent, child) {
        if (parent.childNodes[1]) {
            parent.replaceChild(child, parent.childNodes[1])
        } else {
            parent.appendChild(child)
        }
    }
    
    createTable(){
        return `
        <table class="table table-bordered">

            <thead>
                <tr>
                    <th><button id="all">Tudo</button></th>
                    <th scope="col">#</th>
                    <th scope="col">username</th>
                    <th scope="col">name</th>
                    <th scope="col">email</th>
                    <th scope="col">date_at</th>
                    <th scope="col">whatsapp</th>
                </tr>
            </thead>
            <tbody id='data'>

            </tbody>
        </table>
        `
    }

}