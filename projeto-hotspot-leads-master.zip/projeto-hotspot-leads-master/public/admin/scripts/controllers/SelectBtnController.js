class BtnController {
    'use strict'

    constructor() {
        this._box = false
        this._data = []
        this._buttons = []


        this.readData()
        //this.populateTable()
        this.btn()
    }

    checkBox() {
        let box = null

        box = this._buttons.filter((button) => {
            if (button.children[0].lastChild.checked)
                return button
        })

        if (box.length)
            this._box = false
        else
            this._box = true
    }

    btn() {

        $("#all").click(() => {
            this.checkBox()

            for (let i = 0; i < this._buttons.length; i++) {

                this.changeChecked(i, this._box)

            }


        })

    }

    changeChecked(index = null, checked = this._box) {
        let id = `#lead${index + 1}`

        if (checked) {

            this._buttons[index].children[0].lastChild.checked = true
            $(id).css('background-color', 'red');

        } else {

            this._buttons[index].children[0].lastChild.checked = false
            $(id).css('background-color', 'transparent');

        }

        //if(this._buttons.length < index)

    }

    genBtn() {

        for (let i = 0; i < this._data.length; i++) {
            let id = `#lead${i + 1}`
            let btn = document.querySelector(id)

            btn.addEventListener('click', (el) => {

                btn.children[0].lastChild.checked = !btn.children[0].lastChild.checked

                let checked = btn.children[0].lastChild.checked
                //console.log(id, ": ", btn.children[0].lastChild.checked)   

                if (checked) {
                    $(`#${btn.id}`).css('background-color', 'red');
                } else {
                    $(`#${btn.id}`).css('background-color', 'transparent');
                }

            })

            this._buttons.push(btn)
        }

    }

    populateTable() {
        const tb = document.querySelector("#data")
        let trs = ''

        for (let i = 0; i < this._data.length; i++) {
            let tr = `<tr id="lead${i + 1}" class="lead">
                  <td><input hidden type='checkbox' /></td>
                  <td>${this._data[i].id}</td>
                  <td>${this._data[i].username}</td>
                  <td>${this._data[i].name}</td>
                  <td>${this._data[i].email}</td>		
                  <td>${this._data[i].created_at}</td>
                  <td>${this._data[i].whatsapp}</td>
                </tr>`

            trs += tr

        }

        if (trs != '') {
            tb.innerHTML = trs

            this.genBtn()
        } else
            tb.innerText = 'Not Found'
    }

    async readData() {

        await axios.get('/admin/user/index')
            .then((res) => {               
                this._data = res.data
                this.populateTable()
            })
            .catch((err) => {
                alert(err)
                this.populateTable()
            })

    }

}


