const venom = require('venom-bot');

venom
  .create('hotspot-server')
  .then()
  .catch((erro) => {
    console.log(erro);
  });


