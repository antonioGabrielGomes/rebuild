const express = require('express')
const app = express()
const routes = express.Router()
const cron = require('node-cron')
require('dotenv-safe').config()


//const ScheduleController = require('./controllers/ScheduleController')
//routes.get('/schedule/index', ScheduleController.index)
//routes.put('/schedule/delete/:id', ScheduleController.delete)
const CampaignController = require('./controllers/CampaignController')
const LeadsController = require('./controllers/LeadsController')


app.locals.tasks = []

const tasks = function (req, res, next) {
    const tmp = app.locals.tasks
    app.locals.tasks = tmp

    console.log(tmp)
    
    next();
};

app.use(tasks);


routes.post('/campaign/create', CampaignController.create)
routes.get('/campaign/show', CampaignController.index)
routes.put('/campaign/:id/start', CampaignController.start)

routes.get('/leads/index', LeadsController.index)


app.use(express.json())
app.use(express.static('./src/public'))
app.use(routes)
app.set('x-powered-by', false)

app.listen(process.env.APP_PORT, () => {
    console.log(`Listen server port: ${process.env.APP_PORT}`)
})