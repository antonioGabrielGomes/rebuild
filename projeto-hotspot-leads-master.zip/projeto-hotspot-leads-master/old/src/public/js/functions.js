function replaceChildDemo(parent, child) {
    if (parent.childNodes[1]) {
        parent.replaceChild(child, parent.childNodes[1])
    } else {
        parent.appendChild(child)
    }
}