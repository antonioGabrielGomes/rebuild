
(function () {

    window.addEventListener('load', () => {
    
    
        $("#schedule").click(async () => {
            $("#demo").show();
            $("#demo").empty()
    
    
            const demo = document.querySelector("#demo")
            demo.innerHTML = `
            <br>
                <button id="addSchedule" type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModalCenter">
                Novo</button>
    
                <table class="table">
                    <thead class="thead-dark">
                        <tr>
                        <th scope="col">#</th>
                        <th scope="col">Dias da Semana</th>
                        <th scope="col">Horas</th>
                        <th scope="col">Ações</th>
                        </tr>
                    </thead>
                    <tbody id="tableSchedule">
                    
                    </tbody>
                </table>
            `  
                                                            
    
            /**
            1. Listar agenda existente
            2. Adicionar botão para adicionar novo agendamento
             
             */
            let data = []
            let btns = null
            
            await axios('/schedule/index')
                .then((res) => {
                    data = res.data
                })
                .catch((err) => {
                    console.log(err)
                    //alert(err.response.message)
                })
    
            if(data.length > 0){
    
                let trs = ''
                let count = 0
    
                data.forEach(element => {
                    let { id, 
                        hours,
                        days_week } = element   
                    
                    let days = Array(days_week).join(', ')
                    let hours_ = Array(hours).join(', ')
    
                    let buttons = `<button id="btn${count}" key="${id}" name="no" type="button" class="btn-primary btn-sm btn btn-danger">Deletar</button>` 
                    let tr = 
                            `<tr>
                                    <th class="list-group-item list-group-item-primary" scope="row">${id}</th>
                                    <td>${days}</td>
                                    <td>${hours_}</td>                               
            
                                    <td>
                                        ${buttons}
                                    </td>
            
                                </tr>`
            
                    trs += tr
                    count += 1        
                })
                    
                let tbody = document.querySelector("#tableSchedule")
            
                if (trs != '') {
                    tbody.innerHTML = trs
                    btns = createButtons(data.length)

                    $("#addSchedule").click(() => {
                        createModalAddSchedule()
                    })

                } else {
                    tbody.innerHTML = 'Nenhum Registro nesta sessão.'
                }            
               
            }
    
           
    
        });
    
        $("#campaigns").click(async () => {
            alert("campanhas")
        })

        $("#integration").click(async () => {
            alert("whatsapp")
        })

        $("#leads").click(async () => {
            alert("leads")
        })
    })

    function createButtons(count) {
        let btns = []

        for (let j = 0; count > j; j++) {

            let btn = document.querySelector(`#btn${j}`)
            btn.addEventListener('click', async () => {

                let id = btn.getAttributeNode('key').value

                await axios.put(`/schedule/delete/${id}`)
                    .then(function (res) {
                        alert(res.data.message)
                        window.location.reload()
                    })
                    .catch(function (err) {
                        alert(err.response.data.message)
                    })
            })

            btns.push(btn)
        }

        return btns
    }

    function createModalAddSchedule(){

        let modalDiv = document.querySelector(`#modal`)
        let modal = `
            <div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered" role="document">
                    <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalCenterTitle">Nova Agendamento</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">

                        <form>
                            <div class="form-group">
                            <label for="exampleInputEmail1">Email address</label>
                            <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email">
                            <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
                            </div>
                            <div class="form-group">
                            <label for="exampleInputPassword1">Password</label>
                            <input type="password" class="form-control" id="exampleInputPassword1" placeholder="Password">
                            </div>
                            <div class="form-group form-check">
                            <input type="checkbox" class="form-check-input" id="exampleCheck1">
                            <label class="form-check-label" for="exampleCheck1">Check me out</label>
                            </div>
                            <button type="submit" class="btn btn-primary">Submit</button>
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        </form>


                    </div>
                  
                    </div>
                </div>
            </div>
        `
        modalDiv.innerHTML = modal
       // $("#modal").hide()

    }

    

    

})()



  