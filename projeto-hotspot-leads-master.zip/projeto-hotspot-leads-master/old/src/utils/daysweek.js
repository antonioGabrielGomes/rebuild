module.exports = {

    dw(start, end) {
        
        if (start != '' && end != '') {
            const n = parseInt(start)
            const m = parseInt(end)

            if (isNaN(start) || isNaN(end))
                return null

            if ((n < 0 || n >= 7) || (m < 0 || m >= 7))
                return null

            if (m <= n)
                return null

            return `${start},${end}`
        } else if (start != '') {
            const n = parseInt(start)

            if (isNaN(start))
                return null

            if (n < 0 || n >= 7)
                return null

            return start
        } else {
            return null
        }

    },

    m(start, end) {

        if (start != '' && end != '') {
            const n = parseInt(start)
            const m = parseInt(end)

            if (isNaN(start) || isNaN(end))
                return null

            if ((n < 1 || n > 12) || (m < 1 || m > 12))
                return null

            if (m <= n)
                return null

            return `${start}-${end}`
        } else if (start != '') {
            const n = parseInt(start)

            if (isNaN(start))
                return null

            if (n < 1 || n > 12)
                return null

            return start
        } else {
            return null
        }

    }

}


/**
 * 
 * criar todo os intervalos permitidos
 Allowed values
field 	value
second 	0-59
minute 	0-59
hour 	0-23
day of month 	1-31
month 	1-12 (or names)
day of week 	0-7 (or names, 0 or 7 are sunday)


0 dom
1 seg
2 ter
3 qua
4 qui
5 sex
6 sab


 */