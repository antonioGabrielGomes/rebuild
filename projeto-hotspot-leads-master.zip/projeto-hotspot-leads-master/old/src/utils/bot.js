const { create } = require('@open-wa/wa-automate')

class Bot {

    launchConfig = {
        useChrome: true,
        autoRefresh: true,
        cacheEnabled: false,
        sessionId: 'hr',
        headless: false
    }

    async launch(data) {
        await create(this.launchConfig).then(client => {

            client.sendText('559180629694@c.us', `${data.title}\n${data.message}`);

        })

    }
}

module.exports = new Bot()






