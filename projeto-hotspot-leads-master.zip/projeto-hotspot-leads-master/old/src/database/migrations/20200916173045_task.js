
exports.up = function(knex) {
  return knex.schema.createTable('task', table => {
    table.integer('campaign_id').unsigned()
    table.foreign('campaign_id').references('campaign_id')
  })
};

exports.down = function(knex) {
  return knex.schema.dropTable('task')
};
