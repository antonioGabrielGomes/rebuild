
exports.up = function(knex) {
  return knex.schema.createTable('campaign', table => {
      table.increments("id")
      table.string("title", 100).notNull()
      table.string("message", 255).notNull()
      table.string("image", 200).defaultTo(null)
      table.string("url", 255).defaultTo(null)
      table.boolean('active').defaultTo(true)
      table.boolean('start').defaultTo(false)      
      table.string("days_week", 50).notNull()
      table.string("days_month", 50).notNull()
      table.string("hours", 50).notNull()
      table.timestamp('created_at').defaultTo(knex.fn.now());
  })
};


exports.down = function(knex) {
  return knex.schema.dropTable('campaign')
};
