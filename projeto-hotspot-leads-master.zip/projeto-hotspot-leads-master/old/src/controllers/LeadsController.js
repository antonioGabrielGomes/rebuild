const connection = require('../database/connection')

const leads = require('../leads/leads.json')


module.exports = {

    async index(req, res) {

        try {
            res.json(leads)
        } catch (error) {
            res.json({ message: 'Nenhum lead encontrado.' })
        }

    }

}