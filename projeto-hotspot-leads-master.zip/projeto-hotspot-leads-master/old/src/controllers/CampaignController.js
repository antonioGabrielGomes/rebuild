const connection = require('../database/connection')
const cron = require('node-cron')
const daysweek = require('../utils/daysweek')
const bot = require('../utils/bot')


module.exports = {

    async create(req, res) {
        const {
            title,
            message,
            url,
            day_week_start,
            day_week_end,
            month_start,
            month_end,
            hours,
            // image
        } = req.body



        try {
            // clear hours
            if (isNaN(hours) || (parseInt(hours) < 0 || parseInt(hours) > 23))
                res.status(400).json({ message: 'Valores incorretos para o horário escolhido.' })

            const days_week = daysweek.dw(day_week_start, day_week_end)
            const days_month = daysweek.m(month_start, month_end)

            if (!days_week)
                res.status(400).json({ message: 'Valores incorretos para dias da semana.' })
            else if (!days_month)
                res.status(400).json({ message: 'Valores incorretos para o mês.' })
            else {
                const [id] = await connection('campaign')
                    .insert({
                        title,
                        message,
                        url,
                        days_week,
                        days_month,
                        hours,
                    })

                res.json({ message: "Campanha cadastrada!", id })
            }
        } catch (error) {
            console.log(error)
            res.status(400).json({ message: 'Erro de conexão com servidor. Tente novamente ou mais tarde.' })
        }
    },

    async index(req, res) {
        try {
           
            const result = await connection('campaign')
                .select("*")

            res.json(result)
        } catch (error) {
            console.log(error)
            res.status(400).json({ message: 'Erro de conexão com servidor. Tente novamente ou mais tarde.' })
        }
    },
 
    async start(req, res) {
        const { id } = req.params

        if (isNaN(parseInt(id))) {
            console.log(`Id ${id} não é um número válido.`)
            res.status(400).json({ message: 'Parametro Inválido.' })
        }

        try {
            // buscar campanha
            const resp = await connection('campaign')
                .where({
                    id: id,
                    active: 1
                })
                .select('*')
                .first()

            if (!resp)
                res.status(400).json({ message: 'Campanha não encontrada.' })

            if (resp.start === 1)
                res.status(400).json({ message: 'A campanha selecionada já foi iniciada.' })

            // atualizar campanha
            await connection('campaign')
                .where('id', '=', id)
                .update({
                    start: 1
                })
            
            const expression = `* ${resp.hours} * ${resp.days_month} ${resp.days_week}`
            //const expression = `* * * ${resp.days_month} ${resp.days_week}`


            const task = cron.schedule(expression, async () => {

                const resp_task = await connection('campaign')
                    .where({
                        id: id,
                        active: 1
                    })
                    .select('*')
                    .first()
                
                if(resp_task.start == 1){
                    console.log(`Rodando Tarefa ${expression}`)
                    //
                    await bot.launch(resp_task)
                }else{
                    console.log('task cancel')
                }
                                
            })


            const tasks = req.tasks

            tasks.push(tasks)
            req.tasks = { tasks, id }

            res.json({ message: 'Campanha Iniciada.' })
        } catch (error) {
            console.log(error)
            res.status(400).json({ message: 'Erro de conexão com servidor. Tente novamente ou mais tarde.' })
        }

    },
  
    
   

}