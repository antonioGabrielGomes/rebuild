require('dotenv-safe').config()

module.exports = {

  production: {
    client: 'mysql',
    connection: {
      host: process.env.APP_DB_HOST,
      port: process.env.APP_DB_PORT,
      user: process.env.APP_DB_USER,
      password: process.env.APP_DB_PASSWORD,
      database: process.env.APP_DB_NAME,
    },
    pool: {
      min: 2,
      max: 10,
    },
    migrations: {
      directory: './src/database/migrations'
    },
    useNullAsDefault: true 
  },

  development: {
    client: 'mysql',
    connection: {
      host: 'localhost',
      port: 3306,
      user: 'root',
      password: '0b63fbb35e41b52c5fd330a755fbe06df110a78e948e32b478fdbb84dccf33e88055e0dd446747bdbde98122bd6344f951132d61b618',
      database: 'hotspot_dev',
    },
    pool: {
      min: 2,
      max: 10,
    },
    migrations: {
      directory: './src/database/migrations'
    }
  }

};
