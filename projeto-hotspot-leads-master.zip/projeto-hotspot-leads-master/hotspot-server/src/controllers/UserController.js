const connection = require('../database/connection')

module.exports = {

    async index(req, res){

        try {

            const users = await connection('user')
                .select('*')
            
            res.json(users)
        } catch (error) {
            console.log(error)
            res.status(401).json({ 
                message: "Sem conexão com servidor"
            })
        }

    }

}