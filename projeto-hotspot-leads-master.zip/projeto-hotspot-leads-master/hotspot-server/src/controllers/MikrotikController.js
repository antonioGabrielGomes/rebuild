const bcrypt = require('bcrypt')
const connection = require('../database/connection')
const phone = require('../utils/validator_cellphone')
const MkConn = require('../api/mikrotik.json')

const bot = require('../utils/bot')


const MikroNode = require('mikronode')
const device = new MikroNode(MkConn.address);

module.exports = {

    async register(req, res) {

        const { name, email, whatsapp, psw } = req.body
        let username = name.replace(/\s/g, '')
        
        let telephone = phone(whatsapp)
        //console.log(whatsapp)
        //console.log(telephone)
        //return res.json(true)

        try {
            if (!telephone)
                return res.status(400).json({ message: "Número inválido." })


            const msg = `Olá ${name}, Seja Bem Vindo(a)!\nPara acessar o a rede utilize seu email e senha de cadastro.\n${email}\n${psw}\nObs.: Acesso único. `
            const client = req.client

            // await validation profile number
            await client.getNumberProfile(`55${telephone}@c.us`)
                .then(r => {
                    if (r.status != 200)
                        return res.status(404).json({ message: 'Número inválido.' })
                })
                .catch(err => {
                    console.log(err)
                    return res.status(404).json({ message: "Número inválido." })
                })


            if (name == '' || email == '' || psw == '')
                return res.status(400).json({ message: "Preencha todos os campos." })
            else if (name.length > 200 || email.length > 255)
                return res.status(400).json({ message: "Quantidade de caracteres inválida." })


            const user = await connection('user')
                .where('email', email)
                .orWhere('whatsapp', telephone)
                .select('*')
                .first()

            let resp = null

            if (user)
                return res.status(400).json({ message: "E-mail ou Whatsapp já utilizado." })
            else {

                // send data to client
                await client.sendText(`55${telephone}@c.us`, msg)
                    .catch(err => {
                        console.log(err)
                        return res.status(404).json({ message: "Número inválido." })

                    })

                //



                // encrypt password
                const salt = bcrypt.genSaltSync()
                const hash = bcrypt.hashSync(psw, salt)

                resp = await connection('user')
                    .insert({
                        username,
                        name,
                        email,
                        whatsapp: telephone,
                        password: hash
                    })

                await device.connect()
                    .then(([login]) => login(MkConn.user, MkConn.password))
                    .then((conn) => {
                        conn.closeOnDone(true);
                        const listenChannel = conn.openChannel("listen");

                        const actionChannel = conn.openChannel("action", false);

                        actionChannel.sync(false);
                        actionChannel.closeOnDone(false);

                        actionChannel.write('/ip/hotspot/user/add', {
                            'name': email,
                            'password': psw,
                            'comment': telephone,
                            'server': 'hotspot1'
                        }).then(results => {

                            const { promise, resolve, reject } = MikroNode.getUnwrappedPromise();
                            listenChannel.data
                                .take(1)
                                // This is just to prove that it grabbed the first one.
                                .do(d => console.log("Data:", MikroNode.resultsToObj(d.data)))
                                .subscribe(d => actionChannel.write('/ip/hotspot/user/add', {
                                    'name': email,
                                    'password': psw,
                                    'comment': telephone,
                                    'server': 'hotspot1'
                                }).then(resolve, reject))

                            return promise;
                        })
                            .catch((error) => {
                                console.log("An error occurred during one of the above commands: ", error);
                                return res.status(400).json({ message: 'Erro no servidor, Tente outra vez ou mais tarde.' })
                            })
                            .then((nodata) => {
                                listenChannel.close(true);
                                actionChannel.close();

                            });

                    })

            }

            return res.json({ message: 'Usuário cadastrado.', user: resp })

        } catch (error) {
            console.log(error)
            return res.status(400).json({ message: 'Erro no servidor, Tente outra vez ou mais tarde.' })

        }


    }

}


