const venom = require('venom-bot')
const fs = require('fs')
const path = require('path')

class bot {

    constructor() {
        this._client = null
    }


    async send(from = null, message = "Std Message Error: Null") {
        await this._client.sendText(`55${from}@c.us`, message)
            .then((r) => {
                
            })
            .catch(err => {
                console.log(err)
                throw new Error('Número Inválido')
            })
    }

    async retrieveProfile(from = null) {
        await this._client.getNumberProfile(`55${from}@c.us`)
            .then(() => {
                return true
            })
            .catch(err => {
                console.log(err)
                throw new Error('Número Inválido')
            })
    }


}


module.exports = new bot()