require('dotenv-safe').config()
const express = require('express')
const cors = require('cors')
const app = express()
//const bodyParser = require('body-parser')
const port = process.env.APP_PORT || 5000
const route = require('./routes')

app.use(cors())
app.use(express.json())
//app.use(express.urlencoded({ extended: false, limit: '2gb' }));

//app.use(express.static('./src/public'))
app.use(route)
app.set('x-powered-by', false)


app.listen(port, () => console.log(`Hotspot server listen port: ${port}`))
