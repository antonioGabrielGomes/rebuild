const express = require('express');
const venom = require('venom-bot')
const fs = require('fs')
const path = require('path')

const router = express.Router();

const bot = require('./utils/bot')


/** controllers */
const MikrotikController = require('./controllers/MikrotikController')
const UserController = require('./controllers/UserController')
/**  */

/** client hotspot */
router.post('/register', (req, res, next) => {

    if (bot._client) {

        req.client = bot._client

        return next()
    } else {
        return res.status(400).json({ message: 'Não foi possível continuar o cadastro, tente novamente ou mais tarde. ' })
    }

}, MikrotikController.register);
/** */

/** admin */
//router.get('/admin/user/index', UserController.index)

/** router tmp */
router.get('/admin/integration/whatsapp', async (req, res) => {
    const { cod } = req.body

    try {

        if (cod !== 'hex193'){
            return res.send(false)
        }

        await venom
            .create(
                'hotspot-server',
                (base64Qr, asciiQR) => {

                    return res.json(true)
                },
                (statusSession) => {
                    //console.log(statusSession)
                },
                {
                    useChrome: true,
                    logQR: false,
                    disableWelcome: true,
                    autoClose: 120000,
                    //refreshQR: 60000
                }
            )
            .then(client => {
                bot._client = client
            })
            .catch(err => {
                console.log(err)
                throw new Error('Whatsapp Integration Failed: ', err)
            })

            return res.json(true)

    } catch (err) {
        console.log(err)
        return res.status(400).json(err)
    }
})

/** 
router.get('/admin/integration/whatsapp/launch', async (req, res) => {


    try {

        await venom
            .create(
                'hotspot',
                (base64Qr, asciiQR) => {

                    //console.log(asciiQR)

                    //const imgPath = `${path.resolve(__dirname, '..', 'output')}/qrcode.png`

                    //base64Qr = base64Qr.replace('data:image/png;base64,', '');
                    //const imageBuffer = Buffer.from(base64Qr, 'base64');
                    //fs.writeFileSync(imgPath, imageBuffer);


                    //res.setHeader('Content-disposition', `attachment; filename=${imgPath}`)
                    //res.setHeader('Content-type', 'png')

                    //const filestream = fs.createReadStream(imgPath);
                    //filestream.pipe(res)
                    //res.setHeader('keep-Alive', `timeout=12, max=5`)


                    res.json({ base64Qr })
                },
                (statusSession) => {
                    //console.log(statusSession)
                },
                {
                    useChrome: true,
                    logQR: false,
                    disableWelcome: true,
                    autoClose: 120000,
                    //refreshQR: 60000
                }
            )
            .then(client => {
                bot._client = client
            })
            .catch(err => {
                console.log(err)
                throw new Error('Whatsapp Integration Failed: ', err)
            })


    } catch (err) {
        console.log(err)
        res.status(400).json(err)
    }
})

*/




module.exports = router;