#!python3

# print('Seja bem vindo!')
# import pacote.sub.arquivo

# import tipos.variaveis
# from tipos import basicos
# import tipos.lista
# import tipos.conjuntos
# import tipos.dicionarios

# import operadores.unarios
import operadores.aritmeticos