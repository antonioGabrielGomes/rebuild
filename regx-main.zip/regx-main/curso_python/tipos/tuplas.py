nomes = ("Ana", "Bia", "Gui", "Carla")

print(type(nomes))
# print('nome 1' in nomes)
print(nomes[:-2])