#!python3

print(type(1))
print(type(1.1))
print(type('abcd'))
print(type(False))

