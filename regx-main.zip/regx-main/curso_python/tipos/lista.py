nums = [1, 2, 3]
print(type(nums))
nums.append(4)
nums[3] = 100

print(nums[-1])
