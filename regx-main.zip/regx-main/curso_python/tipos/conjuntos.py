print(type({1,2,3,4}))

conj = {1,2,3,4,4,4,4,44}
print(conj)
print(len(conj))