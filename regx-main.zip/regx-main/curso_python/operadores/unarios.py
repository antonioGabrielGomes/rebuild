y = 4

print(not False)
print(not True)
print(--3)
print(--y)
print(+3)

