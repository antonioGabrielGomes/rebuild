#include "regex.h"
#include "stdio.h"

int main(){

    printf("%s", "Olá C");

    return 0;
}