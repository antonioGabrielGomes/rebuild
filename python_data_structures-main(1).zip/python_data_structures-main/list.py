num = [5, 4, 3, 2]
 
for i in range(len(num)):
 print(num[i])


