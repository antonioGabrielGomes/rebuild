# tool-log

## Descrição:
<p>Ferramenta para renomear pontos no mapa kml; converter as coordenadas (geo para utm) dos pontos no mapa kml.</p>

<p>Após baixar, entre no diretório ../tool-log/ e digite (no linux): $ sudo npm link</p>
 
## Uso

### Usage: tool-log [options] [command]

### Options:
###  -V, --version   output the version number
###  -h, --help      display help for command

### Commands:
###  renome [file]   add file to rename points
###  convert [file]  add file for coordinate conversion
###  convert-fuso [options] [file]  add file for fuso conversion
###  help [command]  display help for command


