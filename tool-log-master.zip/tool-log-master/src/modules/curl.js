const shell = require('shelljs')

const execCurl = (lat, lon) => {
    //const query = "curl  -s --request POST --data 'proj_out=utm&DATUM_OUT=4&Y="+lat+"&X="+lon+"&DATUM=4&PRJIN=latlong_gd&TYCORD=latlong_gd&Avan%E7ar=Avan%E7ar'  http://www.dpi.inpe.br/calcula/result.php"
    //const query = `curl.exe  -s -v --request POST --data proj_out=utm&DATUM_OUT=4&Y=${lon}&X=${lat}+&DATUM=4&PRJIN=latlong_gd&TYCORD=latlong_gd&Avan%E7ar=Avan%E7ar  http://www.dpi.inpe.br/calcula/result.php`
    //console.log(query)
    //`proj_out=utm&DATUM_OUT=4&Y=${lon}&X=${lat}+&DATUM=4&PRJIN=latlong_gd&TYCORD=latlong_gd&Avan%E7ar=Avan%E7ar`
    // proj_out=utm&DATUM_OUT=4&Y=-48.43960281&X=-1.35902866+&DATUM=4&PRJIN=latlong_gd&TYCORD=latlong_gd&Avan%E7ar=Avan%E7ar


    const command = shell.exec(`curl -s --request POST --data "proj_out=utm&DATUM_OUT=4&Y=${lat}&X=${lon}+&DATUM=4&PRJIN=latlong_gd&TYCORD=latlong_gd&Avan%E7ar=Avan%E7ar"  http://www.dpi.inpe.br/calcula/result.php`, { silent: true })
    
    return command
}

module.exports = execCurl
