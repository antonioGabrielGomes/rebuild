#!/usr/bin/env node

const program = require('commander')
const { join } = require('path')
const fs = require('fs')
const inquirer = require('inquirer')
const chalk = require('chalk')

//const shell = require('shelljs');
const tokml = require('tokml')
const html2json = require('html2json').html2json
//const htmlToJson = require('html-to-json')
//const json2xlsx = require('node-json-xlsx')
const csvToJson = require('convert-csv-to-json');
const converter = require('json-2-csv')

const togeojson = require('./modules/convert')
const execCurl = require('./modules/curl')

const package = require('../package.json')
const logPath = join(__dirname, 'log.json')



const getJson = (path) => {
    const data = fs.existsSync(path) ? fs.readFileSync(path) : []
    try {
        return JSON.parse(data)
    } catch (e) {
        return []
    }
}
const saveJson = (path, data) => fs.writeFileSync(path, JSON.stringify(data, null, '\t'));

program.version(package.version)

program
    .command('renome [file]')
    .description('add file to rename points')
    .action(async (file) => {
        let answers
        if (!file) {
            answers = await inquirer.prompt([
                {
                    type: 'input',
                    name: 'renome',
                    message: 'Whats your file?',
                    validate: value => value ? true : 'You need to pass the file name!'
                }
            ])
        }


        /**
         * 
         */

        const stdout = togeojson(file)
        const objGeoJson = JSON.parse(stdout)

        for (let index = 0; index < objGeoJson.features.length; index++) {
            objGeoJson.features[index].properties['name'] = "P" + index
            //let point = objGeoJson.features[index].properties['name']            
            // point to verbose add
        }

        const kml = tokml(objGeoJson)
        const fileNameKml = 'tool-log-renome.kml'
        fs.writeFileSync(fileNameKml, kml)


        /**
          * 
          */


        const data = getJson(logPath)
        data.push({
            title: "renome-point",
            done: false,
            date: new Date,
            name_file: file || answers.file
        })
        saveJson(logPath, data)
        console.log(`${chalk.green('### rename points done ###')}`)
    })


program
    .command('convert [file]')
    .description('add file for coordinate conversion')
    .action(async (file) => {
        let answers
        if (!file) {
            answers = await inquirer.prompt([
                {
                    type: 'input',
                    name: 'file',
                    message: 'Whats your file?',
                    validate: value => value ? true : 'You need to pass the file name!'
                }
            ])
        }

        /**
         * 
         */

        const stdout = togeojson(file)
        const objGeoJson = JSON.parse(stdout)

        for (let index = 0; index < objGeoJson.features.length; index++) {

            let lat = objGeoJson.features[index].geometry.coordinates[1]
            let lon = objGeoJson.features[index].geometry.coordinates[0]

            let request = execCurl(lat, lon)

            json = html2json(request.stdout)

            let lonUtm = json.child[0].child[3].child[25].child[0].child[1].child[0].text
            let latUtm = json.child[0].child[3].child[41].child[0].child[1].child[0].text

            objGeoJson.features[index].geometry.coordinates[1] = latUtm
            objGeoJson.features[index].geometry.coordinates[0] = lonUtm

        }


        //const fileNameExel =  'tool-log-convert.xlsx'        
        //const xls = json2xls(str)                             
        //const xlsx = json2xlsx(objGeoJson, opts);

        const fileJsonProvisorio = 'tool-log-convert-provisorio.json'
        fs.writeFileSync(fileJsonProvisorio, JSON.stringify(objGeoJson));

        /**
          * 
          */

        const data = getJson(logPath)
        data.push({
            title: "geo-to-utm",
            done: false,
            date: new Date,
            name_file: file || answers.file
        })
        saveJson(logPath, data)
        console.log(`${chalk.green('### convert points done ###')}`)
    })

program
    .command('convert-fuso [file]')
    .description('add file for fuso conversion')
    .option('-l, --legacy [legacy]', 'date legacy')
    .action(async (file, options) => {

        let answers

        if (!file) {
            answers = await inquirer.prompt([
                {
                    type: 'input',
                    name: 'file',
                    message: 'Whats your file?',
                    validate: value => value ? true : 'You need to pass the file name!'
                }
            ])
        }

        const stdout = csvToJson.getJsonFromCsv(file)

        for(let i=0; i<stdout.length; i++){

        	if(options.legacy === 'true'){


				const d = stdout[i].datahora
				const arr = d.split('/')
				const y = arr[2].split(' ')
				const date = y[0]+'-'+arr[1]+'-'+arr[0]+' '+y[1]+':0.0'+ ' GMT'

				const input = Date.parse(date)   
				const start = new Date(input)
				const event = new Date(Date.UTC(start.getFullYear(), start.getMonth(), start.getDate(),
				 start.getHours(), start.getMinutes(), start.getSeconds(), start.getMilliseconds()))
								
				stdout[i].datahora = event.toUTCString()



        	}else{

	            let date = Date.parse(stdout[i].datahora + ' GMT');
	            let start = new Date(date)
	            let event = new Date(Date.UTC(start.getFullYear(), start.getMonth(), start.getDate(), 
	            	start.getHours(), start.getMinutes(), start.getSeconds(), start.getMilliseconds()))
	                        
	            stdout[i].datahora = event.toUTCString()

            }
			//stdout[i].valorMedida = parseFloat(stdout[i].valorMedida)
			//console.log(stdout[i].valorMedida)		
        }

        //file
        const fileOut = 'tool-log-3.ods' 
		const fields = ['municipio','codEstacao','uf','nomeEstacao','latitude','longitude','datahora','valorMedia']
        const opts = { fields }
        
        let json2csvCallback = function(err, csv){
            if(err) throw err;
            fs.writeFileSync(fileOut, csv);
        }

        converter.json2csv(stdout, json2csvCallback)

 
        const data = getJson(logPath)
        data.push({
            title: "change schedule",
            done: false,
            date: new Date,
            name_file: file || answers.file
        })
        saveJson(logPath, data)
        console.log(`${chalk.green('### change schedule done ###')}`)

    })

program.parse(process.argv)


			// path para resolver
			/*
const d = "26/11/2013 15:10"
const arr = d.split('/')
const y = arr[2].split(' ')
const date = y[0]+'-'+arr[1]+'-'+arr[0]+' '+y[1]+':0.0'

const input = Date.parse(date)   
const start = new Date(input)
const event = new Date(Date.UTC(start.getFullYear(), start.getMonth(), start.getDate(), start.getHours(), start.getMinutes(), start.getSeconds(), start.getMilliseconds()))
console.log(event)           

			*/
