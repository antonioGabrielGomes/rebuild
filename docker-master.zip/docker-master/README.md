# docker

### configurações docker-composer com pg e pgadmin
![Alt text](db-pg-pgadmin.png?raw=true "pgadmin4 com banco de dados")

### configurações jupiter-notebook
![Alt text](jupiter.png?raw=true "pgadmin4 com banco de dados")
