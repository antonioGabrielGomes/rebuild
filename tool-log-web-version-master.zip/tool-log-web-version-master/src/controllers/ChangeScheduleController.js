const path = require('path')
const mime = require('mime')

const csvToJson = require('convert-csv-to-json');
const converter = require('json-2-csv')

const logs = require('../modules/logs')
const io = require('../modules/io')


class ChangeSchedule {

    async store(req, res) {
        const { datafile, filename, datelegacy } = req.body

        /** return format array */
        const arr = filename.split('.') // split name file and extension

        /** save data to a file on the server to inform the conversion library  */
        const saveCsvInLog = `${path.resolve(__dirname, '..', '..', 'logs')}/${Date.now()}-${arr[0]}.${arr[1]}`
        io.write(saveCsvInLog, datafile, 'csv')

        /** convert csv in json */
        const jsonData = csvToJson.getJsonFromCsv(saveCsvInLog)

        for (let i = 0; i < jsonData.length; i++) {

            if (datelegacy) {

                // adicionar try catch para validar se realmente estamos podendo fazer o split da data - 
                // se não coseguirmos, deletar o file do server e retornar um error

                const d = jsonData[i].datahora
                const arr = d.split('/')
                const y = arr[2].split(' ')
                const date = y[0] + '-' + arr[1] + '-' + arr[0] + ' ' + y[1] + ':0.0' + ' GMT'

                const input = Date.parse(date)
                const start = new Date(input)
                const event = new Date(Date.UTC(start.getFullYear(), start.getMonth(), start.getDate(),
                    start.getHours(), start.getMinutes(), start.getSeconds(), start.getMilliseconds()))

                jsonData[i].datahora = event.toUTCString()

            } else {

                let date = Date.parse(jsonData[i].datahora + ' GMT');
                let start = new Date(date)
                let event = new Date(Date.UTC(start.getFullYear(), start.getMonth(), start.getDate(),
                    start.getHours(), start.getMinutes(), start.getSeconds(), start.getMilliseconds()))

                jsonData[i].datahora = event.toUTCString()

            }

        }

        /** file options csv */
        //const fields = ['municipio', 'codEstacao', 'uf', 'nomeEstacao', 'latitude', 'longitude', 'datahora', 'valorMedia']
        //const opts = { fields }

        /** delete data saveCsvInLog */
        io.delete(saveCsvInLog)

        /** path/filename.kml */
        const resultPath = `${path.resolve(__dirname, '..', '..', 'logs')}/${Date.now()}-${arr[0]}.${arr[1]}`

        /** callback to converter json to csv */
        const json2csvCallback = (err, csv) => {
            try {
                /** save file */
                io.write(resultPath, csv, 'csv')

                /** check format return stream */
                const mimetype = mime.getType(resultPath)
                res.setHeader('Content-disposition', `attachment; filename=${resultPath}`);
                res.setHeader('Content-type', mimetype);

                const filestream = io.stream(resultPath)
                filestream.pipe(res);

                /** delete file in the server */
                io.delete(resultPath)

            } catch (err) {
                console.log(err)
            }
            //if (err) throw err;
            //fs.writeFileSync(fileOut, csv);
        }

        /** generate output file */
        converter.json2csv(jsonData, json2csvCallback)


        /** save request */
        const log = {
            name_file: filename,
            name_file_server: `${Date.now()}-${arr[0]}.csv`,
            data: new Date,
            address: req.connection.remoteAddress,
            browser: req.headers["user-agent"],
            description: 'Change Schedule'
        }
        logs.logService(log)
    }
}


module.exports = new ChangeSchedule()