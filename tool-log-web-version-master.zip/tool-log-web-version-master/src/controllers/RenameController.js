const path = require('path')
const mime = require('mime')

const tokml = require('tokml')
const togeojson = require('../modules/convert')

const logs = require('../modules/logs')
const io = require('../modules/io')

class RenameController {

    async store(req, res) {
        const { points, filename } = req.body

        /** converte point kml to geojson format e parse Json */
        const jsonPoints = JSON.parse(togeojson(points))

        /** generate names to properties in jsonPoints */
        for (let index = 0; index < jsonPoints.features.length; index++) {
            jsonPoints.features[index].properties['name'] = "P" + index
        }

        /** return format kml */
        const kml = tokml(jsonPoints)

        const arr = filename.split('.') // split name file and extension

        /** path/filename.kml */
        const resultPath = `${path.resolve(__dirname, '..', '..', 'logs')}/${Date.now()}-${arr[0]}.${arr[1]}`

        io.write(resultPath, kml, 'kml')

        /** check format return stream */
        const mimetype = mime.getType(resultPath)
        res.setHeader('Content-disposition', `attachment; filename=${resultPath}`);
        res.setHeader('Content-type', mimetype);

        const filestream = io.stream(resultPath)
        filestream.pipe(res);

        /** save request */
        const log = {
            name_file: filename,
            name_file_server: `${Date.now()}-${arr[0]}.${arr[1]}`,
            data: new Date,
            address: req.connection.remoteAddress,
            browser: req.headers["user-agent"],
            description: 'Rename Points'
        }
        logs.logService(log)
        
        /** delete file in the server */
        io.delete(resultPath)
    }

}

module.exports = new RenameController()