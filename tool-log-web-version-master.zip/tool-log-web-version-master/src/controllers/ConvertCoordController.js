const path = require('path')
const mime = require('mime')

//const converter = require('json-2-csv')
const togeojson = require('../modules/convert')

const logs = require('../modules/logs')
const io = require('../modules/io')
const calcula_inpe = require('../modules/calcula_inpe')

const html2json = require('html2json').html2json


class ConvertCoordController {

    async store(req, res) {
        const { points, filename } = req.body
        
        /** converte point kml to geojson format e parse Json */
        const jsonPoints = JSON.parse(togeojson(points))

        /**  */
        for (let index = 0; index < jsonPoints.features.length; index++) {

            let lat = jsonPoints.features[index].geometry.coordinates[1]
            let lon = jsonPoints.features[index].geometry.coordinates[0]

            /**
            if(isNaN(lat) || isNaN(lon))
                return ERROR
           
            //    Latitude : max/min +90 até -90
            //    Longitude : max/min +180 até -180
            */

            const request = calcula_inpe(lat, lon)             
            const json = html2json(request.stdout)

            let lonUtm = json.child[0].child[3].child[25].child[0].child[1].child[0].text
            let latUtm = json.child[0].child[3].child[41].child[0].child[1].child[0].text

            jsonPoints.features[index].geometry.coordinates[1] = latUtm
            jsonPoints.features[index].geometry.coordinates[0] = lonUtm

        }

        /** split name file and extension */
        const arr = filename.split('.')

        /** path/filename.csv */
        const resultPath = `${path.resolve(__dirname, '..', '..', 'logs')}/${Date.now()}-${arr[0]}.json`
      
        /** callback to converte json to csv 

        const json2csvCallback = (err, csv) => {
            try {
                /** save file 
                io.write(resultPath, csv, 'csv')

                /** check format return stream 
                const mimetype = mime.getType(resultPath)
                res.setHeader('Content-disposition', `attachment; filename=${resultPath}`);
                res.setHeader('Content-type', mimetype);

                const filestream = io.stream(resultPath)
                filestream.pipe(res);

                /** delete file in the server
                io.delete(resultPath)

            } catch (err) {
                console.log(err)
            }
            //if (err) throw err;
            //fs.writeFileSync(fileOut, csv);
        }
        */
        ///** generate output file csv */
        //converter.json2csv(jsonPoints.features, json2csvCallback)
        //console.log(jsonPoints.features)

        io.write(resultPath, jsonPoints)

        /** check format return stream */
        const mimetype = mime.getType(resultPath)
        res.setHeader('Content-disposition', `attachment; filename=${resultPath}`)
        res.setHeader('Content-type', mimetype)

        const filestream = io.stream(resultPath)
        filestream.pipe(res)

        /** save request  */ 
        const log = {
            name_file: filename,
            name_file_server: `${Date.now()}-${arr[0]}.json`,
            data: new Date,
            address: req.connection.remoteAddress,
            browser: req.headers["user-agent"],
            description: 'Convert Coord'
        }
        logs.logService(log)
      

        /** delete file in the server */
        io.delete(resultPath)
    }

}

module.exports = new ConvertCoordController()