
class Sessao {

    async create(req, res){
        
    }

}

module.exports = new Sessao()