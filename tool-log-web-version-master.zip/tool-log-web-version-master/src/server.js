const express = require('express')
const app = express()
//const bodyParser = require('body-parser')
const port = process.env.PORT || 3000
const route = require('./routes')


app.use(express.json({ limit: "1mb" }))
//app.use(express.urlencoded({ extended: false, limit: '2gb' }));
//app.use(bodyParser.urlencoded({ extended: false, limit: "200kb" })) 
//app.use(bodyParser.json({ limit: '200kb' }))

app.use(express.static('./src/public'))
app.use(route)
app.set('x-powered-by', false)


app.listen(port, () => console.log(`Tool-log listen port: ${port}`))
