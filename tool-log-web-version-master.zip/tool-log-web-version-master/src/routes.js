const express = require('express');
const router = express.Router();

/** controllers */
const RenameController = require('./controllers/RenameController')
const ChangeScheduleController = require('./controllers/ChangeScheduleController')
const ConvertCoordController = require('./controllers/ConvertCoordController')

router.post('/renome_points', RenameController.store);
router.post('/change_schedule', ChangeScheduleController.store)
router.post('/convert_coord', ConvertCoordController.store)


module.exports = router;
