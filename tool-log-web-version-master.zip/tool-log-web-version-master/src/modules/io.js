const fs = require('fs')

module.exports = {

    reader(path) {
        try {
            const data = fs.existsSync(path) ? fs.readFileSync(path) : []
            return JSON.parse(data)
        } catch (err) {
            return []
            console.error(err)
        }
    },

    write(path, data, format = null) {  // (kml or other) and json
        try {

            if (!format)
                fs.writeFileSync(path, JSON.stringify(data, null, '\t'))
            else
                fs.writeFileSync(path, data);

            return 0
        } catch (err) {
            return 1
            console.error(err)
        }
    },

    stream(path) {
        try {
            return fs.createReadStream(path);
        } catch (err) {
            return 1
            console.error(err)
        }
    },

    delete(path) {
        try {
            fs.unlinkSync(path)
            return 0
        } catch (err) {
            return 1
            console.error(err)
        }
    }

}