const path = require('path')
const { join } = require('path')
const { ACCESS, SERVICE } = { ACCESS: 'log_acess.json', SERVICE: 'log_service.json' }
const logsPath = path.resolve(__dirname, '..', '..', 'logs')

const io = require('./io')

module.exports = {

    logService(newData) {
        const file = join(logsPath, SERVICE)
        const data = io.reader(file)        
        data.push(newData)
        io.write(file, data)
    },

    logAcess(){

    },

}