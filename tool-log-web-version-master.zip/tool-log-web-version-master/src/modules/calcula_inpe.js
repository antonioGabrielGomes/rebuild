const shell = require('shelljs')

const calcula_inpe = (lat, lon) => {
    const query = "curl -s --request POST --data 'proj_out=utm&DATUM_OUT=4&Y="+lat+"&X="+lon+"&DATUM=4&PRJIN=latlong_gd&TYCORD=latlong_gd&Avan%E7ar=Avan%E7ar'  http://www.dpi.inpe.br/calcula/result.php"
    const command = shell.exec(query, {silent:true})
    return command
}

module.exports = calcula_inpe