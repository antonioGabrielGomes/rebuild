const tj = require("@tmcw/togeojson");
const fs = require("fs");
const { DOMParser } = require("xmldom");

function* convert(data) {
  const snippet = data.substring(0, 200);
  const parser = new DOMParser();
  if (snippet.includes("<kml")) {
    yield* tj.kmlGen(parser.parseFromString(data));
  } else if (snippet.includes("<gpx")) {
    yield* tj.gpxGen(parser.parseFromString(data));
  } else {
    throw new Error("Could not detect file format of an input");
  }
}

const geojson = (data) => {

    let stdout = '{\n  "type": "FeatureCollection",\n  "features": [\n'
  
    let first = true;

    for (let feature of convert(data)) {

        if (!first) {
          stdout += ",\n    "
        } else {
          stdout += "    "
          first = false;
        }

        stdout += JSON.stringify(feature)
       
    }
    
    stdout +=  "\n  ]\n}\n"   

    return stdout
}

module.exports = geojson








/*


} else {
  let data = "";

  process.stdin.setEncoding("utf8");

  process.stdin.on("readable", () => {
    let chunk;
    while ((chunk = process.stdin.read())) {
      data += chunk;
    }
  });

  process.stdin.on("end", () => {
    console.log(
      JSON.stringify({
        type: "FeatureCollection",
        features: Array.from(convert(data))
      })
    );
  });
}

*/