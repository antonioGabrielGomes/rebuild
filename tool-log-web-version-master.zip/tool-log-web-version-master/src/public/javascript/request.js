$(document).ready(function () {
    
    const urlH = "https://tool-log-web-version.herokuapp.com"
    const urlL = "http://localhost:3000"

    $("#s1").hide()
    $("#s2").hide()
    $("#s3").hide()

    $("#rename-point").click(function () {
        $("#s1").show()
        $("#s2").hide()
        $("#s3").hide()
        $("#content").hide()
    })

    $("#change-schedule").click(function () {
        $("#s1").hide()
        $("#s2").show()
        $("#s3").hide()
        $("#content").hide()

    })

    $("#coord-conversion").click(function () {
        $("#s1").hide()
        $("#s2").hide()
        $("#s3").show()
        $("#content").hide()

    })

    const setDownload = (data, filename) => {
        const element = document.createElement('a')
        element.setAttribute('href', 'data:text/plain;charset=utf8,' + encodeURIComponent(data))
        element.setAttribute('download', `${Date.now()}-${filename}`)

        element.style.display = 'none'
        document.body.appendChild(element)

        element.click()

        document.body.removeChild(element)
    }

    $("#btn-s1").click(function () {
        $("#btn-s1").html('wait...')
        $("#btn-s1").prop('disabled', true)

        const urlH = "https://tool-log-web-version.herokuapp.com"

        const type_file = "application/vnd.google-earth.kml+xml"

        const input = document.querySelector("input#file-s1")
        const file = input.files[0]

        if (file) {
            if (file.type === type_file) {
                const reader = new FileReader()

                reader.addEventListener("load", () => {

                    (async () => {
                        try {

                            const res = await axios.post(`${urlH}/renome_points`, {
                                points: reader.result,
                                filename: file.name
                            })

                            const data = res.data //JSON.stringify(res.data)                            
                            setDownload(data, file.name)

                            $("#btn-s1").html('send')
                            $("#btn-s1").prop('disabled', false)

                        } catch (error) {
                            console.log(error)
                        }

                    })()
                })
                reader.readAsText(file);
            } else {
                alert(`Error: Invalid file format. Accept only ${type_file}`)
            }
        }

    })

    $("#btn-s2").click(function () {
        $("#btn-s1").html('wait...')
        $("#btn-s1").prop('disabled', true)

        const urlH = "https://tool-log-web-version.herokuapp.com"

        const type_file = "text/csv"

        const datelegacy = $("#legacy-s2").is(':checked')
        const input = document.querySelector("input#file-s2")
        const file = input.files[0]

        if (file) {
            if (file.type === type_file) {
                const reader = new FileReader()

                reader.addEventListener("load", () => {

                    (async () => {
                        try {

                            const res = await axios.post(`${urlH}/change_schedule`, {
                                datafile: reader.result,
                                filename: file.name,
                                datelegacy: datelegacy
                            })

                            const data = res.data //JSON.stringify(res.data)                            
                            setDownload(data, file.name)
                           

                            $("#btn-s2").html('send')
                            $("#btn-s2").prop('disabled', false)

                        } catch (error) {
                            console.log(error)
                        }

                    })()

                })
                reader.readAsText(file);

            } else {
                alert(`Error: Invalid file format. Accept only ${type_file}`)
            }
        }

    })

    /**  convert coord  */
    $("#btn-s3").click(function () {
        $("#btn-s3").html('wait...')
        $("#btn-s3").prop('disabled', true)

        const type_file = "application/vnd.google-earth.kml+xml"

        const input = document.querySelector("input#file-s3")
        const file = input.files[0]

        if (file) {
            if (file.type === type_file) {
                const reader = new FileReader()

                reader.addEventListener("load", () => {

                    (async () => {
                        try {
                            const res = await axios.post(`${urlH}/convert_coord`, {
                                points: reader.result,
                                filename: file.name
                            })

                            const data = JSON.stringify(res.data) //res.data                                            
                            setDownload(data, `${file.name}.json`)
                            
                            $("#btn-s3").html('send')
                            $("#btn-s3").prop('disabled', false)                            

                        } catch (error) {
                            console.log(error)
                        }
                       

                    })()


                })
                reader.readAsText(file);
            } else {
                alert(`Error: Invalid file format. Accept only ${type_file}`)
            }
        }

    })



    const frames = [
        "https://pt.wikipedia.org/wiki/Keyhole_Markup_Language",
        "https://pt.wikipedia.org/wiki/Coordenadas_geogr%C3%A1ficas",
        "https://en.wikipedia.org/wiki/Google_Earth",
        "https://pt.wikipedia.org/wiki/Universal_Transversa_de_Mercator",
        "https://pt.wikipedia.org/wiki/Fuso_hor%C3%A1rio",
        "https://en.wikipedia.org/wiki/Date_format_by_country"
    ]

    $("#content").show()
    let content = document.getElementById("content")
    let indice = parseInt(Math.random() * (frames.length - 0) + 0)
    let element = document.createElement("iframe")
    element.setAttribute('src', frames[indice])
    element.style.width = "800px";
    element.style.height = "480px";


    content.appendChild(element)
   
})


