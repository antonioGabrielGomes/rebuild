# archfi CONTRIBUTING

## Contributing :
* Open an issue before work to hard
* **Work on the src branch**
* **Use tab for identation**
* **Preserve identation on empty line**
* **Test your changes**

- [ ] I've read these rules before submitting my PR.
