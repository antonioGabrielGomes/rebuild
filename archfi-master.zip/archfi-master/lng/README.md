# Translations

Translations is simple:

- fork the project.
- create your language file.
- pull Request your change.
- you can test your change with the next command:

```
sh archfi -t {githubusername} {branchname}
```

As exemple:

```
sh archfi -t matmoul master
```
