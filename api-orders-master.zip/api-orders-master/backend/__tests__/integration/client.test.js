const request = require('supertest')

const app = require('../../src/app')
const factory = require('../factories')
const truncate = require('../utils/truncate')

describe('client', () => {
    beforeEach(async () => {
        await truncate()
    })

    it('POST /client 200', async () => {
        const client = await factory.create('Client')
     
        const response = await request(app)
            .post('/client')
            .send({
                name: client.name,
                email: client.email,
                phone: client.phone,
                latitude: client.latitude,
                longitude: client.longitude,
                number: client.number,
                complements: client.complements,
                payment_method: client.payment_method
            })
              
        console.log(client)
        expect(response.status).toBe(200)
    });

    it('POST /client 400', async () => {
        const client = await factory.create('Client')
     
        const response = await request(app)
            .post('/client')
            .send({
                email: client.email,
                phone: client.phone,
                latitude: client.latitude,
                longitude: client.longitude,
                number: client.number,
                complements: client.complements,
                payment_method: client.payment_method
            })
              
        expect(response.status).toBe(400)
    })

    // criar testes para put 200 e 400


    it('PUT /client/:id', async () => {
        const client = await factory.create('Client')

        const response = await request(app)
            .put('/client/1')
            .send({
                name: client.name,
                email: client.email,
                phone: client.phone,
                latitude: client.latitude,
                longitude: client.longitude,
                number: client.number,
                complements: client.complements,
                payment_method: client.payment_method
            })

        expect(response.status).toBe(404)
    });

    // criar teste para delete 200 400 404
})