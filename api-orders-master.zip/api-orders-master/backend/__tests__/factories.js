const faker = require('faker')
const { factory } = require('factory-girl')
const { Client } = require('../src/app/models')

factory.define('Client', Client, {
    name: faker.name.findName(),
    email: faker.internet.email(),
    phone: faker.phone.phoneNumber(),
    latitude: faker.address.latitude(),
    longitude: faker.address.longitude(),
    number: faker.address.zipCode(),
    complements: faker.address.secondaryAddress(),
    payment_method: faker.random.arrayElement([1,2])
})


module.exports = factory