const routes = require('express').Router()

const ClientController = require('./app/controllers/ClientController')
const OrderController = require('./app/controllers/OrderController')
const OrderProductController = require('./app/controllers/OrderProductController')
const CollaboratorController = require('./app/controllers/CollaboratorController')


routes.post('/client', ClientController.store)
routes.put('/client/:id', ClientController.update)
routes.get('/client/telegram/:chat_id', ClientController.index)

routes.post('/order/new/:client_id', OrderController.store)
routes.post('/order/product/add/:order_id', OrderProductController.store) 
routes.delete('/order/product/remove/:order_id', OrderProductController.delete) 
routes.put('/order/confirm/:order_id', OrderController.update) 

routes.put('/order/status/:order_id', CollaboratorController.update)




//routes.get('/order', OrderController.index)

module.exports = routes
