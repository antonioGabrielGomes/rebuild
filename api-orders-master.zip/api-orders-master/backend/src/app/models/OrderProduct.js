'use strict'

module.exports = (sequelize, DataTypes) => {
    const OrderProduct = sequelize.define('OrderProduct', {

    })
    OrderProduct.associate = function (models) {
        OrderProduct.belongsTo(models.Order, {
            foreignKey: 'order_id',
            as: 'order'
        })
        OrderProduct.belongsTo(models.Product, {
            foreignKey: 'product_id',
            as: 'product'
        })
    }
    return OrderProduct
}