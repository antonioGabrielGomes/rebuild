'use strict';

module.exports = (sequelize, DataTypes) => {
    const Product = sequelize.define('Product', {
        name: DataTypes.STRING,
        description: DataTypes.STRING,
        value: DataTypes.FLOAT
    }, {});
    Product.associate = function (models) {
        Product.belongsTo(models.Category,
            {
                foreignKey: 'category_id',
                as: 'category'
            });
        Product.belongsToMany(models.Order, {
            foreignKey: 'product_id',
            through: 'order_product',
            as: 'orders'
        });
    }

    return Product
}