'use strict';
module.exports = (sequelize, DataTypes) => {
  const Order = sequelize.define('Order', {
    status: DataTypes.STRING,
    payment_type: DataTypes.INTEGER
  }, {});
  Order.associate = function (models) {
    Order.belongsTo(models.Client, {
      foreignKey: 'client_id',
      as: 'clients'
    })
    Order.belongsToMany(models.Product,
      {
        foreignKey: 'order_id',
        through: 'order_product',
        as: 'products'
      })
  };
  return Order;
};