
module.exports = (sequelize, DataTypes) => {
  const Client = sequelize.define('Client', {
    name: DataTypes.STRING,
    email: DataTypes.STRING,
    id_telegram: DataTypes.INTEGER,
    phone: DataTypes.STRING,
    latitude: DataTypes.STRING,
    longitude: DataTypes.STRING,
    number: DataTypes.STRING,
    complements: DataTypes.STRING,
    payment_method: DataTypes.INTEGER
  }, {
    
  });

  Client.associate = function (models) {
    Client.hasMany(models.Order, { foreignKey: 'client_id', as: 'order'  })
  };

  return Client;
};