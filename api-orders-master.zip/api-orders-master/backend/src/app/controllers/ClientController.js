const { Client } = require('../models')

class ClientController {

    async index(req, res){
        const {  chat_id } = req.params

        try {   
            const client = await Client.findOne({ where: { id_telegram: chat_id } })

            if(!client)
                res.status(404).json({ message: "Client not found" })

            res.json(client)
        } catch (error) {
            res.status(400).json({ message: "Client not found" })
        }
    } 

    async store(req, res) {
        const {
            name, email, id_telegram, phone, latitude, longitude, number, complements, payment_method
        } = req.body

        try {
            const client = await Client.create({
                name,
                email,
                id_telegram,
                phone,
                latitude,
                longitude,
                number,
                complements,
                payment_method
            })

            res.json(client)
        } catch (err) {
            res.status(400).json({ message: "Client not created" })
        }

    }

    async update(req, res) {
        const {
            name, email, id_telegram, phone, latitude, longitude, number, complements, payment_method
        } = req.body
        const { id } = req.params

        try {
            const client = await Client.findByPk(id)

            if (!client)
                res.status(404).json({ message: "Client not found" })

            await Client.update({
                name,
                email,
                id_telegram,
                phone,
                latitude,
                longitude,
                number,
                complements,
                payment_method
            }, {
                where: {
                    id: id
                }
            })

            res.status(200).send()
        } catch (err) {
            res.status(400).json({ message: "Client has not updated" })
        }

    }

}

module.exports = new ClientController()