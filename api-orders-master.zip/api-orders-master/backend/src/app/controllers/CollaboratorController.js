const { Order } = require('../models')

const status = require('../../database/data_std/status')

class CollaboratorController {

    async update(req, res) {
        const { order_id } = req.params
        const { order_status_code } = req.body

        try {
            const order = await Order.findByPk(order_id)

            if (!order)
                res.status(404).json({ message: "Order not found" })
            else {
                const current_status = order.dataValues.status

                if (status[order_status_code] === current_status)
                    res.status(404).json({ message: `Error: current status ${current_status}` })
                else {

                    await Order.update({
                        status: status[order_status_code],
                    }, {
                        where: {
                            id: order_id
                        }
                    })

                    res.json({ message: `Order ${status[order_status_code]}` })
            
                }
            
            }
        } catch (error) {
            console.log(error)
            res.status(400).json({ message: "It was not possible to change the order status" })
        }


    }

}

module.exports = new CollaboratorController() 