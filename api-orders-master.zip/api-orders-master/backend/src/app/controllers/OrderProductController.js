const { Product, Order } = require('../models')

class OrderProductController {

    async index(req, res){
        const { order_id } = req.params

        res.send()
    }

    async store(req, res) {
        const { product_id } = req.body
        const { order_id } = req.params

        try {
            const order = await Order.findByPk(order_id)

            if (!order)
                res.status(404).json({ message: "Order not found" })

            if (order.status !== "new")
                res.status(404).json({ message: `Error: Your order is ${order.status}` })

            const product = await Product.findByPk(product_id)

            if (!product)
                res.status(404).json({ message: "Product not found" })

            await order.addProduct(product)

            res.status(200).send()
        } catch (error) {
            res.status(400).json({ message: "Product not add" })
        }
    }

    async delete(req, res) {
        const { product_id } = req.body
        const { order_id } = req.params

        try {
            const order = await Order.findByPk(order_id)

            if (!order)
                res.status(404).json({ message: "Order not found" })

            if (order.status !== "new")
                res.status(404).json({ message: `Error: Your order is ${order.status}` })

            const product = await Product.findByPk(product_id)

            if (!product)
                res.status(404).json({ message: "Product not found" })


            await order.removeProduct(product)

            res.status(200).send()
        } catch (error) {
            res.status(400).json({ message: "Order not created" })
        }
    }


}

module.exports = new OrderProductController()