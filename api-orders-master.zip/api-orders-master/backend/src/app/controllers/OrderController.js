const { Client, Order } = require('../models')

class OrderController {

    async store(req, res) {
        const { client_id } = req.params
        const status = 'new'

        try {
            const client = await Client.findByPk(client_id)

            if (!client)
                res.status(404).json({ message: "Client not found" })

            const order = await Order.create({
                client_id,
                status,
            })

            res.json(order)
        } catch (error) {
            res.status(400).json({ message: "Order not created" })
        }
    }

    async update(req, res) {
        const { payment } = req.body
        const { order_id } = req.params

        try {
            const order = await Order.findByPk(order_id, {
                include: {
                    association: 'products'
                }
            })

            if (!order)
                res.status(404).json({ message: "Order not found" })
            else {

                if (order.status === "new" ){

                    if (order.products.length == 0)
                        res.status(404).json({ message: "No products found in your order" })
                    else {
                        const client = await Client.findByPk(order.dataValues.client_id)

                        if (!client)
                            res.status(404).json({ message: "Client of order not found" })

                        let payment_method = client.payment_method

                        if (payment.change)
                            payment_method = payment.payment_type

                        await Order.update({
                            status: "confirmed",
                            payment_type: payment_method,
                        }, {
                            where: {
                                id: order_id
                            }
                        })

                        res.json({ message: "Order confirmed" })
                    }
                }else{
                    res.status(404).json({ message: `The order cannot be confirmed. 
                                                    Current status ${order.status}` })
                }

            }
        } catch (error) {
            console.log(error)
            res.status(400).json({ message: "Order not confirmed" })
        }
    }

}

module.exports = new OrderController()