
const status = ["new", "confirmed", "canceled", "in progress", "complete"]

module.exports = status