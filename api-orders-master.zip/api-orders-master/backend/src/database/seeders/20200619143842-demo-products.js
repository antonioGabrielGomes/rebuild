'use strict';

module.exports = {
  up: (queryInterface, Sequelize) => {

    return queryInterface.bulkInsert('products', [
      {
        name: 'Mussarela',
        value: 18.0,
        description: 'Molho de Tomate, Queijo Mussarela, Tomate, Oregano',
        category_id: 1
        , created_at: new Date(), updated_at: new Date()
      },
      {
        name: 'Calabresa',
        value: 18.0,
        description: 'Molho de Tomate, Queijo Mussarela, Tomate, Oregano, Calabresa',
        category_id: 1
        , created_at: new Date(), updated_at: new Date()
      },
      {
        name: 'Presunto',
        value: 18.0,
        description: 'Molho de Tomate, Queijo Mussarela, Tomate, Oregano, Presunto',
        category_id: 1
        , created_at: new Date(), updated_at: new Date()
      },
      {
        name: 'Coca-cola',
        value: 6.0,
        description: 'Refrigerante Coca Cola 1L',
        category_id: 2
        , created_at: new Date(), updated_at: new Date()
      },
      {
        name: 'Guaraná',
        value: 5.0,
        description: 'Refrigerante Guaraná 1L',
        category_id: 2
        , created_at: new Date(), updated_at: new Date()
      },
      {
        name: 'Acerola',
        value: 5.0,
        description: 'Suco acerola 1L',
        category_id: 2
        , created_at: new Date(), updated_at: new Date()
      },
      {
        name: 'Goiaba',
        value: 5.0,
        description: 'Suco goiaba 1L',
        category_id: 2
        , created_at: new Date(), updated_at: new Date()
      }
    ], {});

  },

  down: (queryInterface, Sequelize) => {

    return queryInterface.bulkDelete('products', null, {});

  }
};
