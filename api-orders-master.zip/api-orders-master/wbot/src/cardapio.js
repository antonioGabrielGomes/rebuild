const cardapio = {
    1: {
        descricao: 'X-Burguer',
        preco: 9.9,
    },
    2: {
        descricao: 'Passaporte',
        preco: 10.0,
    },
    3: {
        descricao: 'Minuano',
        preco: 12.99
    },
}


exports.menu = cardapio