var banco = {
    '559188343121@c.us': {
        stage: 0,
        itens: [],
    },
    user2: {
        stage: 1,
        itens: [],
    }
}


exports.db = banco