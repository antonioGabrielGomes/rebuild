/*
const sulla = require('sulla')

sulla.create().then((client) => start(client))

function start(client){
    client.onMessage((message) => {
        if(message.body === 'Hi'){
            client.sendText(message.from, 'Hello F Word!')
        }

        client.sendText(message.from, 'Hello F Word!')

    })
}

*/

const venom = require('venom-bot')
const banco = require('./banco')
const stages = require('./stages')


venom.create().then((client) => start(client))
function start(client) {
    client.onMessage((message) => {

        //if (message.body === 'hi') {

            let resp = stages.step[getStage(message.from)].obj.execute(
                message.from,
                message.body
            )

            resp.forEach(element => {
                client.sendText(message.from, element)
            });
       // }

    })
}

function getStage(user) {
    return banco.db[user].stage
}
