const banco = require('../banco')

function execute(user, msg){

    banco.db[user].stage = 0

    return [
        "Obrigado pela preferência",
        "Aguarde, seu pedido será está a caminho",
        "Para mais informaçẽos, ligue: 8888-8888"
    ]

}

exports.execute = execute