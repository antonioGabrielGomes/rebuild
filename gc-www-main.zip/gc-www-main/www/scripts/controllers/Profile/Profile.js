class Profile {

    constructor(){
        this._urlShow = '/mikrotik/profile/show'
        this._data = []
    
    }



}