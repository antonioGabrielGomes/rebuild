class Mikrotik {
    'use-strict'

    constructor() {
        this._id = 'mikrotik_connection'
        this._dataConn = []

        this.baseUrl = "http://localhost:8080/api/v1.0.0"

        this._urlShow = `${this.baseUrl}/mikrotik/index`
        this._urlTestConn = `${this.baseUrl}/mikrotik/test`
        this._urlCreate  = `${this.baseUrl}/mikrotik/salve`

        this.loadMenuEvents()
    }

    loadMenuEvents() {
        $(`#${this._id}`).click(async () => {
            // add new html in container
            let form = document.querySelector(`#${this.modifiBody(this.formCreateConn())}`)

            await axios.get(this._urlShow)
                .then(r => {
                    this._dataConn = r.data
                })
                .catch(e => {
                    alert(e.response.message)
                })

            if (this._dataConn && form) {
                form[0].value = this._dataConn.address
                form[1].value = this._dataConn.user
                form[2].value = this._dataConn.password
            }

            // listen handle form
            form.addEventListener('submit', async (e) => {
                e.preventDefault()

                const address = form[0].value
                const user = form[1].value
                const password = form[2].value

                await axios.post(this._urlCreate, {
                    address, user, password 
                })
                .then((r) => {
                    alert(r.data.message)
                })
                .catch((e) => {
                    alert(e.response.data.message)
                })
            })

            // listen handle test connections
            let formTest = document.querySelector("#test_mikrotik_connection")                
            formTest.addEventListener('click', async (e) => {
                e.preventDefault()

                const address = form[0].value
                const user = form[1].value
                const password = form[2].value

                await axios.post(this._urlTestConn, {
                    address, user, password 
                })
                .then((r) => {
                    alert(r.data.message)
                })
                .catch((e) => {
                    alert(e.response.data.message)
                })

            })

        })
    }

    modifiBody(html, id_container = 'demo') {
        
        let container = document.querySelector(`#${id_container}`)
        this.replaceChildBody(container, this.newContainer(html))
        return 'form_mikrotik_connection'

    }

    newContainer(html = '') {
        let div = document.createElement('div')
        // add style

        // content
        if (html !== '')
            div.innerHTML = html

        return div
    }

    replaceChildBody(parent, child) {
        if (parent.childNodes[1]) {
            parent.replaceChild(child, parent.childNodes[1])
        } else {
            parent.appendChild(child)
        }
    }

    formCreateConn() {
        return `                  
        <form id="form_mikrotik_connection">
             <div class="form-group">

             <label>Endereço IP</label>
             <input for="ip" type="text" class="form-control" id="ip" aria-describedby="IPAddressHelp" placeholder="Endereço IP">
             <small id="IPAddressHelp" class="form-text text-muted"></small>
             </div>

             <div class="form-group">
             <label for="user">Usuário</label>
             <input type="text" class="form-control" id="user" placeholder="Usuário">
             </div>

             <div class="form-group">
             <label for="password">Senha</label>
             <input type="password" class="form-control" id="password" placeholder="Senha">
             </div>
             
             <button type="submit" class="btn btn-primary">Salvar</button>
             <button id="test_mikrotik_connection" type="button" class="btn btn-success">Teste</button>
         </form>
        `
    }

}