class Secret {
    'use-strict'

    constructor(indexId) {
        this._index = indexId
        this._id = ['secrets', 'pending']
        this._data = []
        this._btns = []
        this._url = [`/secrets`, `/pending`]

        this.loadMenuEvents()
    }

    loadMenuEvents() {
        $(`#${this._id[this._index]}`).click(async () => {
            await this.requestData()
        })
    }

    async requestData() {
        // add new html in container
        let form = document.querySelector(`#${this.modifiBody(this.createTableSecrets())}`)

        await axios.get(this._url[this._index])
            .then(r => {
                this._data = r.data.data ? r.data.data: r.data
                this.addDataTableSecrets(this._data)
            })
            .catch(e => {
                this.addDataTableSecrets(this._data)
            })

        if (this._data.length) {
            this._btns = this.createBtnActionSecrets(this._data.length)
        }
    }

    addDataTableSecrets(data) {

        let trs = ''

        for (let j = 0; data.length > j; j++) {


            let id = data[j][0]
            let name = data[j][1]
            let service = data[j][2]
            //let caller_id = data[j][3]
            //let password = data[j][4]
            let profile = data[j][5]
            //let routes = data[j][6] ? data[j][6].value : null
            //let limit_bytes_in = data[j][7]
            //let limit_bytes_out = data[j][8]
            let last_logged_out = data[j][9]
            let disabled = data[j][10]
            let comment = data[j][11] ? data[j][11].value : null

            let classDisabled = disabled.value === 'true' ? 'list-group-item-danger' : 'list-group-item-success'
            let buttons = disabled.value === 'true' ?
                `<button id="btn_${j}" key="${name.value}" name="no" type="button" class="btn-primary btn-sm btn btn-success">Desbloquear</button>` :
                `<button id="btn_${j}" key="${name.value}" name="yes" type="button" class="btn-primary btn-sm btn btn-danger">Bloquear</button>`

            //** */
            let infos = null

            if (comment) {

                let json = JSON.parse(comment)
                comment = `venc. ${json.payment_day}`
                infos = json.info

            }

            let tr =
                `<tr>
                        <th class="list-group-item list-group-item-primary" scope="row">${id.value}</th>
                        <td>${name.value}</td>
                        <td>${service.value}</td>
                        <td>${profile.value}</td>
                        <td>${last_logged_out.value}</td>
                        <td class='${classDisabled}'></td>
                        <td class='list-group-item-warning'>${comment}</td>

                        <td>${infos}</td>

                        <td>
                            ${buttons}
                        </td>

                    </tr>`

            trs += tr

            // apagar depois de usar
            //tmpCadastrarCommentario(name.value)
        }


        let tbody = document.querySelector("#tbodySecret")

        if (trs != '') {
            tbody.innerHTML = trs
        } else {
            tbody.innerHTML = 'Nenhum cliente disponível nesta sessão.'
            //alert('Data found.')
        }
    }

    createBtnActionSecrets(count = 0) {
        let btns = []

        for (let j = 0; count > j; j++) {

            let btn = document.querySelector(`#btn_${j}`)
            btn.addEventListener('click', async () => {

                let name = btn.getAttributeNode('key').value
                let yn = btn.getAttributeNode('name').value
                let url = yn === 'yes' ? '/disable/' : '/enable/'

                //console.log(name, " ", yn)

                await axios.put(`${url}${name}`)
                    .then((res) => {
                        alert(res.data.message)
                        this.requestData()
                    })
                    .catch((e) => {
                        alert(e.response.message)
                    })
            })

            btns.push(btn)
        }

        return btns
    }

    modifiBody(html, id_container = 'demo') {

        let container = document.querySelector(`#${id_container}`)
        this.replaceChildBody(container, this.newContainer(html))
        return 'form_mikrotik_connection'

    }

    newContainer(html = '') {
        let div = document.createElement('div')
        // add style

        // content
        if (html !== '')
            div.innerHTML = html

        return div
    }

    replaceChildBody(parent, child) {
        if (parent.childNodes[1]) {
            parent.replaceChild(child, parent.childNodes[1])
        } else {
            parent.appendChild(child)
        }
    }

    createTableSecrets() {
        return `
                <table class="table">
                    <thead>
                        <tr class="list-group-item-dark">                            
                            <th scope="col">*id</th>
                            <th scope="col">name</th>
                            <th scope="col">Service</th>
                            <th scope="col">profile</th>
                            <th scope="col">ll-out</th>
                            <th scope="col">disabled </th>
                            <th scope="col">comment </th>
                            <th scope="col">Info</th>
                            <th scope="col">Opções</th>
                        </tr>
                    </thead>
                    <tbody id="tbodySecret">                                     
                        
                    </tbody>
                </table>`
    }


}