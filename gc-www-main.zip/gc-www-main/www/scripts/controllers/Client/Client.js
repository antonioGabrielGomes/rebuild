class Client {

    'use-strict'

    constructor() {
        this._id = 'add_client'
        this._data = []
        this._urlCreate = `/mikrotik/client/salve`

        this.loadMenuEvents()
    }

    loadMenuEvents() {
        $(`#${this._id}`).click(async () => {
            // add new html in container
            let form = document.querySelector(`#${this.modifiBody(this.formCreateClient())}`)

            // listen handle form
            form.addEventListener('submit', async (e) => {
                e.preventDefault()

                await axios.post(this._urlCreate, {
                    address, user, password
                })
                    .then((r) => {
                        alert(r.data.message)
                    })
                    .catch((e) => {
                        alert(e.response.data.message)
                    })
            })

        })
    }

    modifiBody(html, id_container = 'demo') {

        let container = document.querySelector(`#${id_container}`)
        this.replaceChildBody(container, this.newContainer(html))
        return 'form_add_client'

    }

    newContainer(html = '') {
        let div = document.createElement('div')
        // add style

        // content
        if (html !== '')
            div.innerHTML = html

        return div
    }

    replaceChildBody(parent, child) {
        if (parent.childNodes[1]) {
            parent.replaceChild(child, parent.childNodes[1])
        } else {
            parent.appendChild(child)
        }
    }

    formCreateClient() {
        return `                  
        <form id="form_add_client">
             <div class="form-group">

             <label>Name</label>
             <input for="ip" type="text" class="form-control" id="ip" aria-describedby="IPAddressHelp" placeholder="Endereço IP">
             <small id="IPAddressHelp" class="form-text text-muted"></small>
             </div>

             <div class="form-group">
             <label for="password">Senha</label>
             <input type="password" class="form-control" id="password" placeholder="Senha">
             </div>

             <div class="form-group">
                 <label for="profile">Profile</label>
                 <select class="form-control" id="profile">
                 <option>1MB</option>
                 <option>2MB</option>
                 <option>3MB</option>
                 <option>4MB</option>
                 <option>5MB</option>
                 </select>
             </div>
             
             
             <button type="submit" class="btn btn-primary">Salvar</button>
         </form>
     `
    }

}