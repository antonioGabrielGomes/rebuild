window.mikrotik = new Mikrotik()
window.secret = new Secret(0) // all secrets
window.pending = new Secret(1) // secrets pending
window.client = new Client()

//  criar no back end os controllers para profile show e client create