const app = require('./server')

app.listen(3000, () => {
    console.log("example localhost:3000")
})