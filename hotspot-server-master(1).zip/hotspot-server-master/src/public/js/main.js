$(document).ready(function(){

    /** load menu buttons */
    (function init(){
      $("#test").hide();        
    })()

    $("#launch").click(function(){
      $("#test").show();
    });

 
  });



  

  /**
   * 
   
(function () {

    window.addEventListener('load', () => {

        const days = [5, 15, 25]
        
        let secrets = document.querySelector('#secrets')
        secrets.addEventListener('click', async () => {

            // criando campo de tabela
            innerDemo(tableSecrets)
            // array para guardar novos botões, caso existam
            let btns = []
            let data = []

            await axios.get('/secrets')
                .then(function (res) {
                    data = res.data.data
                    createTableHtml(res.data.data)
                })
                .catch(function (err) {
                    createTableHtml([])
                    //alert(err.response)
                })

            // ** verificar se não está vázio
            let l = data.length
            if (l > 0) {
                btns = createButtons(l)
            }

        })

        let pending = document.querySelector("#pending")
        pending.addEventListener('click', async () => {
            // criando campo de tabela
            innerDemo(tableSecrets)
            // array para guardar novos botões, caso existam
            let btns = []
            let data = []

            await axios.get('/secrets')
                .then(function (res) {
                    console.log(res.data.data)
                    data = checkPending(res.data.data)
                    createTableHtml(data)
                })
                .catch(function (err) {
                    createTableHtml([])
                    //alert(err.response)
                })

            // ** verificar se não está vázio
           
            let l = data.length
            if (l > 0) {
                btns = createButtons(l)
            }
           

        })

    })

    function createTableHtml(data) {

        let trs = ''

        for (let j = 0; data.length > j; j++) {


            let id = data[j][0]
            let name = data[j][1]
            let service = data[j][2]
            //let caller_id = data[j][3]
            //let password = data[j][4]
            let profile = data[j][5]
            //let routes = data[j][6] ? data[j][6].value : null
            //let limit_bytes_in = data[j][7]
            //let limit_bytes_out = data[j][8]
            let last_logged_out = data[j][9]
            let disabled = data[j][10]
            let comment = data[j][11] ? data[j][11].value : null

            let classDisabled = disabled.value === 'true' ? 'list-group-item-danger' : 'list-group-item-success'
            let buttons = disabled.value === 'true' ?
                `<button id="btn_${j}" key="${name.value}" name="no" type="button" class="btn-primary btn-sm btn btn-success">Desbloquear</button>` :
                `<button id="btn_${j}" key="${name.value}" name="yes" type="button" class="btn-primary btn-sm btn btn-danger">Bloquear</button>`

       
            let infos = null

            if (comment) {

                let json = JSON.parse(comment)
                comment = `venc. ${json.payment_day}`
                infos = json.info

            }

            let tr =
                `<tr>
                        <th class="list-group-item list-group-item-primary" scope="row">${id.value}</th>
                        <td>${name.value}</td>
                        <td>${service.value}</td>
                        <td>${profile.value}</td>
                        <td>${last_logged_out.value}</td>
                        <td class='${classDisabled}'></td>
                        <td>${comment}</td>

                        <td>${infos}</td>

                        <td>
                            ${buttons}
                        </td>

                    </tr>`

            trs += tr

            // apagar depois de usar
            //tmpCadastrarCommentario(name.value)
        }


        let tbody = document.querySelector("#tbodySecret")

        if (trs != '') {
            tbody.innerHTML = trs
        } else {
            tbody.innerHTML = 'Nenhum cliente disponível nesta sessão.'
            //alert('Data found.')
        }

    }

    function createButtons(count = 0) {
        let btns = []

        for (let j = 0; count > j; j++) {

            let btn = document.querySelector(`#btn_${j}`)
            btn.addEventListener('click', async () => {

                let name = btn.getAttributeNode('key').value
                let yn = btn.getAttributeNode('name').value
                let url = yn === 'yes' ? '/disable/' : '/enable/'

                //console.log(name, " ", yn)

                await axios.put(`${url}${name}`)
                    .then(function (res) {
                        alert(res.data.message)
                        window.location.reload()
                    })
                    .catch(function (err) {
                        alert(err.response.data.message)
                    })
            })

            btns.push(btn)
        }

        return btns
    }

    function checkPending(data) {

        if (data.length > 0) {

            const pendencies = data.filter(d => { if (d.pendencies.length > 0) return d })

            return pendencies

        } else {
            return []
        }

        //let comment = data[j][11] ? data[j][11].value : null
        //const json = JSON.parse(comment)
        //console.log(json.payment_day)                        
        // const text = '{"add_at":"09/09/2020","payment_day": "05","pendencies":[],"info":"null"}'



    }

    function replaceChildDemo(parent, child) {
        if (parent.childNodes[1]) {
            parent.replaceChild(child, parent.childNodes[1])
        } else {
            parent.appendChild(child)
        }
    }

    function createDiv(html = '') {
        let dv = document.createElement('div')
        // add style

        // content
        if (html !== '')
            dv.innerHTML = html

        return dv
    }

    function innerDemo(html) {
        let demo = document.querySelector('#demo')
        replaceChildDemo(demo, createDiv(html))
        //demo.innerHTML = html
    }



    const tableSecrets = `
                <table class="table">
                    <thead>
                        <tr class="list-group-item-dark">                            
                            <th scope="col">*id</th>
                            <th scope="col">name</th>
                            <th scope="col">Service</th>
                            <th scope="col">profile</th>
                            <th scope="col">ll-out</th>
                            <th scope="col">disabled </th>
                            <th scope="col">comment </th>
                            <th scope="col">Info</th>
                            <th scope="col">Opções</th>
                        </tr>
                    </thead>
                    <tbody id="tbodySecret">                                     
                        
                    </tbody>
                </table>
                `

})()
   */