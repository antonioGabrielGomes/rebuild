const express = require('express');
const router = express.Router();

/** controllers */
const MikrotikController = require('./controllers/MikrotikController')

router.post('/register', MikrotikController.register);

module.exports = router;