const express = require('express')
const app = express()
//const bodyParser = require('body-parser')
const port = process.env.PORT || 8080
const route = require('./routes')

app.use(express.json())
//app.use(express.urlencoded({ extended: false, limit: '2gb' }));

app.use(express.static('./src/public'))
app.use(route)
app.set('x-powered-by', false)


app.listen(port, () => console.log(`Hotspot server listen port: ${port}`))
