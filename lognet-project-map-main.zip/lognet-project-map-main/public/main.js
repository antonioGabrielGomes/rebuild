(()=>{
    
    let map = new Mapb('pk.eyJ1IjoiYXRnYWJyaWVsIiwiYSI6ImNqdTNkb2M4YjBtNWY0ZGxveXdpazB4b3oifQ._iutIATrmRr4_Xz3z5yG3Q')
    
    /*
    let data = bairros.features

        data.forEach(element => {

            var el = document.createElement('div')
          
            el.className = 'marker'
            el.style.backgroundImage = `url(${element.properties.icon})`
            el.style.width = 30 + 'px' //marker.properties.iconSize[0] + 'px'
            el.style.height = 30 + 'px' //marker.properties.iconSize[1] + 'px'
            el.style.stroke = element.properties.stroke
            el.style.strokeOpacity = element.properties["stroke-opacity"]
          
            
            el.addEventListener('click', (e) => {              
             
              let findEl = null 
              map._historyPoint.forEach(finded => {
                if (finded.geometry.coordinates[0] == element.geometry.coordinates[0]){
                  findEl = finded
                  return 
                }
              })      
                                          
              if(findEl == null) {
                
                map._historyPoint.push(element)

                let desc = element.properties.description
                let pos = desc.indexOf('CASA')
            
                if(pos >= 0) {
                  let casa = desc.substr(pos, pos+2)
  
                  casa = casa.substr(0, 7)
                  let qtds = casa.split(' ')
                
                  map._residences += parseInt(qtds[1])                         
                  map.calculate()             
                }

              }
              
              //console.log(map._historyPoint)            
              //console.log(element.properties.description)
            });

          
          
            let popup = new mapboxgl.Popup().setHTML(element.properties.description)          
          
            let marker = new mapboxgl.Marker(el)
              .setLngLat([element.geometry.coordinates[0], element.geometry.coordinates[1]])
              .addTo(map._map)

            marker.setPopup(popup)
          
            //marker._element.id = count
            //this._markers.push(marker)
            //count += 1
            //console.log(count)
          
          })

          for (let index = 1; index < map._markers.length; index++) {
            let marker = document.getElementById(index)
          
            marker.addEventListener('click', (m) => {
          
              let pp = map._markers[index]._popup._content.textContent
              console.log(pp)
          
            })
          
            btns.push(marker)
          }

      */

})()