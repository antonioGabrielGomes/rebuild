'use strict'

class Data {

    constructor(){
        this._data = null

        this.dataPopulate()
    }

    dataPopulate(){
        this._data =  {
            type: 'FeatureCollection',
            features: []
        }
    }

    getRandomArbitrary(min = 99, max = 9999) {
        return Math.random() * (max - min) + min;
    }

    pushMarker(marker = null){
        if (!marker) throw new Error('Object Empty')
        
        let feature = { 
            "type": "Feature",
            "properties": { },
            "geometry": {
                "type": "Point",
                "coordinates": [
                    marker._lngLat.lng,
                    marker._lngLat.lat
                ]
            }
        }

        this._data.features.push(feature)

        /*
        this._data.features.push({
            "type": "Feature",
            "properties": {
              "marker-color": "#7e7e7e",
              "marker-size": "medium",
              "marker-symbol": "",
              "description": "teste"
            },
            "geometry": {
              "type": "Point",
              "coordinates": [
                -56.304931640625,
                -12.65373802009225
              ]
            }
          })
          */
    }


}