'use strict'

class Mapb {

    constructor(token = null){
        this._token = token
        this._map = null
        this._ctoPorts = 0
        this._historyPoint = []
        this._residences = 0
        this._rateTX = 0
        this._ctoAmount = 0
        
        this._elementLog = null
        this._buttonReset = null
        this._inputRate = null
        this._inputPorts = null
        this._buttonDownloadKml = null

        this._markers = []
        this._buttonsMarkers = []
        this.Data = new Data()

        this.setMap()
        this.getElements()
        this.init()
        this.lngLatMap()
    }

    /** configurations */

    init(){
        this._rateTX = 0.5 // 50%
        this._ctoPorts = 8 // 8 ports

        this._buttonReset.addEventListener('click', () => {
            this.reset()
        })

        this._inputPorts.addEventListener('change', ()=> {

            if(this._inputPorts.value != '') 
                this._ctoPorts = parseFloat(this._inputPorts.value)
            else 
                this._ctoPorts = 8

            if(isNaN(this._ctoPorts))
                alert('NaN')

        })

        this._inputRate.addEventListener('change', ()=> {

            if(this._inputRate.value != '') 
                this._rateTX = parseFloat(this._inputRate.value)
            else 
                this._rateTX = 0.5

            if(isNaN(this._rateTX))
                alert('NaN')
               
        })

        this._buttonDownloadKml.addEventListener('click', (e) => {
            e.preventDefault()
         
            
            console.log(JSON.stringify(this.Data._data))
            let content = tokml(this.Data._data)     
                   
            console.log(content)
            

           // console.log(this._map._container.get('map'))

            /*
            const saveAs = new FileSaver(),
                  content = tokml(context.data.get('map')),
                  meta = context.data.get('meta')
                        
            saveAs(new Blob([content], {
                    type: 'text/plain;charset=utf-8'
            }), 'map.kml');            

            tokml = require('tokml'),
            function downloadKML() {
                if (d3.event) d3.event.preventDefault();
                var content = tokml(context.data.get('map'));
                var meta = context.data.get('meta');
                saveAs(new Blob([content], {
                    type: 'text/plain;charset=utf-8'
                }), 'map.kml');
            }
            */

        })

    }

    reset(){
        this._residences = 0
        this._ctoAmount = 0
        this._historyPoint = []

        this.showDataInLog('')
    }

    getElements(){
        this._elementLog = document.getElementById('log')
        this._buttonReset = document.getElementById('reset_count')
        this._inputRate = document.getElementById('rate')
        this._inputPorts = document.getElementById('ports')
        this._buttonDownloadKml = document.getElementById('download_kml')
    }

    setMap(){
        mapboxgl.accessToken = this._token
        this._map = new mapboxgl.Map({
            container: 'map',
            //style: 'mapbox://styles/mapbox/streets-v11', // stylesheet location
            style: 'mapbox://styles/mapbox/satellite-v9', // stylesheet location
            center: [-47.89924385434929, -1.291666697362116], // starting position [lng, lat]
            zoom: 4 // starting zoom
        })
    }

    /** interation */
    calculate(){
        this._ctoAmount = (this._residences * this._rateTX) / this._ctoPorts

        let log = `Qtd Residencias: ${this._residences} <br>
        Qtd CTO para a rua: ${parseInt(this._ctoAmount)}`

        this.showDataInLog(log)
        this.showMarkers()
    }

    showDataInLog(log){
        this._elementLog.innerHTML = log
    }

    showMarkers(){
        if(this._ctoAmount >= 3){
            let fixo = this._ctoAmount
            let result = fixo + 1
            let elementIndex = []

            do {
                result = this._historyPoint.length / fixo

                if(result > fixo){
                    fixo += 1
                }

            } while(fixo < result)
        
            fixo = parseInt(fixo)

            //let pointCount = this._historyPoint.length * this._rateTX
            //let rest = this._historyPoint.length - pointCount
            //let percent = parseInt(rest * this._rateTX)
            //let elementIndex = []

            
            for (let index = 0; index < this._historyPoint.length; ) {
                elementIndex.push(this._historyPoint[index])                
                index += fixo
            }

        
            elementIndex.forEach(element => {
                let marker = new mapboxgl.Marker({ draggable: true })
                    .setLngLat([element.geometry.coordinates[0], element.geometry.coordinates[1]])
                    .addTo(this._map)      
                    
                this.Data.pushMarker(marker)
            })

                        
        }
    }
    
    
    lngLatMap(){

        this._map.on('click', e => {
            //console.log(e.lngLat)
        })

    }
}

//https://docs.mapbox.com/mapbox-gl-js/example/drag-a-marker/