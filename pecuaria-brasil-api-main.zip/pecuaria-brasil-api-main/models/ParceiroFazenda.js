'use strict';

const {
  Model
} = require('sequelize');

module.exports = (sequelize, DataTypes) => {

  class ParceiroFazenda extends Model {

    static associate(models) {

      this.belongsTo(models.Parceiro, { foreignKey: 'cod_parceiro', as: 'parceiro' })
      this.belongsTo(models.Fazenda, { foreignKey: 'cod_fazenda', as: 'fazenda' })

    }

  };

  ParceiroFazenda.init({
  }, {
    sequelize,
    modelName: 'ParceiroFazenda',
    tableName: 'parceiro_fazenda'
  });

  return ParceiroFazenda;
};