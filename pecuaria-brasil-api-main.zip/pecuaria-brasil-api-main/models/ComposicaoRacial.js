'use strict';
 
const { 
    Model
  } = require('sequelize');
  


module.exports = (sequelize, DataTypes) => {

    class ComposicaoRacial extends Model {
        
        static associate(models){

            this.belongsTo(models.Raca, { foreignKey: 'cod_raca', as: 'raca' }) 
            this.belongsTo(models.Animal, { foreignKey: 'cod_animal', as: 'animal' }) 
       
        }

    }

    ComposicaoRacial.init({
        teor: DataTypes.FLOAT
    }, {
        sequelize,
        modelName: 'ComposicaoRacial',
        tableName: 'composicao_racial'
    })

    return ComposicaoRacial
}