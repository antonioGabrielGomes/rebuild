'use strict';

const {
  Model
} = require('sequelize'); 

module.exports = (sequelize, DataTypes) => {

  class Retiro extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      
        this.belongsTo(models.Fazenda, { foreignKey: 'cod_fazenda', as: 'fazenda' })
        this.hasMany(models.Pasto, { foreignKey: 'cod_retiro', as: 'pastos' })

    }
    
  };

  Retiro.init({
    retiro_nome: DataTypes.STRING,
  }, {
    sequelize,
    modelName: 'Retiro',
    tableName: 'retiro'
  });

  return Retiro;
};