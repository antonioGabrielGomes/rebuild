'use strict';

const {
  Model
} = require('sequelize');

module.exports = (sequelize, DataTypes) => {

  class Cidade extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */ 
    static associate(models) {
      
        this.belongsTo(models.Estado, { foreignKey: 'cod_estado', as: 'estado' })
        this.hasMany(models.Fazenda, { foreignKey: 'cod_cidade', as: 'fazendas' })
        this.hasMany(models.Parceiro, { foreignKey: 'cod_cidade', as: 'parceiros' })
    }
    
  };

  Cidade.init({
    cidade_nome: DataTypes.STRING
  }, {
    sequelize,
    modelName: 'Cidade',
    tableName: 'cidade'
  });

  return Cidade;
};