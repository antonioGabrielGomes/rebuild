'use strict';

const {
    Model
} = require('sequelize');


module.exports = (sequelize, DataTypes) => {

    class LoteVenda extends Model {

        static associate(models) {


            this.belongsTo(models.Parceiro, { foreignKey: 'cod_parceiro', as: 'parceiro' })
            this.belongsTo(models.Lote, { foreignKey: 'cod_lote', as: 'lote' })
            this.hasMany(models.VendaAnimal, { foreignKey: 'cod_lote_venda', as: 'lote_vendas' }) 


        }

    };

    LoteVenda.init({
        data_venda: DataTypes.STRING,
        tipo_saida: DataTypes.INTEGER,
        referencia_venda: DataTypes.STRING,
        quantidade: DataTypes.INTEGER,
        preco_venda: DataTypes.FLOAT,
        tipo_venda: DataTypes.FLOAT,
        preco_frete: DataTypes.FLOAT,
        observacao: DataTypes.STRING,
        venda_confirmada: DataTypes.BOOLEAN
    }, {
        sequelize,
        modelName: 'LoteVenda',
        tableName: 'lote_venda'
    });

    return LoteVenda;
};