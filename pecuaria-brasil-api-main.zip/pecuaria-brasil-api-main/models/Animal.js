'use strict';

const { 
  Model
} = require('sequelize');

module.exports = (sequelize, DataTypes) => {

  class Animal extends Model {
   
    static associate(models) {
           
      this.belongsTo(models.Lote, { foreignKey: 'cod_lote', as: 'lote' })     
      this.belongsTo(models.CategoriaSexo, { foreignKey: 'cod_categoria_sexo', as: 'categoria_sexo' })
      this.belongsTo(models.CondicaoRegistro, { foreignKey: 'cod_condicao_registro', as: 'condicao_registro' })
      this.belongsTo(models.Fazenda,  { foreignKey: 'cod_fazenda', as: 'origem_fazenda' })
      this.belongsTo(models.Parceiro,  { foreignKey: 'cod_parceiro', as: 'origem_parceiro' }) 
      this.belongsTo(models.Pasto,  { foreignKey: 'cod_pasto', as: 'pasto' }) 

      this.hasMany(models.VendaAnimal, { foreignKey: 'cod_animal', as: 'venda_animais' })
      this.hasMany(models.ComposicaoRacial, { foreignKey: 'cod_animal', as: 'racas' })

    }
    
  };

  Animal.init({    
    numero: DataTypes.STRING,
    brinco_manejo: DataTypes.STRING, 
    brinco_sis_bov: DataTypes.STRING,
    sexo: DataTypes.STRING,
    ativo:  DataTypes.BOOLEAN,
    primeiro_peso:  DataTypes.FLOAT,
    data_nascimento: DataTypes.STRING,
    rgn: DataTypes.STRING,
    rgd_fbb: DataTypes.STRING,
    doadora_receptora: DataTypes.INTEGER,
    tipo_parto: DataTypes.INTEGER,
    situacao_nascimento: DataTypes.INTEGER,
    tipo_aleitamento: DataTypes.INTEGER,
    transferencia_embriao: DataTypes.INTEGER,
    data_desmame: DataTypes.STRING
  }, {
    sequelize,
    modelName: 'Animal',
    tableName: 'animal'
  });

  return Animal;
};