'use strict';


const {
  Model
} = require('sequelize');

module.exports = (sequelize, DataTypes) => {

  class Parceiro extends Model {

    static associate(models) {

      this.belongsTo(models.Cidade, { foreignKey: 'cod_cidade', as: 'cidade' })
      this.hasMany(models.LoteVenda, { foreignKey: 'cod_parceiro', as: 'lote_vendas' })
      this.hasMany(models.ParceiroFazenda, { foreignKey: 'cod_parceiro', as: 'fazendas' })
      this.hasMany(models.Animal, { foreignKey: 'cod_parceiro', as: 'parceiros'})


    }

  };

  Parceiro.init({
    parceiro_nome: DataTypes.STRING,
    email: DataTypes.STRING,
    tipo: DataTypes.INTEGER,
    cpf: DataTypes.STRING,
    inscricao_estadual: DataTypes.STRING,
    telefone: DataTypes.STRING,
    celular: DataTypes.STRING,
    endereco: DataTypes.STRING,
    cep: DataTypes.STRING,
    incra: DataTypes.STRING
  }, {
    sequelize,
    modelName: 'Parceiro',
    tableName: 'parceiro'
  });

  return Parceiro;
};