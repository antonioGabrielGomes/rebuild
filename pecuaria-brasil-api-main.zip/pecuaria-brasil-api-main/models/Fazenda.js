'use strict';

const {
  Model
} = require('sequelize');

module.exports = (sequelize, DataTypes) => {

  class Fazenda extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      
      this.hasMany(models.Retiro, { foreignKey: 'cod_fazenda', as: 'retiros' })
      this.belongsTo(models.Cidade, { foreignKey: 'cod_cidade', as: 'cidade' })
      this.hasMany(models.ParceiroFazenda, { foreignKey: 'cod_fazenda', as: 'parceiros' })
      this.hasMany(models.Animal, { foreignKey: 'cod_fazenda', as: 'animais'})

    }
    
  };

  Fazenda.init({
    fazenda_nome: DataTypes.STRING,
    latitude: DataTypes.STRING,
    longitude: DataTypes.STRING,
    area_pastagem: DataTypes.FLOAT,
    inscricao_estadual: DataTypes.STRING,
    incra: DataTypes.STRING,
    sis_bov: DataTypes.STRING,
    endereco: DataTypes.STRING,
    cep: DataTypes.STRING
  }, {
    sequelize,
    modelName: 'Fazenda',
    tableName: 'fazenda'
  });

  return Fazenda;
};