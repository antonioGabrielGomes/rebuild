'use strict';

const { 
  Model
} = require('sequelize');

module.exports = (sequelize, DataTypes) => {

  class VendaAnimal extends Model {
   
    static associate(models) {
           
      this.belongsTo(models.LoteVenda, { foreignKey: 'cod_lote_venda', as: 'lote_venda' })
      this.belongsTo(models.Animal, { foreignKey: 'cod_animal', as: 'animal'})

 
    }
    
  };

  VendaAnimal.init({    
    
  }, {
    sequelize,
    modelName: 'VendaAnimal',
    tableName: 'lote_venda_animal'
  });

  return VendaAnimal;
};