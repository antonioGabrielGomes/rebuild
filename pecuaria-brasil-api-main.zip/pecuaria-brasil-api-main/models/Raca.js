'use strict';
 
const { 
    Model
  } = require('sequelize');
  

module.exports = (sequelize, DataTypes) => {

    class Raca extends Model {
        
        static associate(models){

            this.hasMany(models.ComposicaoRacial, { foreignKey: 'cod_raca', as: 'animais' })
           // this.hasMany(models.Animal, { foreignKey: 'cod_animal', as: 'animais' }) 
      

        }

    }

    Raca.init({
        raca_nome:DataTypes.STRING,
        descricao: DataTypes.STRING
    }, {
        sequelize,
        modelName: 'Raca',
        tableName: 'raca'
    })

    return Raca
}