'use strict';
 
const { 
    Model
  } = require('sequelize');
  

module.exports = (sequelize, DataTypes) => {

    class CondicaoRegistro extends Model {
        
        static associate(models){
            this.hasMany(models.Animal, { foreignKey: 'cod_condicao_registro', as: 'animais' })
        }

    }

    CondicaoRegistro.init({
        condicao_nome: DataTypes.STRING,
        descricao: DataTypes.STRING
    }, {
        sequelize,
        modelName: 'CondicaoRegistro',
        tableName: 'condicao_registro'
    })

    return CondicaoRegistro
}