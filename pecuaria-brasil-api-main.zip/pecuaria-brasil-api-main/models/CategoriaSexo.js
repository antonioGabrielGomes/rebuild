'use strict';

const { 
    Model
  } = require('sequelize');
  

module.exports = (sequelize, DataTypes) => {

    class CategoriaSexo extends Model { 

        static associate(models) {
            this.hasMany(models.Animal, { foreignKey: 'cod_categoria_sexo', as: 'animais' })
            
            //this.belongsTo(models.Estado, { foreignKey: 'cod_estado', as: 'estado' })
            //this.hasMany(models.Fazenda, { foreignKey: 'cod_cidade', as: 'fazendas' })
            //this.hasMany(models.Parceiro, { foreignKey: 'cod_cidade', as: 'parceiros' })
        }

    };

    CategoriaSexo.init({
        categoria_nome: DataTypes.STRING,
        descricao: DataTypes.STRING
    }, {
        sequelize,
        modelName: 'CategoriaSexo',
        tableName: 'categoria_sexo'
    });

    return CategoriaSexo;
};