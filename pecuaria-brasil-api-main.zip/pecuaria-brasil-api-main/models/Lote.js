'use strict';

const {
  Model
} = require('sequelize');

module.exports = (sequelize, DataTypes) => {

  class Lote extends Model {
   
    static associate(models) {
          
      this.belongsTo(models.Pasto, { foreignKey: 'cod_pasto', as: 'pasto' })
      this.hasMany(models.Animal, { foreignKey: 'cod_lote', as: 'animais' })
      this.hasMany(models.LoteVenda, { foreignKey: 'cod_lote', as: 'lote_vendas' })

    }
    
  };

  Lote.init({    
    lote_nome: DataTypes.STRING,
    valor_medio_venda: DataTypes.FLOAT,
    peso_medio_venda: DataTypes.FLOAT,
    data_estimada_venda: DataTypes.STRING,
    descricao: DataTypes.STRING
  }, {
    sequelize,
    modelName: 'Lote',
    tableName: 'lote'
  });

  return Lote;
};