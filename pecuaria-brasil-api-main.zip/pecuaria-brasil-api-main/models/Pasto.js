'use strict';

const {
  Model
} = require('sequelize');

module.exports = (sequelize, DataTypes) => {

  class Pasto extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {

      this.belongsTo(models.Retiro, { foreignKey: 'cod_retiro', as: 'retiro' })
      this.belongsTo(models.TipoPasto, { foreignKey: 'cod_tipo_pasto', as: 'tipo_pasto' })

      this.hasMany(models.Animal, { foreignKey: 'cod_pasto', as: 'animais' })
      this.hasMany(models.Lote, { foreignKey: 'cod_pasto', as: 'lotes' })

    }

  };

  Pasto.init({
    pasto_nome: DataTypes.STRING,
    geojson: DataTypes.STRING,
    tamanho: DataTypes.FLOAT,
    lotacao_maxima: DataTypes.INTEGER,
    observacao: DataTypes.STRING,
    disponivel: DataTypes.BOOLEAN,
  }, {
    sequelize,
    modelName: 'Pasto',
    tableName: 'pasto'
  });

  return Pasto;
};