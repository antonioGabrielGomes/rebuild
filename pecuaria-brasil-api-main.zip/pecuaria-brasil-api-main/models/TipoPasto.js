'use strict';

const {
    Model
} = require('sequelize') 

module.exports = (sequelize, DataTypes) => {

    class TipoPasto extends Model {

        static associate(models) {

            this.hasMany(models.Pasto, { foreignKey: 'cod_tipo_pasto', as: 'pastos' })

        }

    }

    TipoPasto.init({
        tipo_nome: DataTypes.STRING,
        descricao: DataTypes.STRING
    }, {
        sequelize,
        modelName: 'TipoPasto',
        tableName: 'tipo_pasto'
    })

    return TipoPasto
}