'use strict';

module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.createTable('lote', {
      id: {
        type: Sequelize.INTEGER,
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,        
      },
      cod_pasto: {  
        type: Sequelize.INTEGER,
        allowNull: true,
        references: {
          model: 'pasto',
          key: 'id'
        },
        onUpdate: 'CASCADE',
        onDelete: 'CASCADE'
      },
      lote_nome: {
        type: Sequelize.STRING(80),
        allowNull: false,
        unique: true
      },
      valor_medio_venda: {
        type: Sequelize.DECIMAL,
        allowNull: true
      },
      peso_medio_venda: {
        type: Sequelize.DECIMAL,
        allowNull: true
      },
      data_estimada_venda: {
        type: Sequelize.STRING(15), 
        allowNull: true
      },
      descricao: {
        type: Sequelize.STRING(255), 
        allowNull: true
      },
      created_at: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updated_at: {
        allowNull: false,
        type: Sequelize.DATE
      }
    })

  },

  down: async (queryInterface, Sequelize) => {
    await queryInterface.dropTable('lote')
  }
};
