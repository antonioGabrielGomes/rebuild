'use strict';

module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.createTable('animal', {
      id: {
        type: Sequelize.INTEGER,
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
      },
      numero: {
        type: Sequelize.STRING(20),
        allowNull: true,
        unique: true
      },
      brinco_manejo: {
        type: Sequelize.STRING(20),
        allowNull: true,
        unique: true
      },
      brinco_sis_bov: {
        type: Sequelize.STRING(20),
        allowNull: true,
        unique: true
      },
      sexo: {
        type: Sequelize.STRING(1),
        allowNull: true
      },
      ativo: {
        type: Sequelize.BOOLEAN,
        allowNull: false
      },
      primeiro_peso: {
        type: Sequelize.DECIMAL,
        allowNull: true
      },
      data_nascimento: {
        type: Sequelize.STRING(15),
        allowNull: true
      },
      rgn: {
        type: Sequelize.STRING(15),
        allowNull: true
      },
      rgd_fbb: {
        type: Sequelize.STRING(15),
        allowNull: true
      },
      doadora_receptora: {
        type: Sequelize.INTEGER,
        allowNull: true
      },
      tipo_parto: {
        type: Sequelize.INTEGER,
        allowNull: true
      },
      situacao_nascimento: {
        type: Sequelize.INTEGER,
        allowNull: true
      },
      tipo_aleitamento: {
        type: Sequelize.INTEGER,
        allowNull: true
      },
      transferencia_embriao: {
        type: Sequelize.INTEGER,
        allowNull: true
      },
      data_desmame: {
        type: Sequelize.STRING(15),
        allowNull: true
      },
      cod_categoria_sexo: {
        type: Sequelize.INTEGER,
        allowNull: true,
        references: {
          model: 'categoria_sexo',
          key: 'id'
        },
        onUpdate: 'CASCADE',
        onDelete: 'SET NULL'
      },
      cod_lote: {
        type: Sequelize.INTEGER,
        allowNull: true,
        references: {
          model: 'lote',
          key: 'id'
        },
        onUpdate: 'CASCADE',
        onDelete: 'SET NULL'
      },
      cod_retiro: {

        type: Sequelize.INTEGER,
        allowNull: true,
        references: {
          model: 'retiro',
          key: 'id'
        },
        onUpdate: 'CASCADE',
        onDelete: 'SET NULL'
      },
      cod_pasto: {
        type: Sequelize.INTEGER,
        allowNull: true,
        references: {
          model: 'pasto',
          key: 'id'
        },
        onUpdate: 'CASCADE',
        onDelete: 'SET NULL'
      },
      cod_grupo: {
        type: Sequelize.INTEGER,
        allowNull: true,
        references: {
          model: 'grupo',
          key: 'id'
        },
        onUpdate: 'CASCADE',
        onDelete: 'SET NULL'
      },
      cod_condicao_registro: {
        type: Sequelize.INTEGER,
        allowNull: true,
        references: {
          model: 'condicao_registro',
          key: 'id'
        },
        onUpdate: 'CASCADE',
        onDelete: 'SET NULL'
      },
      cod_pai: {
        type: Sequelize.INTEGER,
        allowNull: true,
        references: {
          model: 'animal',
          key: 'id'
        },
        onUpdate: 'CASCADE',
        onDelete: 'SET NULL'
      },
      cod_mae: {
        type: Sequelize.INTEGER,
        allowNull: true,
        references: {
          model: 'animal',
          key: 'id'
        },
        onUpdate: 'CASCADE',
        onDelete: 'SET NULL'
      },
      cod_fazenda: {
        type: Sequelize.INTEGER,
        allowNull: true,
        references: {
          model: 'fazenda',
          key: 'id'
        },
        onUpdate: 'CASCADE',
        onDelete: 'SET NULL'
      },
      cod_parceiro: {
        type: Sequelize.INTEGER,
        allowNull: true,
        references: {
          model: 'parceiro',
          key: 'id'
        },
        onUpdate: 'CASCADE',
        onDelete: 'SET NULL'
      },
      created_at: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updated_at: {
        allowNull: false,
        type: Sequelize.DATE
      }
    });


  },

  down: async (queryInterface, Sequelize) => {
    await queryInterface.dropTable('animal');

  }
};
