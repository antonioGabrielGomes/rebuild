'use strict';

module.exports = {
  up: async (queryInterface, Sequelize) => {
     await queryInterface.createTable('estado', {
      id: {
        type: Sequelize.INTEGER,
        allowNull: true,
        //allowNull: false,
        //autoIncrement: true,
        primaryKey: true,
      },
      estado_nome: {
        type: Sequelize.STRING(20)
      },
      codigo: {
        type: Sequelize.STRING(5)
      },
      created_at: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updated_at: {
        allowNull: false,
        type: Sequelize.DATE
      }
     });
  
  },

  down: async (queryInterface, Sequelize) => {
    await queryInterface.dropTable('estado');
  }
};
