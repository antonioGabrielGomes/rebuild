'use strict';

module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.createTable('lote_venda_animal', { 
      id: {
        type: Sequelize.INTEGER,
        allowNull: false,
        autoIncrement: true,
        primaryKey: true, 
      }, 
      cod_lote_venda: {
        type: Sequelize.INTEGER,
        allowNull: false,
        references: {
          model: 'lote_venda',
          key: 'id'
        },
        onUpdate: 'CASCADE',
        onDelete: 'CASCADE'
      },
      cod_animal: {
        type: Sequelize.INTEGER,
        allowNull: true,
        references: {
          model: 'animal',
          key: 'id'
        },
        onUpdate: 'CASCADE',
        onDelete: 'CASCADE'
      },
      created_at: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updated_at: {
        allowNull: false,
        type: Sequelize.DATE
      }
    });

  },

  down: async (queryInterface, Sequelize) => {

    await queryInterface.dropTable('lote_venda_animal');

  }
};
