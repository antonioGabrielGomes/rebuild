'use strict';

module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.createTable('parceiro', { 
      id: {
        type: Sequelize.INTEGER,
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
      },
      parceiro_nome: {
        type: Sequelize.STRING(50),
        allowNull: false,
        unique: true
      },
      email: {
        type: Sequelize.STRING(50),
        allowNull: false,
        unique: true
      },
      tipo: {
        type: Sequelize.INTEGER,
        allowNull: false
      },
      cpf: {
        type: Sequelize.STRING(20), 
        allowNull: true
      },
      inscricao_estadual: {
        type: Sequelize.STRING(20),
        allowNull: true
      },
      telefone: {
        type: Sequelize.STRING(20),
        allowNull: true
      },
      celular: { //------
        type: Sequelize.STRING(20),
        allowNull: true
      },
      endereco: {
        type: Sequelize.STRING(200),
        allowNull: true,
      },   
      cep: {
        type: Sequelize.STRING(15),
        allowNull: true
      },       
      cod_cidade: {
        type: Sequelize.INTEGER,
        allowNull: true,
        references: {
          model: 'cidade',
          key: 'id'
        },
        onUpdate: 'CASCADE',
        onDelete: 'SET NULL'
      },
      incra: {
        type: Sequelize.STRING(20),
        allowNull: true,
        unique: true
      },
      created_at: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updated_at: {
        allowNull: false,
        type: Sequelize.DATE
      }
    });
  },

  down: async (queryInterface, Sequelize) => {
    await queryInterface.dropTable('tipo_venda');
  }
};
