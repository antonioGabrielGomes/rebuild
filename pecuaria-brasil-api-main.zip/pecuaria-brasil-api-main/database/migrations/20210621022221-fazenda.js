'use strict';

module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.createTable('fazenda', {
      id: {
        type: Sequelize.INTEGER,
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,        
      },
      fazenda_nome: {
        type: Sequelize.STRING(80),
        allowNull: false,
        unique: true
      },
      latitude: {
        type: Sequelize.STRING(20),
      },
      longitude: {
        type: Sequelize.STRING(20),
      },
      area_pastagem: {
        type: Sequelize.DECIMAL,
      },
      inscricao_estadual: {
        type: Sequelize.STRING(20),      
        unique: true
      },
      incra: {
        type: Sequelize.STRING(20),
        unique: true
      },
      sis_bov: {
        type: Sequelize.STRING(20),
        unique: true
      },
      endereco: {
        type: Sequelize.STRING(200),
        allowNull: false,
      },   
      cep: {
        type: Sequelize.STRING(15)
      },       
      cod_cidade: {
        type: Sequelize.INTEGER,
        allowNull: true,
        references: {
          model: 'cidade',
          key: 'id'
        },
        onUpdate: 'CASCADE',
        onDelete: 'SET NULL'
      },
      created_at: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updated_at: {
        allowNull: false,
        type: Sequelize.DATE
      }
    })
  },

  down: async (queryInterface, Sequelize) => {
    await queryInterface.dropTable('fazenda')
  }
};
