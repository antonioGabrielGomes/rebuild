'use strict';

module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.createTable('animal', {
      id: {
        type: Sequelize.INTEGER,
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
      },
      cod_lote: {
        type: Sequelize.INTEGER,
        allowNull: false,
        references: {
          model: 'lote',
          key: 'id'
        },
        onUpdate: 'CASCADE',
        onDelete: 'CASCADE'
      },
      // ... ativo ? true or false
      created_at: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updated_at: {
        allowNull: false,
        type: Sequelize.DATE
      }
    });


  },

  down: async (queryInterface, Sequelize) => {
    await queryInterface.dropTable('animal');

  }
};
