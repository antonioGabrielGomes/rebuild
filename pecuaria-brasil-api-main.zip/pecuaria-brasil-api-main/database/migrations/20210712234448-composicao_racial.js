'use strict';

module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.createTable('composicao_racial', {
      id: {
        type: Sequelize.INTEGER,
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
      },
      cod_raca: { 
        type: Sequelize.INTEGER,
        allowNull: true,
        references: {
          model: 'raca',
          key: 'id'
        },
        onUpdate: 'CASCADE',
        onDelete: 'SET NULL'
      },
      cod_animal: {
        type: Sequelize.INTEGER,
        allowNull: true,
        references: {
          model: 'animal',
          key: 'id'
        },
        onUpdate: 'CASCADE',
        onDelete: 'SET NULL'
      },
      teor: {
        type: Sequelize.DECIMAL,
        allowNull: false
      },
      created_at: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updated_at: {
        allowNull: false,
        type: Sequelize.DATE
      }
     });
   
  },

  down: async (queryInterface, Sequelize) => {

    await queryInterface.dropTable('composicao_racial');
    
  }
};
