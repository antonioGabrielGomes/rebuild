'use strict';

module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.createTable('pasto', {
      id: {
        type: Sequelize.INTEGER,
        allowNull: false,
        autoIncrement: true,
        primaryKey: true
      },
      pasto_nome: {
        type: Sequelize.STRING(50),
        allowNull: false
      },
      geojson: {
        type: Sequelize.TEXT,
        allowNull: true
      },
      tamanho: {
        type: Sequelize.DECIMAL,
        allowNull: true
      },
      lotacao_maxima: {
        type: Sequelize.INTEGER,
        allowNull: true
      },
      observacao: {
        type: Sequelize.STRING(255),
        allowNull: true
      },
      disponivel: {
        type: Sequelize.BOOLEAN,
        allowNull: true
      },
      cod_tipo_pasto: {
        type: Sequelize.INTEGER,
        allowNull: false,
        references: {
          model: 'tipo_pasto',
          key: 'id'
        },
        onUpdate: 'CASCADE',
        onDelete: 'SET NULL'
      },
      cod_retiro: {
        type: Sequelize.INTEGER,
        allowNull: false,
        references: {
          model: 'retiro',
          key: 'id'
        },
        onUpdate: 'CASCADE',
        onDelete: 'CASCADE'
      },
      created_at: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updated_at: {
        allowNull: false,
        type: Sequelize.DATE
      }
    }, {})
  },

  down: async (queryInterface, Sequelize) => {
    await queryInterface.dropTable('pasto')
  }
};
