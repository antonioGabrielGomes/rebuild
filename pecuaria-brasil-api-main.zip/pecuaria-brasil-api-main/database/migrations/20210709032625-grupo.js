'use strict';

module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.createTable('grupo', {
      id: {
        type: Sequelize.INTEGER,
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
      }
    });


    /**
     * 
     * cadastro prévio

produção, reprodução e lactação ?


Fêmea Mamando/Borrega Recria
Bezerra Mamando/Fêmea em Recria
Borrega Apta/Matriz 
Novilha Apta/Vaca 


Reprodutor
Matrize
Bezerro
     */
  },

  down: async (queryInterface, Sequelize) => {
    await queryInterface.dropTable('grupo');

  }
};
