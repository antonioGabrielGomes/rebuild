'use strict';

module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.createTable('lote_venda', { 
      id: {
        type: Sequelize.INTEGER,
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
      },
      cod_lote: {
        type: Sequelize.INTEGER,
        allowNull: false,
        references: {
          model: 'lote',
          key: 'id'
        },
        onUpdate: 'CASCADE',
        onDelete: 'CASCADE'
      },
      cod_parceiro: {
        type: Sequelize.INTEGER,
        allowNull: true,
        references: {
          model: 'parceiro',
          key: 'id'
        },
        onUpdate: 'CASCADE',
        onDelete: 'SET NULL'
      },
      data_venda: {
        type: Sequelize.STRING(15),
        allowNull: false
      },
      tipo_saida: {
        type: Sequelize.INTEGER,
        allowNull: false
      },
      referencia_venda: {
        type: Sequelize.STRING(20),
        allowNull: false
      },
      quantidade: {
        type: Sequelize.INTEGER,
        allowNull: false
      },
      preco_venda: {
        type: Sequelize.DECIMAL,
        allowNull: false
      },
      tipo_venda: {
        type: Sequelize.INTEGER,
        allowNull: false
      },
      preco_frete: {
        type: Sequelize.DECIMAL,
        allowNull: true
      },
      observacao: {
        type: Sequelize.STRING(255),
        allowNull: true
      },
      venda_confirmada: {
        type: Sequelize.BOOLEAN,
        allowNull: false
      },
      created_at: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updated_at: {
        allowNull: false,
        type: Sequelize.DATE
      }
    });

  },

  down: async (queryInterface, Sequelize) => {
    await queryInterface.dropTable('lote_venda');
  }
};
