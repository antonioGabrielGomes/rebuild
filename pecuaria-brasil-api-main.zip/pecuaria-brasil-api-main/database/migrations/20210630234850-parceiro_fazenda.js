'use strict';

module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.createTable('parceiro_fazenda', {
      id: {
        type: Sequelize.INTEGER,
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
      },
      cod_parceiro: {
        type: Sequelize.INTEGER, 
        allowNull: false,
        references: {
          model: 'parceiro',
          key: 'id'
        },
        onUpdate: 'CASCADE',
        onDelete: 'CASCADE'
      },
      cod_fazenda: {
        type: Sequelize.INTEGER,
        allowNull: true,
        references: {
          model: 'fazenda',
          key: 'id'
        },
        onUpdate: 'CASCADE',
        onDelete: 'CASCADE'
      },
      created_at: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updated_at: {
        allowNull: false,
        type: Sequelize.DATE
      }

    });

  },

  down: async (queryInterface, Sequelize) => {
    await queryInterface.dropTable('parceiro_fazenda');

  }
};
