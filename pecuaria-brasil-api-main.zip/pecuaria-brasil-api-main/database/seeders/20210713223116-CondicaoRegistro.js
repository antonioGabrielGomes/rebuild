'use strict';

module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.bulkInsert('condicao_registro', [{
      condicao_nome: "Não Registrado",
      descricao: "",
      created_at: new Date(),
      updated_at: new Date()
    },{
      condicao_nome: "Registrado (s/confirmação)",
      descricao: "",
      created_at: new Date(),
      updated_at: new Date()
    },{
      condicao_nome: "Registrado (confirmado)",
      descricao: "",
      created_at: new Date(),
      updated_at: new Date()
    },{
      condicao_nome: "Não Apto",
      descricao: "",
      created_at: new Date(),
      updated_at: new Date()
    }], {}); 
  },

  down: async (queryInterface, Sequelize) => {
    await queryInterface.bulkDelete('condicao_registro', null, {});
  }
};
