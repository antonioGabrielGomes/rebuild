'use strict';

module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.bulkInsert('categoria_sexo', [{
      categoria_nome: "Produção",
      descricao: "",
      created_at: new Date(),
      updated_at: new Date()
    },{
      categoria_nome: "Reprodução",
      descricao: "",
      created_at: new Date(),
      updated_at: new Date()
    },{
      categoria_nome: "Lactação",
      descricao: "",
      created_at: new Date(),
      updated_at: new Date()
    },{
      categoria_nome: "Fêmea Mamando/Borrega Recria",
      descricao: "",
      created_at: new Date(),
      updated_at: new Date()
    },{
      categoria_nome: "Bezerra Mamando/Fêmea em Recria",
      descricao: "",
      created_at: new Date(),
      updated_at: new Date()
    },{
      categoria_nome: "Borrega Apta/Matriz",
      descricao: "",
      created_at: new Date(),
      updated_at: new Date()
    },{
      categoria_nome: "Novilha Apta/Vaca",
      descricao: "",
      created_at: new Date(),
      updated_at: new Date()
    },{
      categoria_nome: "Matrize",
      descricao: "",
      created_at: new Date(),
      updated_at: new Date()
    },{
      categoria_nome: "Reprodutor",
      descricao: "",
      created_at: new Date(),
      updated_at: new Date()
    },{
      categoria_nome: "Bezerro",
      descricao: "",
      created_at: new Date(),
      updated_at: new Date()
    }], {}); 
  },

  down: async (queryInterface, Sequelize) => {
    await queryInterface.bulkDelete('categoria_sexo', null, {});
  }
};
