'use strict';

module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.bulkInsert('cidade', [{
      cidade_nome: 'Castanhal',
      cod_estado: 1,
      created_at: new Date(),
      updated_at: new Date()
    },
    {
      cidade_nome: 'Igarape Açu',
      cod_estado: 1,
      created_at: new Date(),
      updated_at: new Date()
    },
    {
      cidade_nome: 'Peixe Boi',
      cod_estado: 1,
      created_at: new Date(),
      updated_at: new Date()
    }], {});
  },

  down: async (queryInterface, Sequelize) => {
    await queryInterface.bulkDelete('cidade', null, {});
  }
};

