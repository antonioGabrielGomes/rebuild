'use strict';

module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.bulkInsert('tipo_pasto', [{
      tipo_nome: 'Pastagem',
      descricao: "No Brasil cerca de 95% da carne bovina é produzida em regime de pastagens, cuja área total é de cerca de 167 milhões de hectares. Essa particularidade aumenta a competitividade do nosso produto: menor custo de produção, não compete com a alimentação humana e ainda confere um diferencial qualitativo à carne brasileira por não apresentar riscos associados ao “mal da vaca louca”, que está relacionado ao uso de proteína animal na alimentação do rebanho. Mais Em <a href='https://www.embrapa.br/qualidade-da-carne/carne-bovina/producao-de-carne-bovina/pastagem'>EMBRAPA</a>"
      ,
      created_at: new Date(),
      updated_at: new Date()
    },{
      tipo_nome: 'Confinamento',
      descricao: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent non lorem ac nunc tristique consectetur ac eget neque. Mauris pharetra quam eget sodales fringilla.'
      ,
      created_at: new Date(),
      updated_at: new Date()
    },{
      tipo_nome: 'Semi-Confinamento',
      descricao: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent non lorem ac nunc tristique consectetur ac eget neque. Mauris pharetra quam eget sodales fringilla.'
      ,
      created_at: new Date(),
      updated_at: new Date()
    }], {})
  },

  down: async (queryInterface, Sequelize) => {
   await queryInterface.bulkDelete('tipo_pasto', null, {});     
  }
};
