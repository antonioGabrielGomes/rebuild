'use strict';

module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.bulkInsert('raca', [{
      raca_nome: "Nelore",
      descricao: "",
      created_at: new Date(),
      updated_at: new Date()
    },{
      raca_nome: "Girolando",
      descricao: "",
      created_at: new Date(),
      updated_at: new Date()
    },{
      raca_nome: "Guzerá",
      descricao: "",
      created_at: new Date(),
      updated_at: new Date()
    },{
      raca_nome: "Honlandês",
      descricao: "",
      created_at: new Date(),
      updated_at: new Date()
    }], {}); 
  },

  down: async (queryInterface, Sequelize) => {
    await queryInterface.bulkDelete('raca', null, {});
  }
};
