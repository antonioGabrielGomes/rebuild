'use strict'

const express = require('express')
const routes = express.Router()

const FazendaController = require('../controllers/Fazenda')
const RetiroController = require('../controllers/Retiro')
const EstadoController = require('../controllers/Estado')
const TipoPastoController = require('../controllers/TipoPasto')
const PastoController = require('../controllers/Pasto')
const LoteController = require('../controllers/Lote')
const AnimalController = require('../controllers/Animal')
const ParceiroController = require('../controllers/Parceiro')
const LoteVendaController = require('../controllers/LoteVenda')
const VendaAnimalController = require('../controllers/VendaAnimal')

const LoteVendaQueryController = require('../controllers/querys/LoteVenda')


/** FAZENDA */
routes.post('/api/cadastro/fazenda', FazendaController.create)
routes.get('/api/lista/fazenda', FazendaController.findAll)
routes.get('/api/lista/fazenda/:id', FazendaController.findByPk)
routes.put('/api/atualiza/fazenda/:id', FazendaController.update)
//routes.delete('/api/delete/fazenda/:id', FazendaController.delete)

/** RETIRO */
routes.post('/api/cadastro/retiro', RetiroController.create)
routes.get('/api/lista/retiro', RetiroController.findAll)
routes.get('/api/lista/retiro/:id', RetiroController.findByPk)
routes.put('/api/atualiza/retiro/:id', RetiroController.update)
routes.delete('/api/remove/retiro/:id', RetiroController.delete)

/** TIPOS DE PASTOS */
routes.get('/api/lista/tipo_pasto', TipoPastoController.findAll)

/** PASTO */
routes.post('/api/cadastro/pasto', PastoController.create)
routes.get('/api/lista/pasto', PastoController.findAll)
routes.get('/api/lista/pasto/:id', PastoController.findByPk)
routes.put('/api/atualiza/pasto/:id', PastoController.update)
routes.delete('/api/remove/pasto/:id', PastoController.delete)

/** ESTADO E CIDADE */
routes.get('/api/lista/estado', EstadoController.findAll)
routes.get('/api/lista/estado/:id', EstadoController.findByPk)
//routes.get('/api/lista/estado/cidades/:id', EstadoController.findByPkAndIncludes)

/** LOTE */
routes.post('/api/cadastro/lote', LoteController.create)
routes.get('/api/lista/lote', LoteController.findAll)
routes.get('/api/lista/lote/:id', LoteController.findByPk)
routes.put('/api/atualiza/lote/:id', LoteController.update)
routes.delete('/api/remove/lote/:id', LoteController.delete)

/** ANIMAL */
routes.post('/api/cadastro/animal', AnimalController.create)


/** PARCEIRO */
routes.post('/api/cadastro/parceiro', ParceiroController.create)
routes.get('/api/lista/parceiro', ParceiroController.findAll)
routes.get('/api/lista/parceiro/:id', ParceiroController.findByPk)
routes.put('/api/atualiza/parceiro/:id', ParceiroController.update)
routes.delete('/api/remove/parceiro/:id', ParceiroController.delete)

/** LOTE_VENDA */
routes.post('/api/cadastro/lote-venda', LoteVendaController.create)
routes.get('/api/lista/lote-venda', LoteVendaController.findAll)
routes.get('/api/lista/lote-venda/:id', LoteVendaController.findByPk)
routes.put('/api/atualiza/lote-venda/:id', LoteVendaController.update)
routes.delete('/api/remove/lote-venda/:id', LoteVendaController.delete)

routes.put('/api/confirmar/venda/lote/:id', LoteVendaQueryController.confirmarVenda)

/** LOTE_VENDA */
routes.post('/api/cadastro/venda-animal', VendaAnimalController.create)
routes.delete('/api/remove/venda-animal', VendaAnimalController.delete)


module.exports = routes