'use strict'

require('dotenv-safe').config({
    path: process.env.NODE_ENV === 'test' ? '.env.test' : '.env',
    allowEmptyValues: true
})

require('express-async-errors')
const express = require('express')
const cors = require('cors')
const app = express()

app.use(cors("*"))
app.use(express.json())

const routes = require('./routes')
app.use(routes)
app.use((error, req, res, next) => {
    //
    console.warn(error.message)
    console.log(error)

    return res.status(404).json({
        message: error.message,
        data: []
    })
})

module.exports = app