# pecuaria-brasil-api

### OBSERVAÇÕES E DÚVIDAS


1. ALTERAÇÕES NO CONTROLLER PARA CADASTRO DE VENDAS  
  * adicionar animais no historico d movimentações como venda - APÓS A VENDA SER APROVADA! - querys>LoteVenda.js


---------
1. mudança de categoria por sexo de animal, depende da rotina de APTIDÃO DE FÊMEAS JOVENS - PAG 05/ 
2. Se registrado indique a Associação, a categoria de registro, o RGN e o RGD/FBB
3. Adicionar seguinte regra no controle de cadastro de raças: {
  * programa  aceita  animais  com  até  cinco  raças  diferentes  na  sua composição racial
}
4. Regra para cadastro de rgn e rgd/fbb: {
  * depende da condicao de registro :
  Se registrado indique a Associação, a categoria de registro, o RGN e o RGD/FBB
}
5. Para Cadastrar Origem:
- fazenda de onde veio o animal, em caso de compra, por exemplo
u Criador  
- fazenda onde nasceu o animal

DESSA FORMA AQUI>> dê um clique no botão  ao  lado  do  campo “Origem” ou “Proprietário” e selecione entre as opções

>> LISTAGEM DE FAZENDAS. 

É  importante  dizer  que  a  opção  de  selecionar  um  proprietário  diferente  da fazenda em que está sendo cadastrado um animal não está disponível para animais ativos, pois pressupões-se que o animal é de propriedade da fazenda. Esta opção está disponível no cadastro de “Animais externos” “Sêmen” ou “Arquivo morto” (vistos abaixo).

6. VOLTA NA PÁGINA 7 PARA IMPLEMENTAR AS FUNCIONALIDADES DE RELÁTORIO

7. TIPO PRINCIPAIS DE MOVIMENTAÇÕES: {
  * 1. ARQUVIO MORTO
  * 2. VENDA
}

###



### 

Painel
Financeiro
    Fluxo de Caixa
    Entrada e Saída
Relatórios        
    INVENTÁRIO DE ANIMAIS
    PESAGENS DO LOTE
    DESEMPENHO DOS CRIADORES
    DESEMPENHO DAS REÇAS
    MAPA SANITÁRIO
    DESEMPENHO REPRODUTIVO
    VENDA - GANHO DE PESO
    VENDA - FINANCEIRO
    VENDA - GERAL
    CUSTOS POR MÊS
    RESULTADO POR MÊS
    MOVIMENTAÇÕES MÊS
    GANHO POR MÊS
Estoque     
Movimentações
    AQUISIÇÕES
    SAÍDAS
    PERDAS E MORTES
Pesagem
..
..
Fazenda
    Fazendas
    Lotes
    Pastos
    Grupos
    Parceiros
    Categoria de Animais
Animais
    Lotes
    Animais
    PESAGEM
    SANITÁRIO
    NUTRICIONAL
    CASTRAÇÃO
    REPRODUTIVO
    TROCA DE LOTE
    CONTROLE DE SÊMEN
Usuarios
 
###


















###

PAINEL
FINANCEIRO
  FLUXO DE CAIXA
  PAGAR E RECEBER
ESTOQUE
DIETAS
ANIMAIS
LOTES
  GERENCIAMENTO DE ÁREAS E MODULOS
  GERENCIAMENTO DE LOTES
MANEJO
  PESAGEM
  SANITÁRIO
  NUTRICIONAL
  CASTRAÇÃO
  REPRODUTIVO
  TROCA DE LOTE
  CONTROLE DE SÊMEN
CUSTOS
  CUSTOS INDIRETOS
INTELIGÊNCIA
  SIMULADOR DE VENDAS
  MINHAS ANÁLISES
MOVIMENTAÇÕES
  AQUISIÇÕES
  SAÍDAS
  PERDAS E MORTES
PARCEIROS
RELATÓRIO DE ANIMAIS
  INVENTÁRIO DE ANIMAIS
  PESAGENS DO LOTE
  DESEMPENHO DOS CRIADORES
  DESEMPENHO DAS REÇAS
  MAPA SANITÁRIO
  DESEMPENHO REPRODUTIVO
  VENDA - GANHO DE PESO
  VENDA - FINANCEIRO
  VENDA - GERAL
  CUSTOS POR MÊS
  RESULTADO POR MÊS
  MOVIMENTAÇÕES MÊS
  GANHO POR MÊS
MEUS DADOS
  CATEGORIA DE ANIMAIS
    bezerro, novilho, boi, bezerra, novilha, vaca
  CATEGORIAS FINANCEIRAS
  CATÁLOGO DE ITENS
  FAZENDAS
  USUÁRIOS

###






-------------------------
conteudo do .sequelizerc
const path = require('path');

module.exports = {
  'config': path.resolve('config', 'database.js'),
  'models-path': path.resolve('models'),
  'seeders-path': path.resolve('database','seeders'),
  'migrations-path': path.resolve('database', 'migrations'),
};