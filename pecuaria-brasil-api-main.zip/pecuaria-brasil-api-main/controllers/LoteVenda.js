'use strict'

const { LoteVenda, Lote, Animal, Parceiro, Server, sequelize } = require('../models')

module.exports = {

    async create(req, res) {

        const {
            data_venda,
            tipo_saida,
            referencia_venda,
            quantidade,
            preco_venda,
            tipo_venda,
            preco_frete,
            observacao,
            cod_parceiro,
            cod_lote
        } = req.body

        let venda_confirmada = false


        if (!(cod_lote >= 1 && cod_lote <= 999999)) throw new Error("Lote não encontrado!")
        let lote = await Lote.findByPk(cod_lote, {
            include: {
                model: Animal,
                as: 'animais'
            }
        })
        if (!lote) throw new Error("Lote não encontradoo!")

        if (!(cod_parceiro >= 1 && cod_parceiro <= 999999)) throw new Error("Parceiro não encontrado!")
        let parceiro = await Parceiro.findByPk(cod_parceiro)
        if (!parceiro) throw new Error("Parceiro não encontrado!")

        /**
         QUEREMOS SABER A QUANTIDADE DE ANIMAIS CADASTRADOS NO LOTE cod_lote
         CASO A QUANTIDADE SEJA MENOR, NÃO PERMITIR OPERAÇÃO E
         ENVIAR MENSAGEM DE ERRO COM QUANTIDADE DE ANIMAIS RESTANTES
         */
        let quantidadeAnimais = lote.animais.length
        if (quantidadeAnimais < quantidade)
            throw new Error(`Quantidade de Animais restantes: ${quantidadeAnimais}`)

        //
        let loteVenda = await LoteVenda.create({
            data_venda,
            tipo_saida,
            referencia_venda,
            quantidade,
            preco_venda,
            tipo_venda,
            preco_frete,
            observacao,
            cod_parceiro,
            cod_lote,
            venda_confirmada 
        })

        if (!loteVenda) throw new Error("Venda não Cadastrada!")

        res.json({
            message: "Venda Cadastrada!",
            data: loteVenda
        })
    },

    async findAll(req, res) {

        let loteVendas = await LoteVenda.findAll({
            include: [{
                model: Parceiro,
                as: 'parceiro'
            }, {
                model: Lote,
                as: 'lote'
            }]
        })

        if (!loteVendas) throw new Error("Nenhum venda encontrada!")

        res.json({
            message: "Vendas encontradas!",
            data: loteVendas
        })
    },

    async findByPk(req, res) {
        const id = req.params.id
        if (!(id >= 1 && id <= 999999)) throw new Error("Venda não encontrada!")

        let loteVenda = await LoteVenda.findByPk(id, {
            include: [{
                model: Parceiro,
                as: 'parceiro'
            }, {
                model: Lote,
                as: 'lote'
            }]
        })

        if (!loteVenda) throw new Error("Venda não encontrada!")

        res.json({
            message: "Venda encontrada!",
            data: loteVenda
        })
    },

    async update(req, res) {
        const id = req.params.id
        if (!(id >= 1 && id <= 999999)) throw new Error("Venda não encontrada!")

        const {
            data_venda,
            tipo_saida,
            referencia_venda,
            quantidade,
            preco_venda,
            tipo_venda,
            preco_frete,
            observacao,
            cod_parceiro,
            cod_lote
        } = req.body


        let loteVenda = await LoteVenda.findByPk(id)
        if (!loteVenda) throw new Error("Venda não encontrada!")

        /**
         ADICIONAR VÁLIDAÇÃO: CASO A VENDA JÁ ESTEJA FINALIZADA 
         A OPERAÇÃO NÃO É MAIS PERMITIDA 
        
        if (loteVenda.confirmado)
            throw new Error(`Venda Finalizada!`)
        */

        //
        if (!(cod_lote >= 1 && cod_lote <= 999999)) throw new Error("Lote não encontrado!")
        let lote = await Lote.findByPk(cod_lote, {
            include: {
                model: Animal,
                as: 'animais'
            }
        })
        if (!lote) throw new Error("Lote não encontradoo!")

        if (!(cod_parceiro >= 1 && cod_parceiro <= 999999)) throw new Error("Parceiro não encontrado!")
        let parceiro = await Parceiro.findByPk(cod_parceiro)
        if (!parceiro) throw new Error("Parceiro não encontrado!")

        /**
         QUEREMOS SABER A QUANTIDADE DE ANIMAIS CADASTRADOS NO LOTE cod_lote
         CASO A QUANTIDADE SEJA MENOR, NÃO PERMITIR OPERAÇÃO E
         ENVIAR MENSAGEM DE ERRO COM QUANTIDADE DE ANIMAIS RESTANTES
         */
        let quantidadeAnimais = lote.animais.length
        if (quantidadeAnimais < quantidade)
            throw new Error(`Quantidade de Animais restantes: ${quantidadeAnimais}`)

        //

        await LoteVenda.update({
            data_venda,
            tipo_saida,
            referencia_venda,
            quantidade,
            preco_venda,
            tipo_venda,
            preco_frete,
            observacao,
            cod_parceiro,
            cod_lote
        }, {
            where: {
                id: id
            }
        })


        res.json({
            message: "Dados Atualizados!",
            data: []
        })
    },


    async delete(req, res) {
        const id = req.params.id
        if (!(id >= 1 && id <= 999999)) throw new Error("Venda não encontrada!")

        let loteVenda = await LoteVenda.findByPk(id)
        if (!loteVenda) throw new Error("Venda não encontrada!")

        /**
        CASO A VENDA JÁ ESTEJA FINALIZADA 
        A OPERAÇÃO NÃO É MAIS PERMITIDA 
        */
        if (loteVenda.venda_confirmada)
            throw new Error(`A venda não pode ser apagada!`)   

        //

        await LoteVenda.destroy({
            where: {
                id: id
            }
        })

        res.json({
            message: "Dados Apagados!",
            data: []
        })
    }

}

