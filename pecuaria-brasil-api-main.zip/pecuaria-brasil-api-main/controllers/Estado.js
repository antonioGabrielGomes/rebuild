'use strict'

const { Estado, Cidade, Server, sequelize } = require('../models')

module.exports = {

    async findAll(req, res) {
        let estados = await Estado.findAll()

        if (!estados) throw new Error("Nenhum estado encontrado!")

        res.json({
            message: "Estados encontrados!",
            data: estados
        })
    },


    async findByPk(req, res) {

        const id = req.params.id
        if (!(id >= 1 && id <= 999999)) throw new Error('Estado não encontrado!')

        const estado = await Estado.findByPk(id,
            {
                include: {
                    model: Cidade,
                    as: 'cidades'
                }
            })
        if (!estado) throw new Error('Estado não encontrado!')

        res.json({
            message: "Estado encontrado!",
            data: estado
        })
    },

    /**
    async findByPkAndIncludes(req, res) {

        const id = req.params.id
        if (!(id >= 1 && id <= 999999)) throw new Error('Estado não encontrado!')

        const estado = await Estado.findByPk(id, {
            include: {
                model: Cidade,
                as: 'cidades'
            }
        })
        if (!estado) throw new Error('Estado não encontrado!')

        res.json({
            data: estado
        })
    }
    */
}