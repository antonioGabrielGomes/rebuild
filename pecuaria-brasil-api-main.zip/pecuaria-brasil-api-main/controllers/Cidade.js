'use strict'

const { Cidade, Server, sequelize } = require('../models')

module.exports = {

    async findByPk(req, res) {
        const id = req.params.id
        if (!(id >= 1 && id <= 999999)) throw new Error('Código inválido!')

        const cidade = await Cidade.findByPk(id)

        if (!cidade) throw new Error("Cidade não encontrada!")

        res.json({
            data: cidade
        })
    },
    
}