'use strict'

const { Animal, Lote, Parceiro, Fazenda, CondicaoRegistro, CategoriaSexo, Pasto, Server, sequelize } = require('../models')

module.exports = {

    async create(req, res) {
        const {
            numero,
            brinco_manejo,
            brinco_sis_bov,
            sexo,
            primeiro_peso,
            data_nascimento,
            rgn,
            rgd_fbb,
            doadora_receptora,
            tipo_parto,
            situacao_nascimento,
            tipo_aleitamento,
            transferencia_embriao,
            data_desmame,

            cod_lote,
            cod_categoria_sexo,
            cod_condicao_registro,
            cod_fazenda,
            cod_parceiro,
            cod_pasto,
            cod_mae,
            cod_pai
            // cod_grupo
        } = req.body

        /** */
        if (!(cod_lote >= 1 && cod_lote <= 999999)) throw new Error("Lote não encontrado!")
        const lote = await Lote.findByPk(cod_lote)
        if (!lote) throw new Error("Lote não encontrado!")

        if (!(cod_categoria_sexo >= 1 && cod_categoria_sexo <= 999999))
            throw new Error("Categoria de sexo não encontrada!")
        const categoriaSexo = await CategoriaSexo.findByPk(cod_categoria_sexo)
        if (!categoriaSexo) throw new Error("Categoria de sexo não encontrada!")

        if (!(cod_condicao_registro >= 1 && cod_condicao_registro <= 999999))
            throw new Error("Condição de registro não encontrada!")
        const condicaoRegistro = await CondicaoRegistro.findByPk(cod_condicao_registro)
        if (!condicaoRegistro) throw new Error("Condição de registro não encontrada!")

        if (!(cod_fazenda >= 1 && cod_fazenda <= 999999))
            throw new Error("Fazenda não encontrada!")
        const fazenda = await Fazenda.findByPk(cod_fazenda)
        if (!fazenda) throw new Error("Fazenda não encontrada!")

        if (!(cod_parceiro >= 1 && cod_parceiro <= 999999))
            throw new Error("Parceiro não encontrado!")
        const parceiro = await Parceiro.findByPk(cod_parceiro)
        if (!parceiro) throw new Error("Parceiro não encontrado!")

        if (!(cod_pasto >= 1 && cod_pasto <= 999999))
            throw new Error("Pasto não encontrado!")
        const pasto = await Lote.findByPk(cod_pasto)
        if (!pasto) throw new Error("Pasto não encontrado!")

        if (!(cod_mae >= 1 && cod_mae <= 9999999))
            throw new Error("Mãe não encontrada!")
        let animal = await Animal.findByPk(cod_mae)
        if (!animal) throw new Error("Mãe não encontrada no registro!")

        if (!(cod_pai >= 1 && cod_pai <= 9999999))
            throw new Error("Pasto não encontrada!")
        animal = await Animal.findByPk(cod_pai)
        if (!animal) throw new Error("Pai não encontrado no registro!")

        /**  */
        animal = await Animal.create({
            numero,
            brinco_manejo,
            brinco_sis_bov,
            sexo,
            primeiro_peso,
            data_nascimento,
            rgn,
            rgd_fbb,
            doadora_receptora,
            tipo_parto,
            situacao_nascimento,
            tipo_aleitamento,
            transferencia_embriao,
            data_desmame,
            ativo: true,
            cod_lote,
            cod_categoria_sexo,
            cod_condicao_registro,
            cod_fazenda,
            cod_parceiro,
            cod_pasto,
            cod_mae,
            cod_pai
        })

        if (!animal) throw new Error("Animal não cadastrado!")

        res.json({
            message: "Animal Cadastrado!",
            data: animal
        })
    },

    async findAll(req, res) {
        let animais = await Animal.findAll({
            include: [{
                model: Lote,
                as: 'lote'
            }, {
                model: Pasto,
                as: 'pasto'
            },{
                model: CondicaoRegistro,
                as: 'condicao_registro'
            }]
        })

        if (!animais) throw new Error("Nenhum animal encontrado!")

        res.json({
            message: "Animais encontrados!",
            data: animais
        })
    },

    async findByPk(req, res) {
        const id = req.params.id
        if (!(id >= 1 && id <= 999999)) throw new Error("Animal não encontrado!")

        let animal = await Animal.findByPk(id, {
            include: [{
                model: Lote,
                as: 'lote'
            }, {
                model: Pasto,
                as: 'pasto'
            },{
                model: CondicaoRegistro,
                as: 'condicao_registro'
            }]
        })

        if (!animal) throw new Error("Nenhum animal encontrado!")

        res.json({
            message: "Animal encontrado!",
            data: animal
        })
    },

    async update(req, res) {
        const id = req.params.id
        if (!(id >= 1 && id <= 999999)) throw new Error("Lote não encontrado!")

        const {
            numero,
            brinco_manejo,
            brinco_sis_bov,
            sexo,
            primeiro_peso,
            data_nascimento,
            rgn,
            rgd_fbb,
            doadora_receptora,
            tipo_parto,
            situacao_nascimento,
            tipo_aleitamento,
            transferencia_embriao,
            data_desmame,

            cod_lote,
            cod_categoria_sexo,
            cod_condicao_registro,
            cod_fazenda,
            cod_parceiro,
            cod_pasto,
            cod_mae,
            cod_pai
            // cod_grupo
        } = req.body

        /** */
        if (!(cod_lote >= 1 && cod_lote <= 999999)) throw new Error("Lote não encontrado!")
        const lote = await Lote.findByPk(cod_lote)
        if (!lote) throw new Error("Lote não encontrado!")

        if (!(cod_categoria_sexo >= 1 && cod_categoria_sexo <= 999999))
            throw new Error("Categoria de sexo não encontrada!")
        const categoriaSexo = await CategoriaSexo.findByPk(cod_categoria_sexo)
        if (!categoriaSexo) throw new Error("Categoria de sexo não encontrada!")

        if (!(cod_condicao_registro >= 1 && cod_condicao_registro <= 999999))
            throw new Error("Condição de registro não encontrada!")
        const condicaoRegistro = await CondicaoRegistro.findByPk(cod_condicao_registro)
        if (!condicaoRegistro) throw new Error("Condição de registro não encontrada!")

        if (!(cod_fazenda >= 1 && cod_fazenda <= 999999))
            throw new Error("Fazenda não encontrada!")
        const fazenda = await Fazenda.findByPk(cod_fazenda)
        if (!fazenda) throw new Error("Fazenda não encontrada!")

        if (!(cod_parceiro >= 1 && cod_parceiro <= 999999))
            throw new Error("Parceiro não encontrado!")
        const parceiro = await Parceiro.findByPk(cod_parceiro)
        if (!parceiro) throw new Error("Parceiro não encontrado!")

        if (!(cod_pasto >= 1 && cod_pasto <= 999999))
            throw new Error("Pasto não encontrado!")
        const pasto = await Lote.findByPk(cod_pasto)
        if (!pasto) throw new Error("Pasto não encontrado!")

        let animal = await Animal.findByPk(id)
        if (!animal) throw new Error("Animal não encontrado!")
        /** VERIFICAR SE ANIMAL AINDA ESTÁ ATIVO NO REBANHO */
        if (animal.ativo) throw new Error('O animal selecionado não está disponível!')


        if (!(cod_mae >= 1 && cod_mae <= 9999999))
            throw new Error("Mãe não encontrada!")
        animal = await Animal.findByPk(cod_mae)
        if (!animal) throw new Error("Mãe não encontrada no registro!")

        if (!(cod_pai >= 1 && cod_pai <= 9999999))
            throw new Error("Pasto não encontrada!")
        animal = await Animal.findByPk(cod_pai)
        if (!animal) throw new Error("Pai não encontrado no registro!")
        /*
        await Animal.update({
            numero,
            brinco_manejo,
            brinco_sis_bov,
            sexo,
            primeiro_peso,
            data_nascimento,
            rgn,
            rgd_fbb,
            doadora_receptora,
            tipo_parto,
            situacao_nascimento,
            tipo_aleitamento,
            transferencia_embriao,
            data_desmame,

            cod_lote,
            cod_categoria_sexo,
            cod_condicao_registro,
            cod_fazenda,
            cod_parceiro,
            cod_pasto
            // cod_grupo
        }, {
            where: {
                id: id
            }
        })
        */


        res.json({
            message: "Dados Atualizados!",
            data: []
        })
    },

    async delete(req, res) {
        const id = req.params.id
        if (!(id >= 1 && id <= 999999)) throw new Error("Lote não encontrado!")

        const animal = await Animal.findByPk(id)
        if (!animal) throw new Error("Animal não encontrado!")
        /** VERIFICAR SE ANIMAL AINDA ESTÁ ATIVO NO REBANHO */
        if (animal.ativo) throw new Error('O animal selecionado não está disponível!')

        await Animal.destroy({
            where: {
                id: id
            }
        })

        res.json({
            message: "Dados Apagados!",
            data: []
        })
    }


}

