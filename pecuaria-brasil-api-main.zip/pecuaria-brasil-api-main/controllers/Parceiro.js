'use strict'

const { Parceiro, Cidade, Estado, Fazenda, ParceiroFazenda, Server, sequelize } = require('../models')


module.exports = {

    async create(req, res){
        const {
            parceiro_nome,
            email,
            tipo,
            cpf,
            inscricao_estadual,
            telefone,
            celular,
            endereco,
            cep,
            incra,
            cod_cidade
        } = req.body

        if (!(cod_cidade >= 1 && cod_cidade <= 999999)) throw new Error("Cidade não encontrada!")
        const cidade = await Cidade.findByPk(cod_cidade)
        if (!cidade) throw new Error("Cidade não encontrada!")


        let parceiro = await Parceiro.create({
            parceiro_nome,
            email,
            tipo,
            cpf,
            inscricao_estadual,
            telefone,
            celular,
            endereco,
            cep,
            incra ,
            cod_cidade
        })

        if (!parceiro) throw new Error("Parceiro não cadastrado!")

        // relecionando parceiro com fazendas
        let fazendas = await Fazenda.findAll()
        if(fazendas){

            let bulk = []
            for (let index = 0; index < fazendas.length; index++) {
                const element = fazendas[index];
                bulk.push({ cod_parceiro: parceiro.id, cod_fazenda: element.id })
            }
           
            await ParceiroFazenda.bulkCreate(bulk)

        }

        res.json({
            message: "Parceiro Cadastrado!",
            data: parceiro
        })
    },

    async findAll(req, res) {
        let parceiro = await Parceiro.findAll({
            include: {
                model: Cidade,
                as: 'cidade',
                include: {
                    model: Estado,
                    as: 'estado'
                }
            }
        })

        if (!parceiro) throw new Error("Nenhum parceiro encontrado!")

        res.json({
            data: parceiro
        })
    },

    async findByPk(req, res) {
        const id = req.params.id
        if (!(id >= 1 && id <= 999999)) throw new Error("Parceiro não encontrado!")

        let parceiro = await Parceiro.findByPk(id, {
            include: {
                model: Cidade,
                as: 'cidade'
            }
        })

        if (!parceiro) throw new Error("Parceiro não encontrado!")

        res.json({
            message: "Parceiro encontrado!",
            data: parceiro
        })
    },

    async update(req, res) {
        const id = req.params.id
        if (!(id >= 1 && id <= 999999)) throw new Error("Parceiro não encontrado!")

        let parceiro = await Parceiro.findByPk(id)
        if (!parceiro) throw new Error("Parceiro não encontrado!")

        const {
            parceiro_nome,
            email,
            tipo,
            cpf,
            inscricao_estadual,
            telefone,
            celular,
            endereco,
            cep,
            incra,
            cod_cidade
        } = req.body

        if (!(cod_cidade >= 1 && cod_cidade <= 999999)) throw new Error("Cidade não encontrada!")
        const cidade = await Cidade.findByPk(cod_cidade)
        if (!cidade) throw new Error("Cidade não encontrada!")

        await Parceiro.update({
            parceiro_nome,
            email,
            tipo,
            cpf,
            inscricao_estadual,
            telefone,
            celular,
            endereco,
            cep,
            incra ,
            cod_cidade
        }, {
            where: {
                id: id
            }
        })

        res.json({
            message: "Dados Atualizados!",
            data: []
        })
    },

    async delete(req, res) {
        const id = req.params.id
        if (!(id >= 1 && id <= 999999)) throw new Error("Parceiro não encontrado!")

        let parceiro = await Parceiro.findByPk(id)
        if (!parceiro) throw new Error("Parceiro não encontrado!")

        await Parceiro.destroy({
            where: {
                id: id
            }
        })

        res.json({
            message: "Dados Apagados!",
            data: []
        })
    }


}
