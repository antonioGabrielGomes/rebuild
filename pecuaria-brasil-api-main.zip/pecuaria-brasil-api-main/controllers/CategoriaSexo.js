'use strict'

const { Animal, CategoriaSexo, Server, sequelize } = require('../models')

module.exports = { 

    async create(req, res) {
        const {
            categoria_nome,
            descricao
        } = req.body

        let categoriaSexo = await CategoriaSexo.findAll({
            where: {
                categoria_nome: categoria_nome
            }
        })        
        if (categoriaSexo.length) throw new Error("Cadastre um nome diferente para o novo registro!")

        categoriaSexo = await CategoriaSexo.create({
            categoria_nome,
            descricao
        })

        if (!categoriaSexo) throw new Error("Categoria não cadastrada!")

        res.json({
            message: "Categoria Cadastrada!",
            data: categoriaSexo
        })
    },

    async delete(req, res) {
        const id = req.params.id
        if (!(id >= 1 && id <= 999999)) throw new Error("Categoria não encontrada!")       

        await CategoriaSexo.destroy({
            where: {
                id: id
            }
        })

        res.json({
            message: "Dados Apagados!",
            data: []
        })
    },   

    async findAll(req, res) {
        let categoriaSexo = await CategoriaSexo.findAll()
        /**
        {
            include: {
                model: Pasto,
                as: 'pasto'
            }
        }
         */

        if (!categoriaSexo) throw new Error("Nenhuma categoria encontrada!")

        res.json({
            message: "Categorias encontradas!",
            data: categoriaSexo
        })
    },

    async findByPk(req, res) {
        const id = req.params.id
        if (!(id >= 1 && id <= 999999)) throw new Error("Categoria não encontrada!")

        let categoriaSexo = await CategoriaSexo.findByPk(id)
        /*
         {
            include: {
                model: Pasto,
                as: 'pasto'
            }
        }
        */
        if (!categoriaSexo) throw new Error("Categoria não encontrada!")

        res.json({
            message: "Categoria encontrada!",
            data: categoriaSexo
        })
    },

    async update(req, res) {
        const id = req.params.id
        if (!(id >= 1 && id <= 999999)) throw new Error("Categoria não encontrada!")

        let categoriaSexo = await CategoriaSexo.findByPk(id)     
        if (!categoriaSexo) throw new Error("Categoria não encontrada!")

        categoriaSexo = await CategoriaSexo.findAll({
            where: {
                categoria_nome: categoria_nome
            }
        })        
        if (categoriaSexo.length) throw new Error("Cadastre um nome diferente para o novo registro!")

        const {
            categoria_nome,
            descricao
        } = req.body  

        await CategoriaSexo.update({
            categoria_nome,
            descricao
        }, {
            where: {
                id: id
            }
        })

        res.json({
            message: "Dados Atualizados!",
            data: []
        })
    }


}

