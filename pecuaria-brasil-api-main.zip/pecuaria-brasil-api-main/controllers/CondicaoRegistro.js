'use strict'

const { Animal, CondicaoRegistro, Server, sequelize } = require('../models')

module.exports = { 

    async findAll(req, res) {
        let condicaoRegistro = await CondicaoRegistro.findAll()
        /**
        {
            include: {
                model: Pasto,
                as: 'pasto'
            }
        }
         */

        if (!condicaoRegistro) throw new Error("Nenhuma condição encontrada!")

        res.json({
            message: "Condições encontradas!",
            data: condicaoRegistro
        })
    },

    async findByPk(req, res) {
        const id = req.params.id
        if (!(id >= 1 && id <= 999999)) throw new Error("Condição não encontrada!")

        let condicaoRegistro = await CondicaoRegistro.findByPk(id)
        /*
         {
            include: {
                model: Pasto,
                as: 'pasto'
            }
        }
        */
        if (!condicaoRegistro) throw new Error("Condição não encontrada!")

        res.json({
            message: "Condição encontrada!",
            data: condicaoRegistro
        })
    }

 
}

