'use strict'

const { TipoPasto, Server, sequelize } = require('../models')

module.exports = {

    async findAll(req, res) {
        const tipos = await TipoPasto.findAll()

        if (!tipos) throw new Error("Tipos não Encontrados!")

        res.json({
            data: tipos            
        })
    }
    
}