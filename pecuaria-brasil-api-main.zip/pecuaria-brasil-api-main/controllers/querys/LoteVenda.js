'use strict'

const { LoteVenda, Lote, Animal, Parceiro, Server, sequelize } = require('../../models')

module.exports = {

    async confirmarVenda(req, res) {
        const id = req.params.id
        if (!(id >= 1 && id <= 999999)) throw new Error("Venda não encontrada!")

        let loteVenda = await LoteVenda.findByPk(id)
        if (!loteVenda) throw new Error("Venda não encontrada!")

        /**
         CASO A VENDA JÁ ESTEJA FINALIZADA 
         A OPERAÇÃO NÃO É MAIS PERMITIDA 
         */
        if (loteVenda.venda_confirmada)
            throw new Error(`A venda já foi finalizada!`)
       
  
        await LoteVenda.update({
            venda_confirmada: true
        }, {
            where: {
                id: id
            }
        })

        /** 
         * ADICIONAR ANIMAIS PARA HISTÓRICO DE MOVIMENTAÇÃO
         */
        // MOVIMENTAÇÃO

        //


        res.json({
            message: "Venda de lote Confirmada!",
            data: []
        })
    }

   

}

