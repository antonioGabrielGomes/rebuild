'use strict'

const { Fazenda, Cidade, Server, sequelize } = require('../models')


module.exports = {

    async findAll(req, res) {
        let fazendas = await Fazenda.findAll()

        if (!fazendas) throw new Error("Nenhuma fazenda encontrada!")

        res.json({
            data: fazendas
        })
    },

    async create(req, res) {
        const {
            fazenda_nome,
            latitude,
            longitude,
            area_pastagem,
            inscricao_estadual,
            incra,
            sis_bov,
            endereco,
            cep,
            cod_cidade
        } = req.body

        //console.log(fazenda_nome)
        if (!(cod_cidade >= 1 && cod_cidade <= 999999)) throw new Error("Cidade não encontrada!")
        const cidade = await Cidade.findByPk(cod_cidade)
        if (!cidade) throw new Error("Cidade não encontrada!")


        let fazenda = await Fazenda.create({
            fazenda_nome,
            latitude,
            longitude,
            area_pastagem,
            inscricao_estadual,
            incra,
            sis_bov,
            endereco,
            cep,
            cod_cidade
        })

        if (!fazenda) throw new Error("Fazenda não cadastrada!")

        res.json({
            message: "Fazenda Cadastrada!",
            data: fazenda
        })
    },

    async findByPk(req, res) {
        const id = req.params.id
        if (!(id >= 1 && id <= 999999)) throw new Error("Fazenda não encontrada!")

        const fazenda = await Fazenda.findByPk(id, {
            include: {
                model: Cidade,
                as: 'cidade'
            }
        })

        if (!fazenda) throw new Error("Fazenda não encontrada!")
        
        res.json({
            message: "",
            data: fazenda
        })
    },

    async update(req, res) {

        const id = req.params.id
        if (!(id >= 1 && id <= 999999)) throw new Error("Fazenda não encontrada!")

        const fazenda = await Fazenda.findByPk(id) 
        if (!fazenda) throw new Error("Fazenda não encontrada!")

        const {
            fazenda_nome,
            latitude,
            longitude,
            area_pastagem,
            inscricao_estadual,
            incra,
            sis_bov,
            endereco,
            cep,
            cod_cidade
        } = req.body


        await Fazenda.update({
            fazenda_nome,
            latitude,
            longitude,
            area_pastagem,
            inscricao_estadual,
            incra,
            sis_bov,
            endereco,
            cep,
            cod_cidade
        }, {
            where: {
                id: id
            }
        })


        res.json({
            message: "Dados Atualizados!",
            data: []
        })
    },

    /*
    async delete(req, res){
        const id = req.params.id
        if (!(id >= 1 && id <= 999999)) throw new Error('Código inválido!')

        const fazenda = await Fazenda.findByPk(id) 
        if (!fazenda) throw new Error("Fazenda não encontrada!")

        await Fazenda.delete({
            where: {
                id: id
            }
        })

        res.json({
            message: "Fazenda Removida e todos os seus dados relacionados!"
        })
    }
    */

}