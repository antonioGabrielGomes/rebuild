'use strict'

const { Fazenda, Retiro, Server, sequelize } = require('../models')

module.exports = {

    async create(req, res) {

        const { retiro_nome, cod_fazenda } = req.body
        if (!(cod_fazenda >= 1 && cod_fazenda <= 999999)) throw new Error("Fazenda não encontrada!")

        const fazenda = await Fazenda.findByPk(cod_fazenda)
        if (!fazenda) throw new Error("Fazenda não encontrada!")

        let retiro = await Retiro.create({
            retiro_nome,
            cod_fazenda
        })

        if (!retiro) throw new Error("Retiro não cadastrada!")

        res.json({
            message: "Retiro Cadastrado!",
            data: retiro
        })
    },

    async findAll(req, res) {
        let retiros = await Retiro.findAll({
            include: {
                model: Fazenda,
                as: 'fazenda' 
            }
        })

        if (!retiros) throw new Error("Nenhum retiro encontrado!")

        res.json({
            data: retiros 
        })
    },

    async findByPk(req, res) {
        const id = req.params.id
        if (!(id >= 1 && id <= 999999)) throw new Error("Retiro não encontrado!")

        const retiro = await Retiro.findByPk(id, {
            include: {
                model: Fazenda,
                as: 'fazenda'
            }
        })

        if (!retiro) throw new Error("Retiro não encontrado!")

        res.json({
            data: retiro
        })
    },

    async update(req, res) {
        const id = req.params.id
        if (!(id >= 1 && id <= 999999)) throw new Error("Retiro não encontrado!")

        const { retiro_nome, cod_fazenda } = req.body
        if (!(cod_fazenda >= 1 && cod_fazenda <= 999999)) throw new Error("Fazenda não encontrada!")

        const fazenda = await Fazenda.findByPk(cod_fazenda)
        if (!fazenda) throw new Error("Fazenda não encontrada!")

        await Retiro.update({
            retiro_nome, cod_fazenda
        }, {
            where: {
                id: id
            }
        })

   
        res.json({
            message: "Dados Atualizados!",
            data: []
        })
    },

    async delete(req, res){
        const id = req.params.id
        if (!(id >= 1 && id <= 999999)) throw new Error("Retiro não encontrado!")

        const retiro = await Retiro.findByPk(id)
        if (!retiro) throw new Error("Retiro não encontrado!")

        await Retiro.destroy({
            where: {
                id: id
            }
        })    

        res.json({
            message: "Dados Apagados!",
            data: []
        })   
    }

}