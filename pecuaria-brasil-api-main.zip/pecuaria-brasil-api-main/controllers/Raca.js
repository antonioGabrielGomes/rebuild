'use strict'

const { Animal, Raca, Server, sequelize } = require('../models')

module.exports = { 

    async create(req, res) {
        const {
            raca_nome,
            descricao
        } = req.body

        let raca = await Raca.findAll({
            where: {
                raca_nome: raca_nome
            }
        })        
        if (raca.length) throw new Error("Uma raça com o mesmo nome já foi cadastrada!")

        raca = await Raca.create({
            raca_nome,
            descricao
        })

        if (!raca) throw new Error("Raça não cadastrada!")

        res.json({
            message: "Raça Cadastrada!",
            data: raca
        })
    },

    async findAll(req, res) {
        let raca = await Raca.findAll()
        /**
        {
            include: {
                model: Pasto,
                as: 'pasto'
            }
        }
         */

        if (!raca) throw new Error("Nenhuma raça encontrada!")

        res.json({
            message: "Raças encontradas!",
            data: raca
        })
    },

    async findByPk(req, res) {
        const id = req.params.id
        if (!(id >= 1 && id <= 999999)) throw new Error("Raça não encontrada!")

        let raca = await Raca.findByPk(id)
        /*
         {
            include: {
                model: Pasto,
                as: 'pasto'
            }
        }
        */
        if (!raca) throw new Error("Raça não encontrada!")

        res.json({
            message: "Raça encontrada!",
            data: raca
        })
    },

    async update(req, res) {
        const id = req.params.id
        if (!(id >= 1 && id <= 999999)) throw new Error("Raça não encontrada!")

        const {
            raca_nome,
            descricao
        } = req.body

        let raca = await Raca.findByPk(id)
        /*
         {
            include: {
                model: Pasto,
                as: 'pasto'
            }
        }
        */
        if (!raca) throw new Error("Raça não encontrada!")
        
        raca = await Raca.findAll({
            where: {
                raca_nome: raca_nome
            }
        })        
        if (raca.length) throw new Error("Uma raça com o mesmo nome já foi cadastrada!")
        

        await Raca.update({
            raca_nome,
            descricao
        }, {
            where: {
                id: id
            }
        })

        res.json({
            message: "Dados Atualizados!",
            data: []
        })
    },



    async delete(req, res) {
        const id = req.params.id
        if (!(id >= 1 && id <= 999999)) throw new Error("Raça não encontrada!")       

        await Raca.destroy({
            where: {
                id: id
            }
        })

        res.json({
            message: "Dados Apagados!",
            data: []
        })
    }


}

