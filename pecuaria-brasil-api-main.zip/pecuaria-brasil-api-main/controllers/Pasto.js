'use strict'

const { Retiro, Pasto, TipoPasto, Server, sequelize } = require('../models')

module.exports = {

    async create(req, res) {

        const {
            pasto_nome,
            geojson,
            tamanho,
            lotacao_maxima,
            observacao,
            disponivel,
            cod_retiro,
            cod_tipo_pasto
        } = req.body


        if (!(cod_retiro >= 1 && cod_retiro <= 999999)) throw new Error("Retiro não encontrado!")
        const retiro = await Retiro.findByPk(cod_retiro)
        if (!retiro) throw new Error("Retiro não encontrado!")

        if (!(cod_tipo_pasto >= 1 && cod_tipo_pasto <= 999999)) throw new Error("Tipo de pasto não encontrado!")
        const tipoPasto = await TipoPasto.findByPk(cod_tipo_pasto)
        if (!tipoPasto) throw new Error("Tipo de pasto não encontrado!")


        let pasto = await Pasto.create({
            pasto_nome,
            geojson,
            tamanho,
            lotacao_maxima,
            observacao,
            disponivel,
            cod_retiro,
            cod_tipo_pasto
        })

        if (!pasto) throw new Error("Pasto não cadastrado!")

        res.json({
            message: "Pasto Cadastrado!",
            data: pasto
        })
    },

    async findAll(req, res) {
        let pastos = await Pasto.findAll({
            include: [{
                model: TipoPasto,
                as: 'tipo_pasto'
            },{
                model: Retiro,
                as: 'retiro'
            }]
        })

        if (!pastos) throw new Error("Nenhum pasto encontrado!")

        res.json({
            message: "Pastos encontrados!",
            data: pastos
        })
    },

    async findByPk(req, res) {
        const id = req.params.id
        if (!(id >= 1 && id <= 999999)) throw new Error("Pasto não encontrado!")

        let pasto = await Pasto.findByPk(id, {
            include: [{
                model: TipoPasto,
                as: 'tipo_pasto'
            },{
                model: Retiro,
                as: 'retiro'
            }]
        })

        if (!pasto) throw new Error("Pasto não encontradoo!")

        res.json({
            message: "Pasto encontrado!",
            data: pasto
        })
    },

    async update(req, res) {
        const id = req.params.id
        if (!(id >= 1 && id <= 999999)) throw new Error("Pasto não encontrado!")

        let pasto = await Pasto.findByPk(id)
        if (!pasto) throw new Error("Pasto não encontradoo!")

        const {
            pasto_nome,
            geojson,
            tamanho,
            lotacao_maxima,
            observacao,
            disponivel,
            cod_tipo_pasto
        } = req.body

        if (!(cod_tipo_pasto >= 1 && cod_tipo_pasto <= 999999)) throw new Error("Tipo de pasto não encontrado!")
        const tipoPasto = await TipoPasto.findByPk(cod_tipo_pasto)
        if (!tipoPasto) throw new Error("Tipo de pasto não encontrado!")

        await Pasto.update({
            pasto_nome,
            geojson,
            tamanho,
            lotacao_maxima,
            observacao,
            disponivel,
            cod_tipo_pasto
        }, {
            where: {
                id: id
            }
        })


        res.json({
            message: "Dados Atualizados!",
            data: []
        })
    },

    async delete(req, res) {
        const id = req.params.id
        if (!(id >= 1 && id <= 999999)) throw new Error("Pasto não encontrado!")

        let pasto = await Pasto.findByPk(id)
        if (!pasto) throw new Error("Pasto não encontradoo!")

        await Pasto.destroy({
            where: {
                id: id
            }
        })

        res.json({
            message: "Dados Apagados!",
            data: []
        })
    }

}

