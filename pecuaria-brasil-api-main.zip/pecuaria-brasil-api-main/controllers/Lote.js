'use strict'

const { Lote, Pasto, Animal, Server, sequelize } = require('../models')

module.exports = {

    async create(req, res) {

        const {
            lote_nome,
            valor_medio_venda,
            peso_medio_venda,
            data_estimada_venda,
            descricao,
            cod_pasto
        } = req.body 

        if (!(cod_pasto >= 1 && cod_pasto <= 999999)) throw new Error("Pasto não encontrado!")
        const pasto = await Pasto.findByPk(cod_pasto)
        if (!pasto) throw new Error("Pasto não encontrado!")

        let lote = await Lote.create({
            lote_nome,
            valor_medio_venda,
            peso_medio_venda,
            data_estimada_venda,
            descricao,
            cod_pasto
        })

        if (!lote) throw new Error("Lote não cadastrado!")

        res.json({
            message: "Lote Cadastrado!",
            data: lote
        })
    },

    async findAll(req, res) {
        let lotes = await Lote.findAll({
            include: [
                {
                    model: Pasto,
                    as: 'pasto'
                },
                {
                    model: Animal,
                    as: 'animais'
                }
            ]
        })

        if (!lotes) throw new Error("Nenhum lote encontrado!")

        res.json({
            message: "Lotes encontrados!",
            data: lotes
        })
    },

    async findByPk(req, res) {
        const id = req.params.id
        if (!(id >= 1 && id <= 999999)) throw new Error("Lote não encontrado!")

        let lote = await Lote.findByPk(id, {
            include: [{
                model: Pasto,
                as: 'pasto'
            },{
                model: Animal,
                as: 'animais' 
            }]
        })

        if (!lote) throw new Error("Lote não encontradoo!")

        res.json({
            message: "Lote encontrado!",
            data: lote
        })
    },

    async update(req, res) {
        const id = req.params.id
        if (!(id >= 1 && id <= 999999)) throw new Error("Lote não encontrado!")

        const {
            lote_nome,
            valor_medio_venda,
            peso_medio_venda,
            data_estimada_venda,
            descricao,
            cod_pasto
        } = req.body

        let lote = await Lote.findByPk(id)
        if (!lote) throw new Error("Lote não encontradoo!")

        if (!(cod_pasto >= 1 && cod_pasto <= 999999)) throw new Error("Pasto não encontrado!")
        let pasto = await Pasto.findByPk(cod_pasto)
        if (!pasto) throw new Error("Pasto não encontrado!")
     

        await Lote.update({
            lote_nome,
            valor_medio_venda,
            peso_medio_venda,
            data_estimada_venda,
            descricao,
            cod_pasto
        }, {
            where: {
                id: id
            }
        })


        res.json({
            message: "Dados Atualizados!",
            data: []
        })
    },

    async delete(req, res) {
        const id = req.params.id
        if (!(id >= 1 && id <= 999999)) throw new Error("Lote não encontrado!")

        let lote = await Lote.findByPk(id)
        if (!lote) throw new Error("Lote não encontradoo!")

        await Lote.destroy({
            where: {
                id: id
            }
        })

        res.json({
            message: "Dados Apagados!",
            data: []
        })
    }

}

