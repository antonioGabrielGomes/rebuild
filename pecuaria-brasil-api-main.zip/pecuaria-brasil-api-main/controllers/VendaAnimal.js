'use strict'

const { VendaAnimal, LoteVenda, Animal, Server, sequelize } = require('../models')

module.exports = {

    async create(req, res) {
        const {
            cod_lote_venda,
            cod_animal
        } = req.body


        if (!(cod_lote_venda >= 1 && cod_lote_venda <= 999999)) throw new Error("Venda não encontrada!")
        let venda = await LoteVenda.findByPk(cod_lote_venda, {
            include: {
                model: VendaAnimal,
                as: 'lote_vendas'
            }
        })
        if (!venda) throw new Error("Venda não encontrada!")
        if (venda.venda_confirmada) throw new Error("Esta venda já foi finalizada!")
        
        //
        if (!(cod_animal >= 1 && cod_animal <= 999999)) throw new Error("Animal não encontrado!")
        let animal = await Animal.findByPk(cod_animal)
        if (!animal) throw new Error("Animal não encontrado!")

        /** VERIFICAR SE ANIMAL AINDA ESTÁ ATIVO NO REBANHO */
        if(animal.ativo) throw new Error('O animal selecionado não está disponível!')
                
        /**
        VERIFICAR SE ANIMAL AINDA ESTÁ DISPONÍVEL, BUSCANDO NA TABELA DE LOTE_VENDA_ANIMAL
        CASO NÃO ESTEJA, NÃO PERMITIR OPERAÇÃO
         */
        let buscaAnimalVendas = await VendaAnimal.findAll({
            where: {
                cod_animal: cod_animal
            }
        })
        if(buscaAnimalVendas.length)  throw new Error('O animal selecionado já está em uma venda!')
       
        /**
        QUEREMOS SABER QUAL A QUANTIDADE DE ANIMAIS PEDIDOS NA VENDA
        CASO A QUANTIDADE DE ANIMAIS REGISTRADOS NA TABELA LOTE_VENDA_ANIMAIS
        SEJA IGUAL A QUANTIDADE SOLICITADA PARA VENDA LOTE_VENDA, 
        NÃO PERMITIR OPERAÇÃO
        */     
        
        if (venda.lote_vendas.length == venda.quantidade)
            throw new Error(`A quantidade (${venda.quantidade}) de animais já foi atingida nesta venda!`)

        //console.debug(venda.lote_vendas)
        //console.debug(venda.lote_vendas.length)
           

        // 
        let vendaAnimal = await VendaAnimal.create({
            cod_lote_venda,
            cod_animal
        })

        if (!vendaAnimal) throw new Error("Animal não cadastrado na venda!")

        res.json({
            message: "Animal cadastrado na venda!",
            data: vendaAnimal
        })
    },

    async delete(req, res) {
        const {
            cod_lote_venda,
            cod_animal
        } = req.body

        if (!(cod_lote_venda >= 1 && cod_lote_venda <= 999999)) throw new Error("Venda não encontrada!")
        let venda = await LoteVenda.findByPk(cod_lote_venda)
        if (!venda) throw new Error("Venda não encontrada!")
        if (venda.venda_confirmada) throw new Error("Esta venda já foi finalizada!")
 
        if (!(cod_animal >= 1 && cod_animal <= 999999)) throw new Error("Animal não encontrado!")
        let animal = await Animal.findByPk(cod_animal)
        if (!animal) throw new Error("Animal não encontrado!")
        
        let vendaAnimal = await VendaAnimal.findAll({
            where: {
                cod_lote_venda: cod_lote_venda,
                cod_animal: cod_animal
            }
        })               
        if(!vendaAnimal.length) throw new Error("Relacionamento não encontrado!")

        //
        await VendaAnimal.destroy({
            where: {
                cod_lote_venda: cod_lote_venda,
                cod_animal: cod_animal
            }
        })

        res.json({
            message: "Dados Apagados!",
            data: []
        })
    }


}