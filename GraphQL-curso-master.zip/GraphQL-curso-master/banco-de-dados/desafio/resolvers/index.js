const Query = require('./Query')
const Mutation = require('./Mutation')
const Usuario = require('./Type/Usuario')

module.exports = {
    Query,
    Mutation,
    Usuario
}