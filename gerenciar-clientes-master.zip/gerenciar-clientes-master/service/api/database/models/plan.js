'use strict';

const { Model, DataTypes } = require('sequelize')

class Plan extends Model {

  static init(sequelize){
    super.init({
      name: DataTypes.STRING,
      value: DataTypes.DECIMAL,
      active: DataTypes.BOOLEAN,
      created_at: DataTypes.DATE,
      updated_at: DataTypes.DATE
    }, {
      sequelize,
      modelName: 'Plan',
      tableName: 'Plans'
    })
  }

  static associate(models){

    this.hasMany(models.Client, { foreignKey: 'id', as: 'users' })

  }

}

module.exports = Plan

/** 
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class Plan extends Model {
   
    static associate(models) {
      // define association here
    }
  };
  Plan.init({
    name: DataTypes.STRING
  }, {
    sequelize,
    modelName: 'Plan',
  });
  return Plan;
}; 

*/