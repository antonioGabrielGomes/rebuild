'use strict';

const { Model, DataTypes } = require('sequelize')

class Connection extends Model {

  static init(sequelize){
    super.init({
      address: DataTypes.STRING,
      user: DataTypes.STRING,
      password: DataTypes.STRING,
      created_at: DataTypes.DATE,
      updated_at: DataTypes.DATE
    }, {
      sequelize,
      modelName: 'Connection',
      tableName: 'Connections'
    })
  }

  static associate(models){
    // 
  }

}

module.exports = Connection

/*
const { Model } = require('sequelize');

module.exports = (sequelize, DataTypes) => {

  class Connection extends Model {
   
    static associate(models) {
      // define association here
    }
  };

  Connection.init({
    address: DataTypes.STRING,
    user: DataTypes.STRING,
    password: DataTypes.STRING
  }, {
    sequelize,
    modelName: 'Connection',
  });

  return Connection;
};
*/