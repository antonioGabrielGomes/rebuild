'use strict';

const { Model, DataTypes } = require('sequelize')

class Transaction extends Model {

  static init(sequelize){
    super.init({
      charge_id: DataTypes.INTEGER,
      status: DataTypes.STRING,
      pdf: DataTypes.STRING,
      expire_at: DataTypes.DATE,
      created_at: DataTypes.DATE,
      updated_at: DataTypes.DATE
    },{
      sequelize,
      modelName: 'Transaction',
      tableName: 'Transactions'
    })
  }

  static associate(models){

    this.belongsTo(models.Client, { foreignKey: 'client_id', as: 'client'})

  }

}

module.exports = Transaction



/*
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class Transaction extends Model {

    static associate(models) {
      // define association here
    }
  };
  Transaction.init({
    client_id: DataTypes.INTEGER
  }, {
    sequelize,
    modelName: 'Transaction',
  });
  return Transaction;
};
*/