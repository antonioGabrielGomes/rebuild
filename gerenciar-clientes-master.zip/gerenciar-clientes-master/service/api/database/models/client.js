'use strict';

const { throttle } = require('rxjs/operator/throttle');
const { Model, DataTypes } = require('sequelize')

class Client extends Model {
  static init(sequelize){
    super.init({
      first_name: DataTypes.STRING,
      second_name: DataTypes.STRING,
      username: DataTypes.STRING,
      address: DataTypes.TEXT,
      location: DataTypes.STRING,
      email: DataTypes.STRING,
      cpf: DataTypes.STRING,
      contato: DataTypes.STRING,
      active: DataTypes.BOOLEAN,
      blocked: DataTypes.BOOLEAN,
      created_at: DataTypes.DATE,
      updated_at: DataTypes.DATE
    }, {
      sequelize,
      modelName: 'Client', 
      tableName: 'Clients'
    })
  }

  static associate(models){    

    this.belongsTo(models.Plan, { foreignKey: 'plan_id', as: 'plan' })
    this.hasMany(models.Transaction, { foreignKey: 'id', as: 'transactions' })

  }
}

module.exports = Client


/*
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class Client extends Model {

    static associate(models) {
      // define association here
    }
  };
  Client.init({
    first_name: DataTypes.STRING
  }, {
    sequelize,
    modelName: 'Client',
  });
  return Client;
}; 

*/