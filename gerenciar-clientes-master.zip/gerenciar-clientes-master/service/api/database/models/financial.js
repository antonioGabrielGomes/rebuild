'use strict';

const { Model, DataTypes } = require('sequelize')

class Financial extends Model {
  static init(sequelize){
    super.init({
      generate_at: DataTypes.STRING,
      created_at: DataTypes.DATE,
      updated_at: DataTypes.DATE
    }, {
      sequelize,
      modelName: 'Financial',
      tableName: 'Financials'
    })
  }

  static associate(models){
    //
  }
}

module.exports = Financial

/**
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class Financial extends Model {
  
    static associate(models) {
      // define association here
    }
  };
  Financial.init({
    month: DataTypes.DATE
  }, {
    sequelize,
    modelName: 'Financial',
  });
  return Financial;
};
*/