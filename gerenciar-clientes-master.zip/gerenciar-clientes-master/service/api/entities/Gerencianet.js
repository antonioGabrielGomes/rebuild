const gerencianet = require('gn-api-sdk-node')
const options = require('../config/gerencianet')

class Gerencianet {
    constructor() {
        this.body = null
        this.instance = new gerencianet(options)
        this.data = {}
    }

    createBody() {
        this.body = {
            items: [{
                name: 'Product 1',
                value: 1000,
                amount: 1
            }],
            metadata: {
                custom_id: '00',
                //notification_url: ''
            }
        }
    }

    creatBodyPayment() {
        this.body = {
            payment: {
                banking_billet: {
                    expire_at: '2020-12-10',
                    customer: {
                        name: 'Gorbadoc Oldbuck',
                        email: 'oldbuck@gerencianet.com.br',
                        cpf: '04267484171',
                        phone_number: '5144916523'
                    },
                    configurations: {
                        fine: 200,
                        interest: 22
                    }
                }
            }
        }
    }

    async getInfoTransaction(charge_id = null) {

        const params = {
            id: charge_id
        }

        await this.instance
            .detailCharge(params)
            .then(data => {
                this.data = data.data
                console.log(data.data)
            })
            .catch(err => {
                ///throw new Error(err.message)
            })
            .done();


    }



}


module.exports = Gerencianet
