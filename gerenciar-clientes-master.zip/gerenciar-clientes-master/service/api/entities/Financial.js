'use strict'

const ModelFinancial = require('../database/models/financial')
const { Op } = require('sequelize')

class Financial {
    constructor() {
        this.date = new Date()
        this.data = null

    }

    async expirationDate() {
        let expiration = `${this.date.getFullYear()}-${this.date.getMonth() + 1}-10`
        return expiration
    }

    async createLogTransaction(month) {        
        await ModelFinancial.create({
            generate_at: month
        })
            .then((data) => {

                console.log(data)
                
            })
            .catch(err => {
                throw new Error(err)
            })

    }

    async checkDate(month) {

        await ModelFinancial.findAll({
            where: {
                generate_at: month
            }
        })
            .then(data => {
                this.data = data

                console.log(data)

                if (data.length > 0)
                    throw new Error('Transaction has already been requested in the current month.')
            }).catch(err => {
                throw new Error(err)
            })

    }

}

module.exports = Financial