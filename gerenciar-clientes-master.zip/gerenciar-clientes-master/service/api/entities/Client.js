'use strict'

const ModelClient = require('../database/models/client')

class Client {

    constructor(){
        this.clients = []
    }

    async findAllClientWhere(fields){
        this.clients = await ModelClient.findAll({
            where: fields,
            include: {
                association: 'plan',
                attributes: ['name', 'value']
            }
        })

        if(!this.clients.length)
            throw new Error('Clients not found')
    }

    async findAllClient(){
        this.clients = await ModelClient.findAll({
            include: {
                association: 'plan',
                attributes: ['name', 'value']
            }
        })

        if(!this.clients.length)
            throw new Error('clients not found')
    }

    // criar outros metodos para client
}

module.exports = Client