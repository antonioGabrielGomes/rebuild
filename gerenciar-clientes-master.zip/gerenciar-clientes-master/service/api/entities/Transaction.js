'use strict'

const Gerencianet = require('./Gerencianet') // same folder
const Financial = require('./Financial')
const ModelTransaction = require('../database/models/transaction')
const ModelClient = require('../database/models/client')

class Transaction {

    constructor(client = {}) {
        this.date = new Date()
        this.client = client
        this.gerencianet = new Gerencianet()
        this.transactions = []
        this.financial = new Financial()
    }

    async createTransaction() {
        if (!this.client.clients.length)
            throw new Error('Client data not found')

        // **                                
        this.gerencianet.createBody()

        this.client.clients.forEach(async client => {
            let created_at = new Date(client.created_at)

            // Check date register client
            if (this.compareDate(created_at)) {
                let plan = client.plan.dataValues
                this.gerencianet.body.items[0].name = `Plano de Internet ${plan.name}, valor atual R$ ${plan.value},00 reais/mês`
                this.gerencianet.body.items[0].value = parseInt(plan.value) * 100
                this.gerencianet.body.metadata.custom_id = `${client.id}`

                // create charge - return charge_id
                await this.gerencianet.instance
                    .createCharge({}, this.gerencianet.body)
                    .then(async data => {
                        if (data.code == 200) {

                            let transaction = {
                                charge_id: data.data.charge_id,
                                status: data.data.status,
                                client_id: parseInt(data.data.custom_id),
                                created_at: data.data.created_at
                            }

                            // save new transaction in database
                            await this.saveNewTransaction(transaction)
                        }
                    })
                    .catch(console.error)
                    .done()

            }

        })

    }

    async getByStatus(status = 'new', ass = true) {
        let parameters = null

        if (ass) {
            parameters = {
                where: {
                    status: status
                },
                include: {
                    association: 'client',
                    attributes: ['first_name', 'second_name', 'address', 'email', 'cpf', 'contato', 'active', 'plan_id']
                }
            }
        } else {
            parameters = {
                where: {
                    status: status
                }
            }
        }

        await ModelTransaction.findAll(parameters).then(data => {

            this.transactions = data

        }).catch(err => {
            throw new Error(err.message)
        })
    }

    async associateBillet() {
        if (!this.transactions.length)
            throw new Error('Transactions data not found')

        // **
        this.gerencianet.creatBodyPayment()

        this.transactions.forEach(async transaction => {
            const dataValueTransaction = transaction.dataValues
            const dataValueClient = dataValueTransaction.client.dataValues
            dataValueClient.cpf.replace('.', '')
            dataValueClient.cpf.replace('-', '')

            const params = {
                id: dataValueTransaction.charge_id
            }

            // 
            this.gerencianet.body.payment.banking_billet.expire_at = this.genExpireAt(15)
            this.gerencianet.body.payment.banking_billet.customer.name = `${dataValueClient.first_name} ${dataValueClient.second_name}`
            this.gerencianet.body.payment.banking_billet.customer.cpf = dataValueClient.cpf
            this.gerencianet.body.payment.banking_billet.customer.email = dataValueClient.email
            // alterar contato para contact
            this.gerencianet.body.payment.banking_billet.customer.phone_number = dataValueClient.contato

            await this.gerencianet.instance
                .payCharge(params, this.gerencianet.body)
                .then(async data => {
                    if (data.code == 200) {

                        let update = {
                            status: data.data.status,
                            expire_at: data.data.expire_at,
                            pdf: data.data.pdf.charge
                        }

                        // update transaction in database
                        await this.updateTransaction(update, transaction.id)
                    }
                })
                .catch(console.error)
                .done();

        })
    }

    async findTransactionsByClient(id = 0) {
        await ModelTransaction.findAll({
            where: {
                client_id: id
            },
            include: {
                association: 'client',
                attributes: ['first_name', 'second_name', 'address', 'email', 'cpf', 'contato', 'active', 'plan_id']
            }
        }).then(data => {

            this.transactions = data

        }).catch(err => {
            throw new Error(err.message)
        })
    }

    async findTransaction(id = 0) {
        await ModelTransaction.findAll({
            where: {
                id: id
            }
        })
            .then(data => {

                this.transactions = data[0].dataValues

            }).catch(err => {
                
                throw new Error(err.message)

            })
    }

    async updateTransactionInfo(id = null, charge_id = null) {

        const params = {
            id: charge_id
        }

        await this.gerencianet.instance
            .detailCharge(params)
            .then(async data => {

                if (data.code == 200) {

                    let update = {
                        status: data.data.status
                    }

                    if (update.status != 'waiting')
                        await this.updateTransaction(update, id)
                }


            })
            .catch(console.log)
            .done();
    }



    async payTransaction(chargeId) {

    }

    genExpireAt(day = 10) {
        if (day > 20) day = 20

        let year = this.date.getFullYear()
        let month = this.date.getMonth() + 2

        if (month > 12) {
            year = this.date.getFullYear() + 1
            month = '01'
        }

        //console.log(`${year}-${month}-${day}`)
        //^[12][0-9]{3}-(?:0[1-9]|1[0-2])-(?:0[1-9]|[12][0-9]|3[01])$. 

        return `${year}-${month}-${day}`
    }

    compareDate(created_at) {
        if ((created_at.getMonth() === this.date.getMonth()) &&
            (created_at.getFullYear() === this.date.getFullYear())) {
            return false
        }
        return true
    }

    async saveNewTransaction(data) {
        await ModelTransaction.create(data)
    }

    async updateTransaction(data, id) {
        await ModelTransaction.update(data, {
            where: {
                id: id
            }
        })
    }

}

module.exports = Transaction