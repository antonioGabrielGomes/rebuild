'use strict'

const MikroNode = require('mikronode')
const path = require('path')
const fs = require('fs')

class Mikrotik {

    constructor(address, user, password) {
        this.dataConn = null

        this.secrets = null
        this.profiles = null

        this.device = null
        this.address = address
        this.user = user
        this.password = password
    }

    setDevice() {
        this.device = new MikroNode(this.address)
    }

    async test() {

        if (!this.address || !this.user || !this.password)
            throw new Error('Field empty')

        //this.device = new MikroNode(this.address)
        this.setDevice()

        let result = null

        await this.device.connect()
            .then(([login]) => login(this.user, this.password))
            .then(async (conn) => {

                conn.closeOnDone(true)
                const chan = conn.openChannel();

                await chan.write('/interface/print')
                    .then(data => {
                        result = data
                    })
                    .catch(error => {
                        throw new Error(error.message)
                    })

            })
            .catch(error => {
                throw new Error(error.message)
            });

        return result
    }

    /*
    async findProfile() {

        this.setDevice()

        await this.device.connect()
            .then(([login]) => login(this.user, this.password))
            .then(async (conn) => {
                const chan = conn.openChannel()

                await chan.write('/ppp/profile/print')
                    .then(data => {
                        this.profiles = data.data

                        chan.close()
                        conn.close()
                    })
                    .catch(error => {
                        throw new Error(error.message)
                    })
            })
            .catch(error => {
                throw new Error(error.message)
            })
    }
    */

    async enable(name) {

        if (!name)
            throw new Error('Secret name empty')

        this.setDevice()

        await this.device.connect().then(([login]) => login(this.user, this.password))
            .then(function (conn) {
                conn.closeOnDone(true)
                const listenChannel = conn.openChannel('listen')

                const actionChannel = conn.openChannel('action', false)

                actionChannel.sync(false)
                actionChannel.closeOnDone(false)
                // ppp secret set disabled=no adriel.alves 
                actionChannel.write('/ppp/secret/set', {
                    'disabled': 'no',
                    '.id': name
                }).then(results => {
                    const { promise, resolve, reject } = MikroNode.getUnwrappedPromise();
                    listenChannel.data
                        .take(1)
                        // This is just to prove that it grabbed the first one.
                        .do(d => console.log("Data:", MikroNode.resultsToObj(d.data)))
                        .subscribe(d => actionChannel.write('/ppp/secret/set', {
                            'disabled': 'no',
                            '.id': name
                        }).then(resolve, reject));
                    return promise
                }).then(nodata => {
                    listenChannel.close(true)
                    actionChannel.close()
                })


            })

    }

    async disable(name) {

        if (!name)
            throw new Error('Secret name empty')

        this.setDevice()

        await this.device.connect().then(([login]) => login(this.user, this.password))
            .then(function (conn) {
                conn.closeOnDone(true)
                const listenChannel = conn.openChannel('listen')

                const actionChannel = conn.openChannel('action', false)

                actionChannel.sync(false)
                actionChannel.closeOnDone(false)
                // ppp secret set disabled=no adriel.alves 
                actionChannel.write('/ppp/secret/set', {
                    'disabled': 'yes',
                    '.id': name
                }).then(results => {
                    const { promise, resolve, reject } = MikroNode.getUnwrappedPromise();
                    listenChannel.data
                        .take(1)
                        // This is just to prove that it grabbed the first one.
                        .do(d => console.log("Data:", MikroNode.resultsToObj(d.data)))
                        .subscribe(d => actionChannel.write('/ppp/secret/set', {
                            'disabled': 'yes',
                            '.id': name
                        }).then(resolve, reject));
                    return promise
                }).then(nodata => {
                    listenChannel.close(true)
                    actionChannel.close()
                })


            })
    }

    async findSecret(username, test = true) {

        if (!username)
            throw new Error('Secret username empty')

        /** set new instance Mikrotik class */
        this.setDevice()

        await this.device.connect().then(([login]) => login(this.user, this.password))
            .then(async (conn) => {

                conn.closeOnDone(true)
                const listenChannel = conn.openChannel('listen')

                const actionChannel = conn.openChannel('action', false)

                actionChannel.sync(false)
                actionChannel.closeOnDone(false)
                // ppp secret set disabled=no adriel.alves 
                await actionChannel.write('/ppp/secret/get', {
                    '.id': username
                })
                    .then(result => {
                        test = false
                    })
                    .then(nodata => {
                        listenChannel.close(true)
                        actionChannel.close()
                    })
                    .catch(error => {

                        //if (test) {
                        //    throw new Error(error.data[0].value) // object>data>[0]>value
                        // } else {
                        test = true
                        // }

                    })

            })

        return test
    }

    async setComment(secretName, text = null) {

        /** read data conn */
        await this.readMkConn()

        /** test connections */
        //await this.test()

        this.setDevice()

        await this.device.connect().then(([login]) => login(this.user, this.password))
            .then(async (conn) => {
                conn.closeOnDone(true)
                const listenChannel = conn.openChannel('listen')

                const actionChannel = conn.openChannel('action', false)

                actionChannel.sync(false)
                actionChannel.closeOnDone(false)

                await actionChannel.write('/ppp/secret/set', {
                    'comment': text,
                    '.id': secretName
                }).then(results => {
                    const { promise, resolve, reject } = MikroNode.getUnwrappedPromise();
                    listenChannel.data
                        .take(1)
                        // This is just to prove that it grabbed the first one.
                        .do(d => console.log("Data:", MikroNode.resultsToObj(d.data)))
                        .subscribe(d => actionChannel.write('/ppp/secret/set', {
                            'comment': text,
                            '.id': secretName
                        }).then(resolve, reject));
                    return promise
                }).then(nodata => {
                    listenChannel.close(true)
                    actionChannel.close()
                })

            })
            .catch(error => {
                throw new Error(error.message)
            })
    }

    async addSecret(username, password, service, profile, comment) {

        if (!username)
            throw new Error('Secret name empty')

        this.setDevice()

        await this.device.connect().then(([login]) => login(this.user, this.password))
            .then(function (conn) {
                conn.closeOnDone(true)
                const listenChannel = conn.openChannel('listen')

                const actionChannel = conn.openChannel('action', false)

                actionChannel.sync(false)
                actionChannel.closeOnDone(false)

                actionChannel.write('/ppp/secret/add', {
                    'name': username,
                    'password': password,
                    'service': service,
                    'profile': profile,
                    'comment': comment
                }).then(results => {
                    const { promise, resolve, reject } = MikroNode.getUnwrappedPromise();
                    listenChannel.data
                        .take(1)
                        // This is just to prove that it grabbed the first one.
                        .do(d => console.log("Data:", MikroNode.resultsToObj(d.data)))
                        .subscribe(d => actionChannel.write('/ppp/secret/set', {
                            'disabled': 'yes',
                            '.id': username
                        }).then(resolve, reject));
                    return promise
                }).then(nodata => {
                    listenChannel.close(true)
                    actionChannel.close()
                })


            })


    }
}

module.exports = Mikrotik