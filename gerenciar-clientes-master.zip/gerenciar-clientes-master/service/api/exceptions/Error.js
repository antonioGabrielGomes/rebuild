module.exports = {
    console(err, res, msg) {
        if (process.env.NODE_ENV === 'development') {
            console.log(err)
        }

        return res.status(400).json({
            status: false,
            message: msg
        })
    },

    breackFlow(res, msg){
        if (process.env.NODE_ENV === 'development') {
            console.log(msg)
        }

        return res.status(400).json({
            status: false,
            message: msg
        })
    }
}