'use strict'

const express = require('express')
const routes = express.Router()
const packageJson = require('../../package.json')

const MikrotikController = require('./controllers/MikrotikController')
const PlanController = require('./controllers/PlanController')
const ClientController = require('./controllers/ClientController')
const SecretsController = require('./controllers/SecretsController')
const TransactionController = require('./controllers/TransactionController')
const BankController = require('./controllers/BankController')

/**
 * 
 * 
 */
routes.post(`/api/v${packageJson.version}/financial/transaction/generate`, TransactionController.generateTransaction)
routes.post(`/api/v${packageJson.version}/financial/transaction/associate`, TransactionController.generateAssociation) 
routes.get(`/api/v${packageJson.version}/financial/transaction/client/consult/:id_client`, TransactionController.consultClient)
routes.get(`/api/v${packageJson.version}/financial/transaction/consult/:id_transaction`, TransactionController.consultTransaction)
routes.put(`/api/v${packageJson.version}/financial/transaction/status/update`, TransactionController.statusUpdate)


/**
 * 
 * BankController
 */
routes.get(`/api/v${packageJson.version}/financial/bank/transaction/consult/:charge_id`, BankController.getInfoTransaction)

 


//routes.put(`/api/v${packageJson.version}/financial/transaction/pay/:charge_id`, )

// cancelar transacao ou todas as transacoes 
// rota para receber notificação do servidor da gerencianet

// rota gerar gerar boleto para pessoa, baixar e reenviar para email
// pegar todas associações geradas e todas as associações do determinado mês
// gerar bloqueios para cliente inadimplentes




/**
 * index - show all client
 * create - create new client - pre register
 * changeStatus - when active and desactive connection
 * blockUnlock - when client is unpaiment
 */
routes.get(`/api/v${packageJson.version}/client/index`, ClientController.index)
routes.post(`/api/v${packageJson.version}/client/new/create`, ClientController.register)
routes.put(`/api/v${packageJson.version}/client/edit/active/:id`, ClientController.changeStatus)
routes.put(`/api/v${packageJson.version}/client/edit/status/:id`, ClientController.blockUnlock)
/**
 * create - active client registed
 *  
 */
routes.post(`/api/v${packageJson.version}/client/secret/create`, SecretsController.create)
// criar rota para atualizar dados de client
routes.put(`/api/v${packageJson.version}/client/secret/enable/:name`, SecretsController.enableSecret)
routes.put(`/api/v${packageJson.version}/client/secret/disable/:name`, SecretsController.disableSecret)
/**
 * create - register plan and speeds to connection 
 * change_state - change state plan (active/!active)
 * 
 */
routes.post(`/api/v${packageJson.version}/system/plan/create`, PlanController.create)
routes.put(`/api/v${packageJson.version}/system/plan/edit/status/:id`, PlanController.changeStatus)
/**
 * index  - lista [0] data connection to first register
 * create - add new data connection mikrotik in database
 * test   - test connection with mikrotik before save 
 */
routes.get(`/api/v${packageJson.version}/mikrotik/index`, MikrotikController.index)
routes.post(`/api/v${packageJson.version}/mikrotik/save`, MikrotikController.create)
routes.post(`/api/v${packageJson.version}/mikrotik/test`, MikrotikController.test)


module.exports = routes