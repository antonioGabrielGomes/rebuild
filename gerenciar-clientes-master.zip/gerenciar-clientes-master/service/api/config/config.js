require('dotenv-safe').config()
const configuration = require('./database.json')

let connection = configuration.development

if (process.env.NODE_ENV === 'development')
    connection = configuration.development
else if (process.env.NODE_ENV === 'test')
    connection = configuration.test
else if (process.env.NODE_ENV === 'production')
    connection = configuration.production
else
    throw new Error('Failure to interpret environment variables')


module.exports = connection