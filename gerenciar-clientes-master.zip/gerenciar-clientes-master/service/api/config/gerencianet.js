const options = {
    client_id: 'Client_Id_f89e764b9fd9824dcde4026600a60059e11f798a',
    client_secret: 'Client_Secret_397bde5a4e8452ed87a128a0ff9d9f06b53eaf54',
    sandbox: true 
}

module.exports = options