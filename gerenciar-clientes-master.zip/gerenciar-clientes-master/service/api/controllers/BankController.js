'use stric'

const Gerencianet = require('../entities/Gerencianet')

module.exports = {

    async getInfoTransaction(req, res){
        const { charge_id } = req.params

        try {
            const gerencianet = new Gerencianet()
            await gerencianet.getInfoTransaction(charge_id)

            res.json({
                status: true,
                data: gerencianet.data,
                message: ''
            })
        } catch (e) {
            Error.console(e, res, `Error: ${e.message}`)
        }

    }

}