'use strict'

const Plan = require('../database/models/plan')
const Error = require('../exceptions/Error')

module.exports = {
 
    async create(req, res){
        const { name, value, active } = req.body

        try {
            const plan = await Plan.create({ name, value, active })
            
            return res.json({
                status: true,
                data: plan,
                message: 'Plan saved with success'
            })
        } catch (error) {
            Error.console(e, res, `Plan has not been saved: ${e.message}`)
        }

    },

    async changeStatus(req, res){
        const { id } = req.params

        try {
            const plan = await Plan.findByPk(id)

            if(!plan){
                return Error.breackFlow(res, 'Plan not found')
            }

            await Plan.update({ 
                active: !plan.dataValues.active
            }, {
                where: {
                    id: id
                }
            })

            let active = plan.dataValues.active ? 'disabled' : 'actived'
            plan.dataValues.active = !plan.dataValues.active

            return res.json({
                status: true,
                data: plan.dataValues,
                message: `Plan is ${active}`
            })
        } catch (e) {
            Error.console(e, res, `Plan has not been changed: ${e.message}`)
        }

    },

    async deletePlan(req, res){
        const { id } = req.params

        try {
            const plan = await Plan.findByPk(id)

            if(!plan){
                return Error.breackFlow(res, 'Plan not found')
            }

            await Plan.destroy({
                where: {
                    id: id
                }
            })

            return res.json({
                status: true,
                message: `Plan has been deactivated`
            })
        } catch (e) {
            Error.console(e, res, `Plan has not been changed: ${e.message}`)
        }
    }

}