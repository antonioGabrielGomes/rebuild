'use strict'

//const mikrotik = require('../entities/Mikrotik')
//const financial = require('../entities/Financial')
const Client = require('../entities/Client')
//const Financial = require('../entities/Financial')
const Transaction = require('../entities/Transaction')
const Error = require('../exceptions/Error')
const Financial = require('../entities/Financial')

module.exports = {

    async generateTransaction(req, res) {
        try {
            //             
            const financial = new Financial()
            let dateMonth = `${financial.date.getFullYear()}-${financial.date.getMonth() + 1}`

            await financial.checkDate(dateMonth)

            // Get clients active
            const client = new Client()
            await client.findAllClientWhere({ active: true })

            // Generate new transaction per client active
            const transaction = new Transaction(client)
            await transaction.createTransaction()

            // 
            await financial.createLogTransaction(dateMonth)

            res.json({
                status: true,
                data: null,
                message: 'Transactions were generated'
            })
        } catch (e) {
            Error.console(e, res, `${e.message}`)
        }
    },

    async generateAssociation(req, res) {
        try {
            // Get new transactions
            const transaction = new Transaction()
            await transaction.getByStatus('new')

            // Associate payment
            // billet
            await transaction.associateBillet()

            res.json({
                status: true,
                data: null,
                message: 'Associations were generated'
            })
        } catch (e) {
            Error.console(e, res, `Error: ${e.message}`)
        }
    },

    async consultClient(req, res) {
        const { id_client } = req.params

        try {
            // Get new transactions
            const transaction = new Transaction()
            await transaction.findTransactionsByClient(id_client)

            res.json({
                status: true,
                data: transaction.transactions,
                message: ''
            })
        } catch (e) {
            Error.console(e, res, `Error: ${e.message}`)
        }
    },

    async consultTransaction(req, res) {
        const { id_transaction } = req.params

        try {
            // Get new transactions
            const transaction = new Transaction()
            await transaction.findTransaction(id_transaction)

            res.json({
                status: true,
                data: transaction.transactions,
                message: ''
            })
        } catch (e) {
            Error.console(e, res, `Error: ${e.message}`)
        }

    },

    async statusUpdate(req, res) {

        try {

            const transaction = new Transaction()
            await transaction.getByStatus('waiting', false)

            if (transaction.transactions.length > 0) {

                transaction.transactions.forEach(async element => {
                    let id = element.dataValues.id
                    let charge_id = element.charge_id

                    await transaction.updateTransaction(id, charge_id)
                })

            } else {

                throw new Error('Transactions not found')

            }

            res.json({
                status: true,
                data: [],
                message: 'Updated Transactions'
            })
        } catch (e) {
            Error.console(e, res, `Error: ${e.message}`)
        }

    },

    async payOffTransaction(req, res) {
        const { id_transaction } = req.params

        try {
            // Get new transactions
            const transaction = new Transaction()
            await transaction.findTransactionsByClient(id_client)

            res.json({
                status: true,
                data: transaction.transactions,
                message: ''
            })
        } catch (e) {
            Error.console(e, res, `Error: ${e.message}`)
        }
    },

}

/*

module.exports = {

    async pending(req, res) {
        const Mikrotik = new mikrotik()
        const Financial = new financial()

        try {
            await Mikrotik.getSecrets()
            const pending = []
            const array = Mikrotik.secrets

            for (let index = 0; index < array.length; index++) {
                const element = array[index];
                //const id = element[0]
                const comment = element[11]
                const json = JSON.parse(comment.value)

                if (Financial.checkPendency(json.pendencies)) {
                    pending.push(element)
                }

            }

            res.json({
                status: true,
                data: pending,
                message: ''
            })
        } catch (e) {
            Error.console(e, res, `Connection not Established: ${e.message}`)
        }
    },

    async generatePending(req, res) {
        const Option = new options()

        try {
            await Option.readFile()
            Option.setNewDate()
            Option.salveOptions()

            res.json({
                status: true,
                data: [],
                message: 'Awaiting creation of invoices'
            })
        } catch (e) {
            Error.console(e, res, `Error: ${e.message}`)
        }
    },

    async createPending(req, res) {
        const Mikrotik = new mikrotik()
        const Option = new options()

        try {

            await Option.readFile()
            //Option.checkStatus('await') // await
            //await Option.updateStatus()

            let lastDate = new Date(Option.data.financial.lastDate)
            let date = `${lastDate.getDate()}/${lastDate.getMonth()+1}/${lastDate.getFullYear()}`

            await Mikrotik.getSecrets()
            const array = Mikrotik.secrets

            let secrets = Mikrotik.secrets

            let err = []
            secrets.forEach(async (element) => {

                let name = element[1].value
                let comment = element[11]
                let json = JSON.parse(comment.value)


                try {
                    if (json) {
                        json.pendencies.push(date)
                        await Mikrotik.setComment(name, JSON.stringify(json))
                    }
                    err.push(json)

                } catch (error) {
                  //  err.push(name)
                }

            })

            console.log(err)


            res.json({
                status: true,
                data: [],
                message: 'Operation performed'
            })
        } catch (e) {
            Error.console(e, res, `Error: ${e.message}`)
        }
    }
}

*/