'use strict'

const Connection = require('../database/models/connection')
const mikrotik = require('../entities/Mikrotik')
const Error = require('../exceptions/Error')

module.exports = {

    async create(req, res) {
        const { address, user, password } = req.body

        try {
            const connection = await Connection.create({ address, user, password })

            return res.json({
                status: true,
                data: connection,
                message: 'The connection data has been saved'
            })
        } catch (e) {
            Error.console(e, res, `The connection data has not been saved: ${e.message}`)
        }

    },

    async index(req, res) {
       
        try {
            let data = []
            const connection = await Connection.findAll({
                where: {
                    id: 1
                }
            })

            if(connection != [])
                data = connection[0].dataValues
            
            res.json({
                status: true,
                data: data,
                message: 'Data only'
            })
        } catch (e) {
            // output error temp
            Error.console(e, res, `Data not found: ${e.message}`)
        }
    },

    async test(req, res) {
        const { address, user, password } = req.body

        const Mikrotik = new mikrotik(address, user, password)

        try {
            /** */
            await Mikrotik.test()

            return res.json({
                status: true,
                data: null,
                message: 'Connection Established'
            })
        } catch (e) {
            // output error temp
            Error.console(e, res, `Connection not Established ${e.message}`)
        }

    }


}