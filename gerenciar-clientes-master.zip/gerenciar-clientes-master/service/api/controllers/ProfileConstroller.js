'use strict'

const mikrotik = require('../entities/Mikrotik')
const Error = require('../exceptions/Error')

module.exports = {

    async showAll(req, res) {
        const Mikrotik = new mikrotik()

        try {
            await Mikrotik.getProfiles()
             
            res.json({
                status: true,
                data: Mikrotik.profiles,
                message: ''
            })
        } catch (e) {
            // output error temp
            Error.console(e, res, `Connection not Established: ${e.message}`)

        }

    },

}