'use strict'

const Client_ = require('../entities/Client')

const Client = require('../database/models/client')
const Plan = require('../database/models/plan')
const Error = require('../exceptions/Error')


module.exports = {

    async index(req, res){

        try {
            /*
            const clients = await Client.findAll({
                include: {
                    association: 'plan',
                    attributes: ['name']
                }
            })
            */
            // get clients active
            const client = new Client_()
            await client.findAllClient()

    

            return res.json({
                status: true,
                data: client.clients,
                message: 'Data only'
            })
        } catch (e) {
            Error.console(e, res, `Connection fail: ${e.message}`)
        }

    },

    async register(req, res) {
    
        const {
            first_name,
            second_name,
            username,
            address,
            location,
            email,
            cpf,
            contato,
            plan_id
        } = req.body

        try {
            const plan = await Plan.findByPk(plan_id)

            if(!plan){
                return Error.breackFlow(res, 'Plan not found')
            }

            if(!plan.dataValues.active){
                return Error.breackFlow(res, 'Plan not available')
            }

            const client = await Client.create({
                first_name,
                second_name,
                username,
                address,
                location,
                email,
                cpf,
                contato,
                plan_id,
                blocked: false,
                active: false
            })

            return res.json({
                status: true,
                data: client,
                message: 'Client saved with success'
            })
        } catch (e) {
            Error.console(e, res, `Client has not been saved: ${e.message}`)
        }
    },

    /**
     * 
     * ANTES DE ATIVAR, O CLIENTE PRECISA TER UMA CONEXAO NO PPPoe
     */
    async changeStatus(req, res){
        const { id } = req.params

        try {
            const client = await Client.findByPk(id)

            if(!client){
                return Error.breackFlow(res, 'Client not found')
            }

            await Client.update({ 
                active: !client.dataValues.active
            }, {
                where: {
                    id: id
                }
            })

            let active = !client.dataValues.active ? 'actived' : 'disabled'
            client.dataValues.active = !client.dataValues.active

            return res.json({
                status: true,
                data: client.dataValues,
                message: `Client is ${active}`
            })
        } catch (e) {
            Error.console(e, res, `Client has not been changed: ${e.message}`)
        }

    },

    async blockUnlock(req, res){
        const { id } = req.params

        try {
            const client = await Client.findByPk(id)

            if(!client){
                return Error.breackFlow(res, 'Client not found')
            }

            await Client.update({ 
                blocked: !client.dataValues.blocked
            }, {
                where: {
                    id: id
                }
            })

            let blocked = client.dataValues.blocked ? 'blocked' : 'unlocked'
            client.dataValues.blocked = !client.dataValues.blocked

            return res.json({
                status: true,
                data: client.dataValues,
                message: `Client is ${blocked}`
            })
        } catch (e) {
            Error.console(e, res, `Client has not been changed: ${e.message}`)
        }

    }

}