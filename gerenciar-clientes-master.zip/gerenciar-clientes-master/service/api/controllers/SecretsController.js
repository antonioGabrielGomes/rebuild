'use strict'

const Plan = require('../database/models/plan')
const Connection = require('../database/models/connection')
const Mikrotik = require('../entities/Mikrotik')
const Error = require('../exceptions/Error')

module.exports = {

    async create(req, res) {
        const {
            username,
            password,
            plan_id,
            service,
            comment
        } = req.body

        try {
            const plan = await Plan.findByPk(plan_id)

            if (!plan) {
                return Error.breackFlow(res, 'Plan not found')
            }

            const connection = await Connection.findAll({
                where: {
                    id: 1
                }
            })

            const mikrotik = new Mikrotik(connection[0].dataValues.address, connection[0].dataValues.user, connection[0].dataValues.password)

            if (await mikrotik.findSecret(username)) {
                await mikrotik.addSecret(username, password, service, plan.dataValues.name, comment)
            }else{
                Error.breackFlow(res, 'Username already exists')
            }

            res.json({
                status: true,
                data: [],
                message: `Customer was created on the equipment.`
            })
        } catch (e) {
            Error.console(e, res, `Connection not Established: ${e.message}`)
        }

    },

    async enableSecret(req, res) {
        const { name } = req.params        

        try {
            const connection = await Connection.findAll({
                where: {
                    id: 1
                }
            })

            const mikrotik = new Mikrotik(connection[0].dataValues.address, connection[0].dataValues.user, connection[0].dataValues.password)  
            
            if (await mikrotik.findSecret(name)) {               
                Error.breackFlow(res, 'Username does not exist')
            }

            await mikrotik.enable(name)

            res.json({
                status: true,
                data: [],
                message: `Client was enabled`
            })
        } catch (e) {
            Error.console(e, res, `Error: ${e.message}`)
        }
    },

    async disableSecret(req, res) {
        const { name } = req.params    

        try {
            const connection = await Connection.findAll({
                where: {
                    id: 1
                }
            })

            const mikrotik = new Mikrotik(connection[0].dataValues.address, connection[0].dataValues.user, connection[0].dataValues.password)  
            

            if (await mikrotik.findSecret(name)) {               
                Error.breackFlow(res, 'Username does not exist')
            }

            await mikrotik.disable(name)

            res.json({
                status: true,
                data: [],
                message: `Client was disabled`
            })
        } catch (e) {
            Error.console(e, res, `Error: ${e.message}`)
        }
    }




}